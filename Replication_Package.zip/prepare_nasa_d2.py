"""Audit NASA D-double-prime inputs, fixed schemas and original file hashes."""
import argparse
import hashlib
import json
from pathlib import Path
from dataset_loader import DEFAULT_ROOT, load_family, NASA_D2_METRICS
from experiments.common import write_csv


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--data-root', type=Path, default=DEFAULT_ROOT)
    parser.add_argument('--output-dir', type=Path, default=Path('results/nasa_d2_independent/protocol'))
    args = parser.parse_args()
    projects = load_family(args.data_root, 'NASA_D2')
    rows = [dict(project=p['name'], original_rows=p['original_rows'], valid_rows=len(p['y']),
                 invalid_rows=p['invalid_rows'], defects=int(p['y'].sum()),
                 metrics=len(p['features']), path=str(p['path'].resolve()),
                 sha256=hashlib.sha256(p['path'].read_bytes()).hexdigest()) for p in projects]
    args.output_dir.mkdir(parents=True, exist_ok=True)
    write_csv(args.output_dir/'projects.csv', rows)
    protocol = dict(dataset='NASA_D2', projects=[p['name'] for p in projects],
        excluded={'KC4':'empty ARFF placeholder in the pinned mirror'}, features=NASA_D2_METRICS,
        note='Fixed intersection of attribute names, no target-label feature selection.',
        original_files_unchanged=True, target_labels_used_only_for_final_metrics=True,
        split='11 source projects -> one target, repeated for 12 targets',
        tuning='source-project LOPO, reused across seeds; no real target labels',
        seeds=list(range(5)), budget_fraction=.25,
        baselines='ALL uses all source rows; selection methods use 25% budget')
    (args.output_dir/'protocol.json').write_text(json.dumps(protocol,indent=2),encoding='utf-8')
    for row in rows:
        print(row['project'], row['valid_rows'], 'rows;', row['defects'], 'defects')
    print('Protocol saved:', args.output_dir.resolve())


if __name__ == '__main__':
    main()
