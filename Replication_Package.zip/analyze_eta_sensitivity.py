"""Summarize eta runs; optionally include existing eta=0 and eta=.2 controls."""
import argparse
import hashlib
import json
from pathlib import Path
import numpy as np
import pandas as pd
from scipy.stats import rankdata, wilcoxon

KEY = ['dataset', 'target', 'seed']
TARGET = ['dataset', 'target']


def load(folder, method):
    path = folder/'per_run_metrics.csv'
    frame = pd.read_csv(path)
    if frame.empty or frame.duplicated(KEY).any() or not frame.method.eq(method).all():
        raise ValueError(f'Invalid or duplicate result identities: {path}')
    if not np.isfinite(frame[['auc', 'mcc']].to_numpy()).all():
        raise ValueError(f'Nonfinite metrics: {path}')
    frame = frame.set_index(KEY).sort_index()
    return frame, dict(path=str(path.resolve()), sha256=hashlib.sha256(path.read_bytes()).hexdigest())


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--input-root', type=Path, required=True)
    parser.add_argument('--results-root', type=Path, default=Path(__file__).resolve().parent/'results')
    parser.add_argument('--new-only', action='store_true')
    args = parser.parse_args()
    inputs = []
    for folder in sorted(args.input_root.glob('eta_*')):
        if not (folder/'per_run_metrics.csv').exists():
            continue
        config = json.loads((folder/'config.json').read_text(encoding='utf-8'))
        inputs.append((float(config['low_fraction']), folder, 'coverage_uncertainty_graph_lr'))
    if not inputs:
        raise ValueError('No completed eta experiments found.')
    if not args.new_only:
        inputs += [(0., args.results_root/'fair_ablations_25percent_5seeds/coverage_only_graph_lr', 'coverage_only_graph_lr'),
                   (.2, args.results_root/'budget_main_25percent_5seeds', 'coverage_uncertainty_graph_lr')]
    frames, means, sources = {}, {}, {}
    for eta, folder, method in sorted(inputs):
        if eta in frames:
            raise ValueError(f'Duplicate eta={eta}; use --new-only to summarize a newly rerun .2.')
        frame, source = load(folder, method)
        frames[eta], sources[str(eta)] = frame, source
        means[eta] = frame.groupby(level=TARGET)[['auc', 'mcc']].mean()
    reference = next(iter(frames.values()))
    for eta, frame in frames.items():
        if not frame.index.equals(reference.index):
            raise ValueError(f'eta={eta}: target/seed identities differ; use --new-only for smoke runs.')
        for column in ['source_samples', 'selected_samples', 'target_samples']:
            if not frame[column].eq(reference[column]).all():
                raise ValueError(f'eta={eta}: mismatched {column}.')
    summary, target_rows, tests = [], [], []
    for eta, frame in frames.items():
        tm = means[eta]
        summary.append(dict(eta=eta, targets=len(tm), runs=len(frame), seeds=frame.index.get_level_values('seed').nunique(),
            retained_fraction=float((frame.selected_samples/frame.source_samples).mean()),
            auc_mean=float(tm.auc.mean()), auc_std=float(tm.auc.std()),
            mcc_mean=float(tm.mcc.mean()), mcc_std=float(tm.mcc.std())))
        for (family, target), values in tm.iterrows():
            target_rows.append(dict(eta=eta, dataset=family, target=target, auc=values.auc, mcc=values.mcc))
        if .2 not in means or eta == .2:
            continue
        for metric in ['auc', 'mcc']:
            delta = (tm[metric]-means[.2][metric]).to_numpy()
            delta[np.abs(delta) <= 1e-12] = 0
            nonzero = delta[delta != 0]
            ranks = rankdata(np.abs(nonzero))
            tests.append(dict(eta=eta, reference_eta=.2, metric=metric, targets=len(delta),
                delta_mean=float(delta.mean()), wins=int((delta>0).sum()), ties=int((delta==0).sum()),
                losses=int((delta<0).sum()), p=float(wilcoxon(delta).pvalue) if len(nonzero) else 1.,
                rank_biserial=float(np.dot(np.sign(nonzero), ranks)/ranks.sum()) if len(nonzero) else 0.))
    if tests:
        order = sorted(range(len(tests)), key=lambda i: tests[i]['p'])
        q = np.minimum.accumulate(np.array([tests[i]['p']*len(tests)/(j+1) for j,i in enumerate(order)])[::-1])[::-1]
        for i,value in zip(order,q): tests[i]['bh_q'] = min(1.,float(value))
    out = args.input_root/'statistics'
    out.mkdir(parents=True, exist_ok=True)
    pd.DataFrame(summary).to_csv(out/'eta_summary.csv', index=False, encoding='utf-8-sig')
    pd.DataFrame(target_rows).to_csv(out/'eta_per_target.csv', index=False, encoding='utf-8-sig')
    if tests: pd.DataFrame(tests).to_csv(out/'paired_vs_eta02.csv', index=False, encoding='utf-8-sig')
    (out/'protocol.json').write_text(json.dumps(dict(inputs=sources,
        aggregation='Mean seeds within each target, then equal-weight target means; SD across targets.',
        paired_direction='eta minus eta=.2; BH jointly across all emitted AUC/MCC tests.',
        factor='eta only; each interior eta uses the same 21-setting source-LOPO search.'), indent=2), encoding='utf-8')
    print('\nETA SENSITIVITY: same final budget and source-LOPO grid')
    print(pd.DataFrame(summary).to_string(index=False))
    if tests:
        print('\nPaired differences: eta minus eta=.2')
        print(pd.DataFrame(tests).to_string(index=False))
    print(f'\nSaved {out.resolve()}')


if __name__ == '__main__':
    main()
