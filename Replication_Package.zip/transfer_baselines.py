"""Unsupervised transfer/filter baselines under the shared metric/LR protocol."""
import numpy as np
from scipy.linalg import eigh
from sklearn.cluster import KMeans
from sklearn.kernel_approximation import Nystroem
from sklearn.metrics.pairwise import rbf_kernel, pairwise_distances
from sklearn.neighbors import NearestNeighbors
from sklearn.preprocessing import StandardScaler
from selection import compress, fit_lr, positive_probability

TRANSFER_METHODS = ('kmm_lr', 'tca_lr', 'nn_filter_lr', 'peters_filter_lr')


def scaled_metrics(X, T):
    source, target = compress(X), compress(T)
    scaler = StandardScaler().fit(source)
    return scaler.transform(source), scaler.transform(target)


def nn_filter(source, target, neighbors=10):
    indices = NearestNeighbors(n_neighbors=min(neighbors, len(source)), n_jobs=1).fit(source).kneighbors(target)[1]
    return np.unique(indices)


def peters_select(source, target, labels):
    """For each mixed cluster: source -> nearest target -> its closest source fan."""
    selected = []
    ns = len(source)
    for group in np.unique(labels[ns:]):
        s = np.flatnonzero(labels[:ns] == group)
        t = np.flatnonzero(labels[ns:] == group)
        if not len(s):
            continue
        distance, nearest = NearestNeighbors(n_neighbors=1, n_jobs=1).fit(target[t]).kneighbors(source[s])
        # Sort first by target identity, then distance, then source index for ties.
        order = np.lexsort((s, distance[:, 0], nearest[:, 0]))
        fans = nearest[order, 0]
        first = np.r_[True, fans[1:] != fans[:-1]]
        selected.extend(s[order[first]].tolist())
    if not selected:
        raise ValueError('Peters filter retained no source samples; inspect mixed clusters.')
    return np.asarray(sorted(set(selected)), dtype=int)


def peters_filter(source, target, seed, cluster_size=10):
    pooled = np.vstack((source, target))
    clusters = min(max(1, len(pooled)//cluster_size), len(np.unique(pooled, axis=0)))
    labels = KMeans(n_clusters=clusters, n_init=1, max_iter=300, random_state=seed).fit_predict(pooled)
    chosen = peters_select(source, target, labels)
    return chosen, dict(clusters=clusters, instances_per_cluster=cluster_size,
        clustering='pooled KMeans, kmeans++, n_init=1, max_iter=300',
        rule='source-to-target assignment; closest source supporter per popular target')


def linear_tca(source, target, dimension=10, mu=1.):
    """Exact linear-kernel TCA reduced to the nonzero eigenspace of K=ZZ^T."""
    z = np.vstack((source, target))
    u, singular, _ = np.linalg.svd(z, full_matrices=False)
    keep = singular > max(z.shape)*np.finfo(float).eps*max(float(singular.max()), 1.)
    u, eigen = u[:, keep], singular[keep]**2
    if not len(eigen):
        raise ValueError('TCA has no nonconstant feature directions.')
    ns, nt = len(source), len(target)
    e = np.r_[np.full(ns, 1/ns), np.full(nt, -1/nt)]
    v = eigen*(u.T @ e)
    a = np.outer(v, v) + mu*np.eye(len(eigen))
    ku = u*eigen
    centered = ku-ku.mean(axis=0)
    b = centered.T @ centered
    # Whiten positive-definite A, then solve B b = lambda A b.
    values, rotation = eigh(a)
    inverse_sqrt = (rotation/np.sqrt(values)) @ rotation.T
    variance, vectors = eigh(inverse_sqrt @ b @ inverse_sqrt)
    positive = np.flatnonzero(variance > max(1., float(variance.max()))*1e-12)
    if not len(positive):
        raise ValueError('TCA variance constraint has zero rank.')
    picked = positive[::-1][:dimension]
    coefficients = inverse_sqrt @ vectors[:, picked]
    mapped = ku @ coefficients
    return mapped[:ns], mapped[ns:], dict(kernel='linear', dimension=len(picked), mu=mu,
        solver='exact low-rank dual TCA eigensystem', source_rank=len(eigen),
        eigenvalues=variance[picked].tolist())


def capped_simplex(vector, total, bound):
    """Euclidean projection onto 0<=w<=bound, sum(w)=total."""
    lo, hi = float(vector.min()-bound), float(vector.max())
    for _ in range(55):
        mid = (lo+hi)/2
        if np.clip(vector-mid, 0, bound).sum() > total:
            lo = mid
        else:
            hi = mid
    return np.clip(vector-(lo+hi)/2, 0, bound)


def kmm_weights(source, target, seed, bound=10., landmarks=256, exact_limit=1500):
    """RBF KMM, epsilon=0. Large-source kernel uses explicit Nystrom approximation."""
    ns = len(source)
    sample = source[np.linspace(0, ns-1, min(ns, 512), dtype=int)]
    distance = pairwise_distances(sample, metric='sqeuclidean')
    positive = distance[np.triu_indices(len(sample), 1)]
    positive = positive[positive > 1e-12]
    gamma = 1/(2*float(np.median(positive))) if len(positive) else 1.
    if ns <= exact_limit:
        kernel = rbf_kernel(source, gamma=gamma)
        kappa = np.zeros(ns)
        for start in range(0, len(target), 512):
            kappa += rbf_kernel(source, target[start:start+512], gamma=gamma).sum(axis=1)
        kappa /= len(target)
        product = lambda w: kernel @ w/ns
        lipschitz = float(kernel.sum(axis=1).max())/ns
        approximation = 'none; exact RBF source kernel and full target mean'
    else:
        mapper = Nystroem(kernel='rbf', gamma=gamma, n_components=min(landmarks, ns), random_state=seed)
        phi = mapper.fit_transform(source)
        target_mean = np.zeros(phi.shape[1])
        for start in range(0, len(target), 512):
            target_mean += mapper.transform(target[start:start+512]).sum(axis=0)
        target_mean /= len(target)
        kappa = phi @ target_mean
        product = lambda w: phi @ (phi.T @ w)/ns
        lipschitz = float(np.linalg.eigvalsh(phi.T @ phi)[-1])/ns
        approximation = f'Nystrom RBF, {phi.shape[1]} landmarks; all source/target rows retained'
    # Divide the standard QP by ns: 0.5*w^T K w/ns - kappa^T w.
    # Box plus exact mass is the epsilon=0 case of the KMM normalization slab.
    weights, extrapolated, momentum = np.ones(ns), np.ones(ns), 1.
    lipschitz = max(lipschitz, 1e-12)
    gap = np.inf
    for iteration in range(1, 10001):
        gradient = product(extrapolated)-kappa
        updated = capped_simplex(extrapolated-gradient/lipschitz, ns, bound)
        if iteration % 25 == 0 or iteration == 1:
            g = product(updated)-kappa
            order = np.argsort(g, kind='stable')
            oracle = np.zeros(ns)
            full, remainder = divmod(float(ns), bound)
            oracle[order[:int(full)]] = bound
            if remainder > 0:
                oracle[order[int(full)]] = remainder
            gap = float(g @ (updated-oracle))/ns
            if gap <= 1e-6:
                weights = updated
                break
        next_momentum = (1+np.sqrt(1+4*momentum**2))/2
        extrapolated = updated + (momentum-1)/next_momentum*(updated-weights)
        weights, momentum = updated, next_momentum
    else:
        raise RuntimeError(f'KMM did not reach normalized QP dual gap 1e-6; gap={gap:g}')
    return weights, dict(kernel='rbf', gamma=gamma, bound=bound, epsilon=0.,
        approximation=approximation, iterations=iteration, normalized_dual_gap=gap,
        weight_sum=float(weights.sum()), ess=float(weights.sum()**2/np.dot(weights, weights)))


def baseline_prediction(method, X, y, T, seed, *, nn_neighbors=10, peters_size=10,
                        tca_dimension=10, tca_mu=1., kmm_bound=10., kmm_landmarks=256,
                        kmm_exact_limit=1500):
    source, target = scaled_metrics(X, T)
    chosen, weights = np.arange(len(X)), np.ones(len(X))
    if method == 'nn_filter_lr':
        chosen = nn_filter(source, target, nn_neighbors)
        audit = dict(neighbors=min(nn_neighbors, len(X)), rule='union of target-to-source kNN')
    elif method == 'peters_filter_lr':
        chosen, audit = peters_filter(source, target, seed, peters_size)
    elif method == 'tca_lr':
        s, t, audit = linear_tca(source, target, tca_dimension, tca_mu)
        model = fit_lr(s, y, seed)
        return positive_probability(model, t), chosen, weights, audit
    elif method == 'kmm_lr':
        weights, audit = kmm_weights(source, target, seed, kmm_bound, kmm_landmarks, kmm_exact_limit)
    else:
        raise ValueError(f'Unknown baseline: {method}')
    raw = compress(X[chosen])
    if method != 'kmm_lr':
        weights = np.ones(len(chosen))
        model = fit_lr(raw, y[chosen], seed)
    else:
        model = fit_lr(raw, y, seed)
        if len(np.unique(y)) == 2:
            # Explicit count-based class weights avoid sklearn-version changes that
            # recompute 'balanced' from the supplied importance weights.
            counts = np.bincount(y.astype(int), minlength=2)
            model.steps[-1][1].set_params(class_weight={i: len(y)/(2*counts[i]) for i in (0, 1)})
        model.steps[-1][1].fit(model.steps[0][1].transform(raw), y, sample_weight=weights)
        audit['class_policy'] = 'raw KMM weights times explicit count-based balanced class weights; no post-hoc class mass constraint'
    return positive_probability(model, compress(T)), chosen, weights, audit
