"""Label-free, fixed-budget selectors for graph-LR control experiments."""
import contextlib
import io
import numpy as np
from vendor.google_active_learning.kcenter_greedy import kCenterGreedy
from sklearn.neighbors import NearestNeighbors
from sklearn.preprocessing import StandardScaler
from selection import compress

METHODS = ('nearest_budget_graph_lr', 'coreset_graph_lr')


class _UniqueKCenterGreedy(kCenterGreedy):
    """Keep upstream greedy selection unique when feature vectors coincide."""

    def __init__(self, source, seed):
        super().__init__(source, None, seed)
        self._selected_indices = set()

    def update_distances(self, cluster_centers, only_new=True, reset_dist=False):
        super().update_distances(cluster_centers, only_new=only_new, reset_dist=reset_dist)
        self._selected_indices.update(cluster_centers)
        if self.min_distances is not None:
            self.min_distances[list(self._selected_indices)] = -np.inf


def kcenter_order(source, budget, seed):
    """Author-recommended Google k-center greedy, with a seeded first source row.

    The CPDP wrapper enforces unique row indices for duplicate feature vectors.
    Shared geometry and the downstream Graph LR are configured by the caller.
    """
    if not 1 <= budget <= len(source):
        raise ValueError('Budget must be between 1 and source pool size.')
    source = np.asarray(source, dtype=float)
    first = int(np.random.default_rng(seed).integers(len(source)))
    if budget == 1:
        return np.array([first], dtype=int)
    sampler = _UniqueKCenterGreedy(source, seed)
    with contextlib.redirect_stdout(io.StringIO()):
        selected = sampler.select_batch_(None, [first], budget - 1)
    return np.asarray([first, *selected], dtype=int)


def select_budget(method, X, T, budget, seed):
    """Source-only fitted geometry; accepts features, never labels."""
    if method not in METHODS:
        raise ValueError(f'Unknown selector: {method}')
    if not 1 <= budget <= len(X):
        raise ValueError('Invalid budget.')
    scaler = StandardScaler().fit(compress(X))
    source = scaler.transform(compress(X))
    if method == 'nearest_budget_graph_lr':
        target = scaler.transform(compress(T))
        distance = NearestNeighbors(n_neighbors=1, n_jobs=1).fit(target).kneighbors(source)[0][:, 0]
        chosen = np.argsort(distance, kind='stable')[:budget]
        return chosen, distance, dict(rule='K source rows closest to any target row', budget=budget,
            implementation='sklearn.neighbors.NearestNeighbors; fixed-budget source ranking')
    chosen = kcenter_order(source, budget, seed)
    return chosen, None, dict(rule='source-pool greedy k-center; seeded first point',
                              budget=budget, selection_seed=seed,
                              implementation='google/active-learning kCenterGreedy; seeded initial point; unique indices')
