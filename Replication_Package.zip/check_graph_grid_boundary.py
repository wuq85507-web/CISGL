"""Main-model boundary check: reuse 21 saved candidates, evaluate 12 boundary settings."""
import hashlib
import json
from pathlib import Path
import time
import numpy as np
from graph_tuning import tune_graph
from experiments.common import run_cli
from experiments.coverage_uncertainty_graph_lr import METHOD, DEFAULTS as MAIN_DEFAULTS, run as main_run

DEFAULTS = dict(MAIN_DEFAULTS, dataset='paper', budget_fraction=.25, low_fraction=.2,
                target_regions=5, seeds=[0,1,2,3,4],
                output_dir=Path('results/graph_boundary_main_25percent_5seeds'))


def candidate_key(row):
    return float(row['c']), float(row['beta']), int(row['neighbors'])


def merge_records(old, extra):
    """Two overlapping candidates verify compatibility before old rows are reused."""
    for record in [old, extra]:
        for candidate in record['candidates']:
            folds = [r for r in record['folds'] if candidate_key(r)==candidate_key(candidate)]
            if not folds or len(folds)!=int(candidate['folds']) or any(
                    abs(float(candidate[m])-float(np.mean([r[m] for r in folds])))>1e-9
                    for m in ['auc','mcc']):
                raise ValueError('Candidate summary does not match its source-LOPO fold records.')
    old_candidates = {candidate_key(r): r for r in old['candidates']}
    new_candidates = {candidate_key(r): r for r in extra['candidates']}
    anchors = set(old_candidates) & set(new_candidates)
    if not anchors:
        raise ValueError('At least one overlapping candidate is required to verify the saved protocol.')
    old_folds = {(candidate_key(r), int(r['held_out_source'])): r for r in old['folds']}
    for row in extra['folds']:
        key = candidate_key(row)
        if key not in anchors:
            continue
        previous = old_folds.get((key, int(row['held_out_source'])))
        if previous is None or any(abs(float(row[m])-float(previous[m])) > 1e-9 for m in ['auc','mcc']):
            raise ValueError('Saved source-LOPO folds do not match the anchor rerun. '
                             'Stop rather than mixing different validation protocols.')
    for key in anchors:
        old_groups = {int(r['held_out_source']) for r in old['folds'] if candidate_key(r)==key}
        new_groups = {int(r['held_out_source']) for r in extra['folds'] if candidate_key(r)==key}
        if old_groups != new_groups:
            raise ValueError('Eligible source-LOPO folds changed.')
    # Keep the old candidate order, preserving the original exact-tie behavior.
    added = [r for r in extra['candidates'] if candidate_key(r) not in old_candidates]
    candidates = list(old['candidates']) + added
    best = max(candidates, key=lambda r: (r['auc'], r['mcc'], -r['beta'], -r['neighbors']))
    folds = list(old['folds']) + [r for r in extra['folds'] if candidate_key(r) not in old_candidates]
    return dict(best=best, candidates=candidates, folds=folds,
        original_best=old['best'], boundary_best=extra['best'],
        original_candidates=len(old_candidates), added_candidates=len(added),
        evaluated_boundary_candidates=len(extra['candidates']), verified_anchor_candidates=len(anchors),
        selected_from_added_grid=candidate_key(best) not in old_candidates,
        validation_auc_gain=float(best['auc']-old['best']['auc']),
        validation_mcc_gain=float(best['mcc']-old['best']['mcc']),
        protocol=old.get('protocol','source-project LOPO'), real_target_used=False)


def configure(parser):
    parser.add_argument('--baseline-results', default=str(Path(__file__).resolve().parent/'results/budget_main_25percent_5seeds'))
    parser.add_argument('--boundary-c-grid', nargs='+', type=float, default=[.01,.1])
    parser.add_argument('--boundary-beta-grid', nargs='+', type=float, default=[.3,1.,3.])
    parser.set_defaults(boundary_script_hash=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())


def prepare(X, y, groups, args, cache):
    if args.graph_tuning != 'source_lopo':
        raise ValueError('The boundary check requires source_lopo tuning.')
    for values in [args.boundary_c_grid, args.boundary_beta_grid]:
        if not values or not np.isfinite(values).all() or min(values) <= 0:
            raise ValueError('Boundary C and beta candidates must be finite and positive.')
    records = json.loads(cache.read_text(encoding='utf-8')) if cache.exists() else {}
    if METHOD in records:
        return records[METHOD]['best']
    baseline = Path(args.baseline_results)
    old_path = baseline/'tuning'/cache.name
    config = json.loads((baseline/'config.json').read_text(encoding='utf-8'))
    for field in ['budget', 'budget_fraction', 'low_fraction', 'target_regions', 'distance_quantiles',
                  'candidate_multiplier', 'information_ridge', 'graph_c_grid', 'graph_beta_grid',
                  'graph_neighbor_grid']:
        actual = getattr(args, field)
        if config.get(field) != actual:
            raise ValueError(f'Baseline protocol differs in {field}: {config.get(field)} versus {actual}')
    current = json.loads((args.output_dir/'config.json').read_text(encoding='utf-8'))
    if any(config.get('data_hashes',{}).get(p) != h for p,h in current['data_hashes'].items()):
        raise ValueError('Data files differ from the baseline run.')
    old = json.loads(old_path.read_text(encoding='utf-8'))[METHOD]
    print(f'Source-only boundary check: {cache.stem}; reusing {len(old["candidates"])} saved candidates', flush=True)
    started = time.perf_counter()
    extra = tune_graph(X, y, groups, [METHOD], budget=args.budget,
        budget_fraction=args.budget_fraction, low_fraction=args.low_fraction,
        regions=args.target_regions, quantiles=args.distance_quantiles,
        candidate_multiplier=args.candidate_multiplier, information_ridge=args.information_ridge,
        betas=args.boundary_beta_grid, neighbors=list(dict.fromkeys(args.graph_neighbor_grid)),
        c_grid=args.boundary_c_grid, tune_all_c=True)[METHOD]
    record = merge_records(old, extra)
    record.update(tuning_seconds_batch=time.perf_counter()-started,
        baseline_tuning_seconds=old.get('tuning_seconds_batch',0.),
        baseline_tuning_file=str(old_path.resolve()),
        baseline_tuning_sha256=hashlib.sha256(old_path.read_bytes()).hexdigest())
    records[METHOD] = record
    cache.parent.mkdir(parents=True, exist_ok=True)
    cache.write_text(json.dumps(records, indent=2), encoding='utf-8')
    print(f'  {record["original_candidates"]} original + {record["added_candidates"]} new; '
          f'anchor checks passed; source-validation AUC gain={record["validation_auc_gain"]:.6f}; '
          f'best C={record["best"]["c"]}, beta={record["best"]["beta"]}, k={record["best"]["neighbors"]}', flush=True)
    return record['best']


def run(X, y, groups, T, seed, args, settings):
    result = main_run(X, y, groups, T, seed, args, settings)
    result.training['experiment'] = 'source-LOPO parameter boundary sensitivity'
    return result


if __name__ == '__main__':
    run_cli(METHOD, run, DEFAULTS, prepare=prepare, configure=configure)
