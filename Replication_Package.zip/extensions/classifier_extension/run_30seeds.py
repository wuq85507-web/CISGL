"""RF/DT only: H+L+graph smoothing versus random+ordinary, seeds 0..29."""
import argparse
import csv
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys

CLASSIFIERS = ('rf', 'dt')


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def import_compatible_runs(source, destination, method, classifier, graph, args,
                           expected, code_hash, data_hashes, runner_hash):
    """Copy compatible completed runs into a new output; never edit their source."""
    if (destination/'config.json').exists():
        return dict(status='resume current output', imported=0)
    if (destination/'per_run_metrics.csv').exists():
        raise ValueError(f'Metrics exist without configuration: {destination}')
    config_path, metrics_path = source/'config.json', source/'per_run_metrics.csv'
    if not config_path.is_file() or not metrics_path.is_file():
        return dict(status='no previous compatible result', imported=0)
    config = json.loads(config_path.read_text(encoding='utf-8'))
    checks = dict(method=method, classifier=classifier, selection='hl' if graph else 'random',
        dataset=args.dataset, data_root=str(args.data_root), project_dir=str(args.project_dir),
        budget_fraction=.25, budget=None, low_fraction=.2, target_regions=5,
        graph_tuning='source_lopo', graph_beta=0., runner_sha256=runner_hash,
        code_hash=code_hash, data_hashes=data_hashes)
    if graph:
        checks.update(smooth_lambda_grid=[0., .1, 1., 10.], smooth_neighbor_grid=[5, 10])
    if any(config.get(k) != v for k,v in checks.items()):
        return dict(status='previous code, data, or configuration differs; rerun in new output', imported=0)
    with metrics_path.open(encoding='utf-8-sig', newline='') as stream:
        reader = csv.DictReader(stream); fields = reader.fieldnames; rows = list(reader)
    keys = [(r['dataset'],r['target'],int(r['seed'])) for r in rows]
    if len(keys) != len(set(keys)):
        return dict(status='previous metrics contain duplicate tasks; rerun in new output', imported=0)
    usable = []
    for row,key in zip(rows,keys):
        if key not in expected: continue
        dataset,target,seed = key
        detail_name = f'{dataset}__{target}__seed{seed}'
        detail = source/'runs'/detail_name
        tuning = source/'tuning'/f'{dataset}__{target}.json'
        required = ['audit.json',f'{method}_training.json',f'{method}_selection.csv',f'{method}_predictions.csv']
        if not tuning.is_file() or not all((detail/f).is_file() for f in required): continue
        usable.append((row,detail,tuning))
    if not usable:
        return dict(status='no requested completed run to import', imported=0)
    destination.mkdir(parents=True, exist_ok=True)
    (destination/'tuning').mkdir(exist_ok=True)
    for row,detail,tuning in usable:
        shutil.copytree(detail,destination/'runs'/detail.name,dirs_exist_ok=True)
        shutil.copy2(tuning,destination/'tuning'/tuning.name)
    with (destination/'per_run_metrics.csv').open('w',encoding='utf-8-sig',newline='') as stream:
        writer=csv.DictWriter(stream,fieldnames=fields)
        writer.writeheader();writer.writerows(row for row,_,_ in usable)
    shutil.copy2(config_path,destination/'config.json')
    return dict(status='imported compatible completed runs',imported=len(usable),
        source=str(source),source_metrics_sha256=sha(metrics_path),
        seeds=sorted({int(row['seed']) for row,_,_ in usable}))


def summarize(output,expected,seeds):
    import pandas as pd
    metrics=['auc','mcc','average_precision','f1'];frames=[]
    for classifier in CLASSIFIERS:
        for arm in ['random_plain','hl_graphsmooth']:
            method=f'random25_{classifier}' if arm=='random_plain' else f'hl25_graphsmooth_{classifier}'
            folder=output/method
            frame=pd.read_csv(folder/'per_run_metrics.csv',encoding='utf-8-sig')
            frame=frame.loc[[(d,t,int(s)) in expected for d,t,s in zip(frame.dataset,frame.target,frame.seed)]].copy()
            keys=list(zip(frame.dataset,frame.target,frame.seed.astype(int)))
            if len(keys)!=len(set(keys)) or set(keys)!=expected:
                raise ValueError(f'Incomplete or duplicate target/seed results: {method}')
            frame['arm']=arm;frame['classifier']=classifier
            frame['graph_smoothing']=arm=='hl_graphsmooth'
            if arm=='hl_graphsmooth':
                values=[]
                for row in frame.itertuples():
                    record=folder/'runs'/f'{row.dataset}__{row.target}__seed{int(row.seed)}'/f'{method}_training.json'
                    values.append(json.loads(record.read_text(encoding='utf-8'))['smoothing_lambda'])
                frame['smoothing_lambda']=values
            else:frame['smoothing_lambda']=0.
            frames.append(frame)
            target=frame.groupby(['dataset','target'],as_index=False)[metrics].mean()
            target['runs']=frame.groupby(['dataset','target']).size().to_numpy()
            (folder/'statistics').mkdir(exist_ok=True)
            target.to_csv(folder/'statistics/target_means.csv',index=False,encoding='utf-8-sig')
    runs=pd.concat(frames,ignore_index=True)
    keys=['dataset','target','classifier','arm']
    targets=runs.groupby(keys,as_index=False)[metrics].mean()
    targets['runs']=runs.groupby(keys).size().to_numpy()
    assert (targets['runs']==len(seeds)).all()
    overall=targets.groupby(['classifier','arm'],as_index=False)[metrics].mean()
    overall['targets']=targets.groupby(['classifier','arm']).size().to_numpy()
    overall['runs_per_target']=len(seeds)
    ordinary=targets[targets.arm=='random_plain'].drop(columns=['arm','runs'])
    graph=targets[targets.arm=='hl_graphsmooth'].drop(columns=['arm','runs'])
    paired=graph.merge(ordinary,on=['dataset','target','classifier'],suffixes=('_hl_graph','_random_plain'),validate='one_to_one')
    for m in metrics:paired[f'delta_{m}']=paired[f'{m}_hl_graph']-paired[f'{m}_random_plain']
    differences=paired.groupby('classifier',as_index=False)[[f'delta_{m}' for m in metrics]].mean()
    for name,frame in [('per_run_metrics',runs),('target_means',targets),('overall_means',overall),
                       ('paired_target_differences',paired),('overall_differences',differences)]:
        frame.to_csv(output/f'{name}.csv',index=False,encoding='utf-8-sig')
    print('\nOverall target-equal means:',flush=True)
    print(overall.to_string(index=False,float_format=lambda v:f'{v:.4f}'),flush=True)
    print('\nH+L+graph smoothing minus random+ordinary:',flush=True)
    print(differences.to_string(index=False,float_format=lambda v:f'{v:+.4f}'),flush=True)


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--project-dir',type=Path,default=Path(__file__).resolve().parents[2])
    parser.add_argument('--data-root',type=Path,default=Path('./datasets'))
    parser.add_argument('--baseline-dir',type=Path)
    parser.add_argument('--previous-graph-dir',type=Path)
    parser.add_argument('--dataset',choices=['paper','ReLink','AEEEM','JIRA','PROMISE','Kamei'],default='paper')
    parser.add_argument('--target')
    parser.add_argument('--seeds',nargs='+',type=int,default=list(range(30)))
    parser.add_argument('--output-dir',type=Path)
    args=parser.parse_args();args.seeds=list(dict.fromkeys(args.seeds))
    args.project_dir=args.project_dir.resolve();args.data_root=args.data_root.resolve()
    sys.path.insert(0,str(args.project_dir))
    from dataset_loader import FAMILIES,project_paths
    families=list(FAMILIES[:5]) if args.dataset=='paper' else [args.dataset]
    paths=[p for f in families for p in project_paths(args.data_root,f)]
    expected={(f,p.stem,s) for f in families for p in project_paths(args.data_root,f)
              if not args.target or p.stem.lower()==args.target.lower() for s in args.seeds}
    if not expected:parser.error('No matching target project.')
    data_hashes={str(p):sha(p) for p in paths}
    modules=[args.project_dir/f for f in ['selection.py','graph_lr.py','graph_tuning.py',
        'transfer_baselines.py','dataset_loader.py','budget_graph_selection.py']]
    modules+=sorted((args.project_dir/'experiments').glob('*.py'))
    code_hash=hashlib.sha256(b''.join(p.read_bytes() for p in modules)).hexdigest()
    here=Path(__file__).resolve().parent
    output=(args.output_dir or args.project_dir/'results/rf_dt_graph_smoothing_30seeds_20261123').resolve()
    old_base=(args.baseline_dir or args.project_dir/'results/selection_classifier_25_seed0_20261123').resolve()
    old_graph=(args.previous_graph_dir or args.project_dir/'results/hl_graph_smoothing_vs_random_seed0_20261123').resolve()
    output.mkdir(parents=True,exist_ok=True)
    log_path=output/'warm_start_log.json'
    logs=json.loads(log_path.read_text(encoding='utf-8')) if log_path.exists() else {}
    for classifier in CLASSIFIERS:
        for graph in [False,True]:
            method=f'hl25_graphsmooth_{classifier}' if graph else f'random25_{classifier}'
            worker='hl_graph_control.py' if graph else 'classifier_control.py'
            folder=output/method
            files=[here/worker,here/'classifier_control.py',here/'graph_smoothing.py'] if graph else [here/worker]
            fingerprint=hashlib.sha256(b''.join(p.read_bytes() for p in files)).hexdigest()
            record=import_compatible_runs((old_graph if graph else old_base)/method,folder,method,
                classifier,graph,args,expected,code_hash,data_hashes,fingerprint)
            if record['imported'] or method not in logs:logs[method]=record
            log_path.write_text(json.dumps(logs,ensure_ascii=False,indent=2),encoding='utf-8')
            print(f'\n{method}: {record["status"]}; imported={record["imported"]}',flush=True)
            command=[sys.executable,'-B',str(here/worker),'--project-dir',str(args.project_dir),
                '--data-root',str(args.data_root),'--dataset',args.dataset,'--classifier',classifier,
                '--output-dir',str(folder),'--budget-fraction','.25','--low-fraction','.2','--target-regions','5',
                '--seeds',*[str(s) for s in args.seeds]]
            if not graph:command+=['--selection','random']
            if args.target:command+=['--target',args.target]
            subprocess.run(command,check=True)
    summarize(output,expected,args.seeds)
    print(f'\nSaved: {output}',flush=True)


if __name__=='__main__':main()
