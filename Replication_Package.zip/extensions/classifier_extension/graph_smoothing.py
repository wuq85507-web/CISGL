"""Probability smoothing on the existing source-scaled target graph."""
import numpy as np
from scipy import sparse
from scipy.sparse.linalg import cg
from selection import compress
from graph_lr import target_graph


def build_laplacian(source_pool, target, neighbors):
    left, right, weights = target_graph(compress(source_pool), compress(target), neighbors)
    n = len(target)
    if not len(weights) or weights.sum() <= 0:
        return sparse.csr_matrix((n, n)), dict(edges=0, mean_weighted_degree=0.)
    W = sparse.coo_matrix((np.r_[weights, weights],
        (np.r_[left, right], np.r_[right, left])), shape=(n, n)).tocsr()
    degree = np.asarray(W.sum(axis=1)).ravel()
    scale = float(degree.mean())
    L = (sparse.diags(degree)-W)/scale
    return L.tocsr(), dict(edges=len(weights), mean_weighted_degree=scale,
        neighbors=min(neighbors, max(0, n-1)), scaling='L divided by mean weighted degree')


def smooth_probability(probability, laplacian, strength):
    """Minimize ||q-p||^2 + strength*q.T@L@q, with no class labels."""
    p = np.asarray(probability, dtype=float)
    if not np.isfinite(strength) or strength < 0:
        raise ValueError('Smoothing strength must be finite and nonnegative.')
    if laplacian.shape != (len(p), len(p)) or not np.isfinite(p).all():
        raise ValueError('Probability/graph shape mismatch or invalid probabilities.')
    if strength == 0 or laplacian.nnz == 0:
        return p.copy(), dict(solver='identity', relative_residual=0., iterations=0,
            mean_absolute_probability_change=0., energy_before=0., energy_after=0.)
    A = sparse.eye(len(p), format='csr') + strength*laplacian
    preconditioner = sparse.diags(1./A.diagonal())
    iterations = [0]
    def count(_): iterations[0] += 1
    q, info = cg(A, p, x0=p, rtol=1e-9, atol=1e-11,
                 maxiter=5000, M=preconditioner, callback=count)
    residual = float(np.linalg.norm(A@q-p)/max(np.linalg.norm(p), 1.))
    if info != 0 or not np.isfinite(q).all() or residual > 1e-8:
        raise RuntimeError(f'Graph smoothing did not converge: info={info}, residual={residual}')
    if q.min() < -1e-7 or q.max() > 1+1e-7:
        raise RuntimeError('Graph smoothing produced probabilities outside [0,1].')
    q = np.clip(q, 0., 1.)
    return q, dict(solver='preconditioned sparse CG', relative_residual=residual,
        iterations=iterations[0], mean_absolute_probability_change=float(np.mean(np.abs(q-p))),
        energy_before=float(p@(laplacian@p)), energy_after=float(q@(laplacian@q)))
