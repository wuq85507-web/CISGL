"""H+L -> ordinary LR/RF/DT -> target probability smoothing."""
import argparse
import hashlib
import json
from pathlib import Path
import time

# The unchanged previous control module supplies the selection and classifiers.
from classifier_control import (PROJECT, np, compress, positive_probability,
    candidates as base_candidates, fit_classifier, select_sources, Result, run_cli)
from sklearn.metrics import roc_auc_score, matthews_corrcoef
from graph_smoothing import build_laplacian, smooth_probability


def grid(args):
    strengths = list(dict.fromkeys(float(x) for x in args.smooth_lambda_grid))
    neighbors = list(dict.fromkeys(int(x) for x in args.smooth_neighbor_grid))
    if not strengths or not np.isfinite(strengths).all() or min(strengths) < 0 or not neighbors or min(neighbors) < 1:
        raise ValueError('Invalid graph smoothing candidates.')
    return [dict(base=base, base_index=i, strength=strength,
                 neighbors=0 if strength == 0 else k)
            for i, base in enumerate(base_candidates(args.classifier))
            for strength in strengths
            for k in ([0] if strength == 0 else neighbors)]


def tune(X, y, groups, args):
    settings = grid(args)
    folds = []
    for held_out in np.unique(groups):
        train, valid = groups != held_out, groups == held_out
        if train.sum() < 2 or np.unique(y[valid]).size < 2:
            continue
        source, labels, target = X[train], y[train], X[valid]
        chosen, _, _, _ = select_sources('hl', source, labels, groups[train], target, 0, args)
        # Fit only three base models per fold; reuse probabilities across graph settings.
        probabilities = {}
        for i, base in enumerate(base_candidates(args.classifier)):
            model = fit_classifier(args.classifier, compress(source[chosen]), labels[chosen], 0, base, args)
            probabilities[i] = positive_probability(model, compress(target))
        graphs = {k: build_laplacian(source, target, k)[0]
                  for k in {s['neighbors'] for s in settings if s['strength'] > 0}}
        for i, setting in enumerate(settings):
            p = probabilities[setting['base_index']]
            q = (p if setting['strength'] == 0 else
                 smooth_probability(p, graphs[setting['neighbors']], setting['strength'])[0])
            folds.append(dict(held_out_source=int(held_out), candidate_index=i,
                auc=float(roc_auc_score(y[valid], q)),
                mcc=float(matthews_corrcoef(y[valid], q >= .5))))
    if not folds:
        raise ValueError('No eligible source-LOPO fold; target labels cannot be used for tuning.')
    summaries = []
    for i, setting in enumerate(settings):
        scores = [r for r in folds if r['candidate_index'] == i]
        summaries.append(dict(setting, candidate_index=i, folds=len(scores),
            auc=float(np.mean([r['auc'] for r in scores])),
            mcc=float(np.mean([r['mcc'] for r in scores]))))
    best = max(summaries, key=lambda r: (r['auc'], r['mcc'], -r['strength'],
                                        -r['neighbors'], -r['base_index']))
    return dict(best={k:best[k] for k in ['base','base_index','strength','neighbors']},
        candidates=summaries, folds=folds, target_labels_used=False,
        protocol='source-project LOPO; mean AUC, then MCC, smaller strength, smaller k, first base candidate; seed=0',
        objective='||q-p||^2 + lambda*q.T@L_scaled@q; L_scaled=(D-W)/mean_degree')


def prepare(X, y, groups, args, cache):
    if cache.exists():
        return json.loads(cache.read_text(encoding='utf-8'))['best']
    print(f'Source LOPO tuning: H+L+{args.classifier}+graph smoothing; {len(grid(args))} candidates', flush=True)
    start = time.perf_counter()
    result = tune(X, y, groups, args); result['seconds'] = time.perf_counter()-start
    cache.parent.mkdir(parents=True, exist_ok=True)
    cache.write_text(json.dumps(result, indent=2), encoding='utf-8')
    return result['best']


def run(X, y, groups, T, seed, args, settings):
    chosen, distance, uncertainty, audit = select_sources('hl', X, y, groups, T, seed, args)
    model = fit_classifier(args.classifier, compress(X[chosen]), y[chosen], seed, settings['base'], args)
    p = positive_probability(model, compress(T))
    if settings['strength'] > 0:
        L, graph_audit = build_laplacian(X, T, settings['neighbors'])
        q, solver = smooth_probability(p, L, settings['strength'])
    else:
        q = p.copy(); graph_audit = dict(edges=0); solver = dict(solver='identity selected by source validation')
    training = dict(classifier=args.classifier, c=settings['base'].get('c'), beta=0.,
        neighbors=settings['neighbors'], tuning='source_lopo', parameters=settings['base'],
        graph_regularization=False, graph_smoothing=True, smoothing_lambda=settings['strength'],
        class_weight='balanced', n_estimators=200 if args.classifier=='rf' else None,
        graph=graph_audit, smoothing_solver=solver,
        objective='||q-p||^2 + lambda*q.T@L_scaled@q; L_scaled=(D-W)/mean_degree',
        target_labels_used=False)
    return Result(q, chosen, np.ones(len(chosen)), training=training,
                  selection=audit, distance=distance, uncertainty=uncertainty)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(add_help=False)
    parser.add_argument('--classifier', choices=['lr','rf','dt'], required=True)
    selected, _ = parser.parse_known_args()
    method = f'hl25_graphsmooth_{selected.classifier}'
    def configure(parser):
        parser.add_argument('--selection', choices=['hl'], default='hl')
        parser.add_argument('--classifier', choices=['lr','rf','dt'], required=True)
        parser.add_argument('--smooth-lambda-grid', nargs='+', type=float, default=[0., .1, 1., 10.])
        parser.add_argument('--smooth-neighbor-grid', nargs='+', type=int, default=[5,10])
        paths=[Path(__file__),Path(__file__).with_name('classifier_control.py'),Path(__file__).with_name('graph_smoothing.py')]
        parser.set_defaults(runner_sha256=hashlib.sha256(b''.join(p.read_bytes() for p in paths)).hexdigest(),
                            project_dir=str(PROJECT))
    run_cli(method, run, dict(budget_fraction=.25, low_fraction=.2, target_regions=5,
        graph_tuning='source_lopo', graph_beta=0., graph_beta_grid=[0.], graph_neighbors=1,
        graph_neighbor_grid=[1], graph_c_grid=[.1,1.,10.]), prepare=prepare, configure=configure)
