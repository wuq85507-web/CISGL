"""Fixed 25% selection controls with LR, RF, and DT; no graph term."""
import argparse
import hashlib
import json
from pathlib import Path
import sys
import time

# Reuse the package's data, selection, scoring, and output code.
bootstrap = argparse.ArgumentParser(add_help=False)
bootstrap.add_argument('--project-dir', type=Path, default=Path(__file__).resolve().parents[2])
bootstrap_args, remaining = bootstrap.parse_known_args()
PROJECT = bootstrap_args.project_dir.resolve()
if not (PROJECT/'selection.py').is_file():
    raise FileNotFoundError(f'Existing experiment project not found: {PROJECT}')
sys.path.insert(0, str(PROJECT))
sys.argv = [sys.argv[0], *remaining]

import numpy as np
from sklearn.dummy import DummyClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import roc_auc_score, matthews_corrcoef
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.tree import DecisionTreeClassifier
from selection import compress, fit_lr, positive_probability
from experiments.common import Result, run_cli
from experiments.fair_ablation_support import select as select_ablation
from experiments.selection_support import coverage_inputs


def select_sources(rule, X, y, groups, T, seed, args):
    if rule == 'random':
        return select_ablation('random', X, y, groups, T, seed, args)
    ctx = coverage_inputs(X, y, groups, T, seed, args, need_uncertainty=True)
    supplement = ctx.remaining[np.argsort(-ctx.uncertainty[ctx.remaining], kind='stable')[:ctx.n_low]]
    chosen = np.r_[ctx.high, supplement]
    audit = dict(ctx.audit, rule='regional coverage H plus project-grouped OOF uncertainty L')
    assert len(chosen) == ctx.budget == len(np.unique(chosen))
    return chosen, ctx.distance, ctx.uncertainty, audit


def candidates(classifier):
    if classifier == 'lr':
        return [{'c': c} for c in (.1, 1., 10.)]
    return [{'min_samples_leaf': leaf} for leaf in (1, 5, 10)]


def fit_classifier(classifier, X, y, seed, params, args):
    if classifier == 'lr':
        return fit_lr(X, y, seed, c=params['c'])
    if len(np.unique(y)) < 2:
        estimator = DummyClassifier(strategy='prior')
    elif classifier == 'rf':
        estimator = RandomForestClassifier(
            n_estimators=200, criterion='gini', max_depth=None,
            min_samples_leaf=params['min_samples_leaf'], max_features='sqrt',
            bootstrap=True, class_weight='balanced', random_state=seed, n_jobs=4)
    else:
        estimator = DecisionTreeClassifier(
            criterion='gini', splitter='best', max_depth=None,
            min_samples_leaf=params['min_samples_leaf'], max_features=None,
            class_weight='balanced', random_state=seed)
    return make_pipeline(StandardScaler(), estimator).fit(X, y)


def tune(X, y, groups, args):
    """Only source projects enter this function; target labels are unavailable."""
    grid = candidates(args.classifier)
    folds = []
    for held_out in np.unique(groups):
        train, valid = groups != held_out, groups == held_out
        if np.unique(y[valid]).size < 2 or train.sum() < 2:
            continue
        sx, sy, sg, pseudo_target = X[train], y[train], groups[train], X[valid]
        chosen, _, _, _ = select_sources(args.selection, sx, sy, sg, pseudo_target, 0, args)
        source, target = compress(sx[chosen]), compress(pseudo_target)
        for candidate_index, params in enumerate(grid):
            model = fit_classifier(args.classifier, source, sy[chosen], 0, params, args)
            probability = positive_probability(model, target)
            folds.append(dict(held_out_source=int(held_out), candidate_index=candidate_index,
                parameters=params, selected_samples=len(chosen),
                auc=float(roc_auc_score(y[valid], probability)),
                mcc=float(matthews_corrcoef(y[valid], probability >= .5))))
    if not folds:
        raise ValueError('No eligible two-class source-LOPO fold; no target-label fallback is used.')
    summaries = []
    for i, params in enumerate(grid):
        scores = [r for r in folds if r['candidate_index'] == i]
        summaries.append(dict(candidate_index=i, parameters=params, folds=len(scores),
            auc=float(np.mean([r['auc'] for r in scores])),
            mcc=float(np.mean([r['mcc'] for r in scores]))))
    best = max(summaries, key=lambda r: (r['auc'], r['mcc'], -r['candidate_index']))
    return dict(best=best['parameters'], candidates=summaries, folds=folds,
        protocol='source-project LOPO; mean AUC, then MCC; exact ties use first listed candidate; selection and fit seed=0',
        target_labels_used=False, selection=args.selection, classifier=args.classifier)


def prepare(X, y, groups, args, cache):
    if cache.exists():
        return json.loads(cache.read_text(encoding='utf-8'))['best']
    print(f'Source LOPO tuning: {args.selection}+{args.classifier}; 3 candidates', flush=True)
    started = time.perf_counter()
    record = tune(X, y, groups, args)
    record['seconds'] = time.perf_counter()-started
    cache.parent.mkdir(parents=True, exist_ok=True)
    cache.write_text(json.dumps(record, ensure_ascii=False, indent=2), encoding='utf-8')
    return record['best']


def run(X, y, groups, T, seed, args, settings):
    chosen, distance, uncertainty, audit = select_sources(args.selection, X, y, groups, T, seed, args)
    model = fit_classifier(args.classifier, compress(X[chosen]), y[chosen], seed, settings, args)
    probability = positive_probability(model, compress(T))
    training = dict(classifier=args.classifier, c=settings.get('c'), beta=0., neighbors=0,
        tuning='source_lopo', parameters=settings, graph_regularization=False,
        class_weight='balanced', auxiliary_model='original project-grouped OOF LR, C=1',
        n_estimators=200 if args.classifier == 'rf' else None)
    return Result(probability, chosen, np.ones(len(chosen)), training=training,
                  selection=audit, distance=distance, uncertainty=uncertainty)


if __name__ == '__main__':
    pre = argparse.ArgumentParser(add_help=False)
    pre.add_argument('--selection', choices=['random', 'hl'], required=True)
    pre.add_argument('--classifier', choices=['lr', 'rf', 'dt'], required=True)
    selected, _ = pre.parse_known_args()
    method = f'{selected.selection}25_{selected.classifier}'
    def configure(parser):
        parser.add_argument('--selection', choices=['random', 'hl'], required=True)
        parser.add_argument('--classifier', choices=['lr', 'rf', 'dt'], required=True)
        parser.set_defaults(runner_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                            project_dir=str(PROJECT))
    run_cli(method, run, dict(budget_fraction=.25, low_fraction=.2, target_regions=5,
        graph_tuning='source_lopo', graph_beta=0., graph_beta_grid=[0.],
        graph_neighbors=1, graph_neighbor_grid=[1], graph_c_grid=[.1, 1., 10.]),
        prepare=prepare, configure=configure)
