"""MDA-M, Sun et al., IET Software 14(7), 825--838.

Paper Eq. (11) is authoritative: the constraint is Z H Z^T, not the
uncentered Z Z^T in the released MDA.m. No extra pseudo-label iterations.
Preprocessing and otherwise unspecified dimensions follow the author demo.
"""
import numpy as np
from scipy.linalg import eigh, svd
from scipy.sparse import coo_matrix, diags
from sklearn.linear_model import LogisticRegression
from sklearn.neighbors import NearestNeighbors


def preprocess_project(X):
    """Author demo: divide each row by its sum, then population z-score."""
    X = np.asarray(X, dtype=float)
    if X.ndim != 2 or not np.isfinite(X).all():
        raise ValueError('MDA requires a finite metric matrix.')
    totals = X.sum(axis=1)
    if np.any(totals == 0):
        raise ValueError('Author MDA preprocessing is undefined for a zero-sum metric row.')
    divided = X/totals[:, None]
    scale = divided.std(axis=0, ddof=0)
    # MATLAB zscore maps constant columns to zero.
    scale[scale == 0] = 1.
    return (divided-divided.mean(axis=0))/scale


def gfk_kernel(source, target, dimension=5):
    """Analytic geodesic-flow integral using PCA principal vectors.

    This is equivalent to the author's GSVD construction, with the exact
    continuous limit when an angle is zero. PCA centers for learning bases;
    the resulting kernel subsequently maps the supplied metric vectors.
    """
    source, target = np.asarray(source, float), np.asarray(target, float)
    d = source.shape[1]
    if target.shape[1] != d or not 0 < dimension < d/2:
        raise ValueError('GFK requires matching features and 0 < manifold dimension < d/2.')
    if min(len(source)-1, len(target)-1) < dimension:
        raise ValueError('Too few observations for the specified GFK PCA dimension.')
    _, _, source_vt = svd(source-source.mean(axis=0), full_matrices=False)
    _, _, target_vt = svd(target-target.mean(axis=0), full_matrices=False)
    source_basis, target_basis = source_vt[:dimension].T, target_vt[:dimension].T
    U, cosines, Vt = svd(source_basis.T@target_basis)
    cosines = np.clip(cosines, 0., 1.)
    angles = np.arccos(cosines)
    left = source_basis@U
    residual = target_basis@Vt.T-left*cosines
    sines = np.sin(angles)
    right = np.zeros_like(left)
    nonzero = sines > 1e-8
    right[:, nonzero] = residual[:, nonzero]/sines[nonzero]
    # np.sinc(t) = sin(pi*t)/(pi*t), including its correct limit at zero.
    sine_ratio = np.sinc(2*angles/np.pi)
    b1, b4 = .5*(1+sine_ratio), .5*(1-sine_ratio)
    cross = np.zeros_like(angles)
    cross[nonzero] = (1-np.cos(2*angles[nonzero]))/(4*angles[nonzero])
    G = (left*b1)@left.T+(right*b4)@right.T
    G += (left*cross)@right.T+(right*cross)@left.T
    return (G+G.T)/2, angles


def gfk_map(source, target, dimension=5):
    G, angles = gfk_kernel(source, target, dimension)
    values, vectors = eigh(G)
    if values.min() < -1e-10:
        raise ValueError('GFK matrix is not positive semidefinite.')
    # Principal PSD square root; avoids complex roundoff in matrix powers.
    root = (vectors*np.sqrt(np.maximum(values, 0.)))@vectors.T
    return source@root, target@root, dict(
        manifold_dimension=dimension, principal_angles=angles.tolist(),
        gfk_eigenvalues=values.tolist())


def normalize_rows(X):
    lengths = np.linalg.norm(X, axis=1)
    if np.any(lengths == 0):
        raise ValueError('MDA row normalization encountered a zero vector.')
    return X/lengths[:, None]


def cosine_graph(points, neighbors=5, block_size=128):
    """Author lapgraph: exact cosine kNN, k+1 including self, union/max.

    Work in blocks without constructing a dense N-by-N matrix. Boundary
    ties keep input order, like MATLAB's stable sort. Self loops are retained.
    Negative weights are not silently clipped.
    """
    points = normalize_rows(np.asarray(points, float))
    n = len(points)
    if not 0 < neighbors < n or block_size < 1:
        raise ValueError('Invalid graph neighborhood or block size.')
    count = neighbors+1
    columns, weights = [], []
    for start in range(0, n, block_size):
        similarity = points[start:start+block_size]@points.T
        for row in similarity:
            boundary = np.partition(row, n-count)[n-count]
            above = np.flatnonzero(row > boundary)
            ties = np.flatnonzero(row == boundary)[:count-len(above)]
            chosen = np.sort(np.r_[above, ties])
            chosen = chosen[np.argsort(-row[chosen], kind='stable')]
            columns.append(chosen)
            weights.append(row[chosen])
    rows = np.repeat(np.arange(n), count)
    W = coo_matrix((np.concatenate(weights), (rows, np.concatenate(columns))), shape=(n, n)).tocsr()
    W = W.maximum(W.T)
    degree = np.asarray(W.sum(axis=1)).ravel()
    # Paper Eq. (8)--(9) explicitly defines L=D-W. The released code instead
    # uses the normalized Laplacian; do not import that different objective.
    L = diags(degree)-W
    return W, L


def joint_mmd_factors(labels, pseudo, mu=.6):
    """Paper Eq. (3): M=(1-mu)*e0 e0^T + mu*sum(ec ec^T).

    The mean embeddings in Eq. (3) determine the squared denominators in M.
    No extra class multiplier or Frobenius rescaling is present in that loss.
    """
    labels, pseudo = np.asarray(labels), np.asarray(pseudo)
    ns, nt = len(labels), len(pseudo)
    classes = np.unique(labels)
    if ns == 0 or nt == 0 or not 0 <= mu <= 1:
        raise ValueError('Invalid source/target size or mu.')
    columns = [np.sqrt(1-mu)*np.r_[np.full(ns, 1/ns), np.full(nt, -1/nt)]]
    for label in classes:
        source_mask, target_mask = labels == label, pseudo == label
        vector = np.zeros(ns+nt)
        vector[:ns][source_mask] = 1/source_mask.sum()
        if target_mask.any():
            vector[ns:][target_mask] = -1/target_mask.sum()
        columns.append(np.sqrt(mu)*vector)
    V = np.column_stack(columns)
    if not np.any(V):
        raise ValueError('Zero joint MMD matrix.')
    return V


def projection_system(points, labels, pseudo, laplacian, mu=.6, beta=.1, regularization=.1):
    """Paper Eq. (11), exactly factored MMD and sparse graph algebra."""
    V = joint_mmd_factors(labels, pseudo, mu)
    projected = points.T@V
    objective = projected@projected.T
    objective += beta*(points.T@(laplacian@points))
    objective += regularization*np.eye(points.shape[1])
    centered = points-points.mean(axis=0)
    constraint = centered.T@centered
    return (objective+objective.T)/2, (constraint+constraint.T)/2


def smallest_projection(objective, constraint, dimension=3):
    """Solve the finite generalized eigenproblem without adding a ridge.

    GFK maps into a low-rank subspace. The discarded nullspace has zero
    mapped observations and contributes no feasible prediction direction.
    """
    values, vectors = eigh(constraint)
    threshold = max(float(values.max()), 1.)*1e-12
    keep = values > threshold
    if dimension > keep.sum():
        raise ValueError(f'MDA projection dimension {dimension} exceeds constraint rank {keep.sum()}.')
    whitening = vectors[:, keep]/np.sqrt(values[keep])
    reduced = whitening.T@objective@whitening
    eigenvalues, directions = eigh((reduced+reduced.T)/2, subset_by_index=(0, dimension-1))
    A = whitening@directions
    residual = objective@A-(constraint@A)*eigenvalues
    relative = np.linalg.norm(residual)/max(np.linalg.norm(objective@A), 1e-15)
    if relative > 1e-6:
        raise ValueError(f'MDA generalized eigensystem residual too large: {relative}.')
    return A, dict(constraint_rank=int(keep.sum()), eigenvalues=eigenvalues.tolist(),
                   generalized_eigen_residual=float(relative))


def normalize_columns(X):
    lengths = np.linalg.norm(X, axis=0)
    if np.any(lengths == 0):
        raise ValueError('MDA post-projection normalization encountered a zero column.')
    return X/lengths


def predict_mda(source, labels, target, seed=0):
    """Many-to-one MDA; no target labels accepted by this interface."""
    labels = np.asarray(labels, dtype=int)
    if set(np.unique(labels)) != {0, 1}:
        raise ValueError('Published two-class MDA requires both source classes.')
    source, target = preprocess_project(source), preprocess_project(target)
    mapped_source, mapped_target, geometry = gfk_map(source, target, dimension=5)
    points = normalize_rows(np.vstack((mapped_source, mapped_target)))
    ns = len(source)
    pseudo = NearestNeighbors(n_neighbors=1, algorithm='brute', metric='euclidean', n_jobs=1).fit(
        points[:ns]).kneighbors(points[ns:], return_distance=False).ravel()
    pseudo = labels[pseudo]
    W, L = cosine_graph(points, neighbors=5)
    objective, constraint = projection_system(points, labels, pseudo, L)
    A, solver = smallest_projection(objective, constraint, dimension=3)
    # Follow released MDA.m: map GFK vectors before row normalization, then
    # independently normalize each projected source/target COLUMN to unit norm.
    fitted_source = normalize_columns(mapped_source@A)
    fitted_target = normalize_columns(mapped_target@A)
    model = LogisticRegression(solver='liblinear', C=1., penalty='l2',
        fit_intercept=False, class_weight=None, dual=False, tol=.01,
        max_iter=1000, random_state=seed).fit(fitted_source, labels)
    if np.any(model.n_iter_ >= 1000):
        raise ValueError('MDA LIBLINEAR did not converge within 1000 iterations.')
    positive = int(np.flatnonzero(model.classes_ == 1)[0])
    probabilities = model.predict_proba(fitted_target)[:, positive]
    detail = dict(protocol='MDA-M; paper Eq.11 centered constraint; author-demo preprocessing',
        beta=.1, regularization=.1, mu=.6, graph_neighbors=5, projection_dimension=3,
        classifier='liblinear_l2_logistic', c=1., fit_intercept=False,
        class_weight='none', tol=.01, pseudo_label_rounds=1,
        pseudo_positive_fraction=float(pseudo.mean()), graph_nonzeros=int(W.nnz),
        source_training_rows=len(labels), target_rows=len(target),
        target_labels_used=False, graph_laplacian='D-W: paper Eq.8',
        mmd_normalization='none: paper mean-embedding objective Eq.3',
        marginal_class_multiplier=1, **geometry, **solver)
    return probabilities, detail
