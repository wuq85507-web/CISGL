"""MDA-M on the existing 25-project benchmark, with original evaluation IO."""
import argparse
import hashlib
import sys
from pathlib import Path

import numpy as np


def main():
    bootstrap = argparse.ArgumentParser(add_help=False)
    bootstrap.add_argument('--project-root', type=Path,
                           default=Path(__file__).resolve().parents[2])
    options, remaining = bootstrap.parse_known_args()
    project_root = options.project_root.resolve()
    if not (project_root/'experiments'/'common.py').is_file():
        raise FileNotFoundError(f'Existing experiment project not found: {project_root}')
    sys.path.insert(0, str(project_root))
    from experiments.common import Result, run_cli
    from mda_core import predict_mda
    here = Path(__file__).resolve().parent
    implementation_hash = hashlib.sha256((here/'mda_core.py').read_bytes()+Path(__file__).read_bytes()).hexdigest()

    def run(X, y, groups, T, seed, args, settings):
        if args.budget is not None or args.budget_fraction != 1.:
            raise ValueError('MDA receives the full source pool; no 25% input or final-budget cap.')
        probability, detail = predict_mda(X, y, T, seed)
        return Result(probability, np.arange(len(X)), np.ones(len(X)),
            training=dict(detail, tuning='fixed paper/demo settings; no target-label tuning'),
            selection=dict(rule='pool all compatible source projects: paper MDA-M setting',
                source_pool=len(X), original_training_rows=len(X), generated_rows=0,
                preprocessing='row-sum normalization then independent population z-score',
                target_labels_used=False,
                paper_code_difference='paper Eq.3 unrescaled MMD; Eq.8 D-W; Eq.11 ZHZ^T',
                implementation='Python paper-equation implementation; not MATLAB bitwise reproduction'),
            balanced_class_weights=False)

    sys.argv = [sys.argv[0], *remaining]
    defaults = dict(budget_fraction=1., lr_c=1., mda_beta=.1, mda_lambda=.1,
        mda_mu=.6, mda_manifold_dimension=5, mda_projection_dimension=3,
        mda_neighbors=5, mda_pseudo_label_rounds=1,
        mda_implementation_sha256=implementation_hash,
        mda_reference='10.1049/iet-sen.2019.0389; Algorithm 1; Eq.3/8/9/11; MDA-M')
    run_cli('mda_paper_lr', run, defaults)


if __name__ == '__main__':
    main()
