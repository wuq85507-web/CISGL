"""RQ4: nine NASA comparisons; retain completed legacy runs and run missing IDs."""
import argparse
import csv
import hashlib
import json
import math
import os
from pathlib import Path
import statistics as st
import subprocess
import sys
import shutil

METRICS = ['auc', 'mcc', 'average_precision', 'f1']
METHODS = {
    'ascsa': ('ASCSA', 'ascsa_dnn_mmd'),
    'dssdpp': ('DSSDPP', 'dssdpp'),
    'ccpdp': ('CCPDP', 'ccpdp_lr'),
    'wbda': ('W-BDA+', 'wbda_plus_unsupervised_lr'),
    '3sw': ('3SW-MSTL', 'three_stage_mstl'),
    'mda': ('MDA', 'mda_paper_lr'),
    'kmm': ('KMM', 'kmm_lr'),
    'peters': ('Peters', 'peters_filter_lr'),
    'nearest': ('Nearest', 'nearest_budget_graph_lr'),
}
LEGACY = {
    'ccpdp': 'budget_transfer_nasa_d2_seed0/ccpdp_lr',
    'wbda': 'wbda_no_zscore_nasa_d2_30seeds_20261113/wbda_plus_unsupervised_lr',
    'nearest': 'nasa_d2_independent/nearest_budget_graph_lr',
}
EXECUTION_ORDER = ['ccpdp', 'wbda', 'nearest', 'mda', 'kmm', 'peters', '3sw', 'dssdpp', 'ascsa']


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read_csv(path):
    if not path.exists():
        return []
    with path.open(encoding='utf-8-sig', newline='') as stream:
        return list(csv.DictReader(stream))


def write_csv(path, rows):
    if not rows:
        return
    path.parent.mkdir(parents=True, exist_ok=True)
    fields = list(dict.fromkeys(k for row in rows for k in row))
    with path.open('w', encoding='utf-8-sig', newline='') as stream:
        writer = csv.DictWriter(stream, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def checked_rows(path, method, targets):
    result = {}
    for row in read_csv(path):
        if row['dataset'] != 'NASA_D2' or row['method'] != method or row['target'] not in targets:
            continue
        key = (row['target'], int(row['seed']))
        if key in result:
            raise ValueError(f'Duplicate run {key}: {path}')
        if any(row.get(m) in ('', None) or not math.isfinite(float(row[m])) for m in METRICS):
            raise ValueError(f'Incomplete four-metric result {key}: {path}')
        if int(row['target_samples']) != targets[row['target']]:
            raise ValueError(f'Target evaluation size changed: {key}, {path}')
        result[key] = dict(row, source_file=str(path.resolve()))
    return result


def merge_runs(existing, added):
    overlap = existing.keys() & added.keys()
    if overlap:
        raise ValueError(f'Legacy/new runs overlap: {sorted(overlap)}')
    return {**existing, **added}


def pending_groups(targets, seeds, completed):
    groups = {}
    for target in targets:
        missing = tuple(s for s in seeds if (target, s) not in completed)
        if missing:
            groups.setdefault(missing, []).append(target)
    return groups


def validate_legacy(folder, key, method, expected_hashes):
    config_path = folder / 'config.json'
    config = json.loads(config_path.read_text(encoding='utf-8'))
    if config.get('method') != method or config.get('dataset') != 'NASA_D2':
        raise ValueError(f'Legacy method/dataset mismatch: {folder}')
    recorded = {Path(p).name: value for p, value in config['data_hashes'].items()}
    if recorded != expected_hashes:
        raise ValueError(f'NASA data differ from legacy run: {folder}')
    fraction = .25 if key == 'nearest' else 1.
    if config.get('budget_fraction') != fraction or config.get('budget') is not None:
        raise ValueError(f'Legacy retention setting mismatch: {folder}')
    if config.get('lr_c', 1.) != 1.:
        raise ValueError(f'Legacy LR setting mismatch: {folder}')
    if key == 'nearest':
        fields = {'graph_tuning': 'source_lopo', 'graph_c_grid': [.1, 1., 10.],
                  'graph_beta_grid': [0., .03, .1, .3], 'graph_neighbor_grid': [5, 10]}
    else:
        fields = {'baseline_tuning': 'source_lopo', 'graph_c_grid': [.1, 1., 10.]}
        if key == 'wbda':
            fields['wbda_iterations'] = 10
    if any(config.get(k) != v for k, v in fields.items()):
        raise ValueError(f'Legacy validation setting mismatch: {folder}')
    return dict(path=str(config_path.resolve()), sha256=digest(config_path),
                recorded_code_hash=config.get('code_hash'))


def summarize(method_dir, label, method, combined, targets, seeds):
    selected = [dict(r) for (target, seed), r in sorted(combined.items())
                if target in targets and seed in seeds]
    write_csv(method_dir / 'combined_per_run_metrics.csv', selected)
    stats = method_dir / 'statistics'
    means, complete = [], []
    for target in targets:
        part = [r for r in selected if r['target'] == target]
        missing = sorted(set(seeds) - {int(r['seed']) for r in part})
        complete.append(dict(dataset='NASA_D2', target=target, method=method,
            requested_runs=len(seeds), recorded_runs=len(part), complete=not missing,
            missing_seeds='|'.join(map(str, missing))))
        if part:
            means.append(dict(dataset='NASA_D2', target=target, method=method,
                **{m: st.mean(float(r[m]) for r in part) for m in METRICS}))
    write_csv(stats / 'target_means.csv', means)
    write_csv(stats / 'completeness.csv', complete)
    if means:
        summary = dict(method=method, label=label, targets=len(means),
                       complete=all(r['complete'] for r in complete))
        for m in METRICS:
            values = [r[m] for r in means]
            summary[m] = st.mean(values)
            summary[m + '_std_across_targets'] = st.stdev(values) if len(values)>1 else ''
        write_csv(stats / 'summary.csv', [summary])
        return means, summary
    return [], None


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--project-root', type=Path, default=Path(__file__).resolve().parents[2])
    parser.add_argument('--data-root', type=Path, default=Path('./datasets'))
    parser.add_argument('--output-root', type=Path, required=True)
    parser.add_argument('--methods', nargs='+', choices=list(METHODS), default=list(METHODS))
    parser.add_argument('--seeds', nargs='+', type=int, default=list(range(30)))
    parser.add_argument('--target')
    parser.add_argument('--check-only', action='store_true')
    args = parser.parse_args()
    if len(set(args.methods)) != len(args.methods) or len(set(args.seeds)) != len(args.seeds) or min(args.seeds)<0:
        parser.error('Use distinct methods and nonnegative seeds.')
    project = args.project_root.resolve()
    sys.path.insert(0, str(project))
    from dataset_loader import load_family, project_paths
    projects = load_family(args.data_root, 'NASA_D2')
    targets = {p['name']:len(p['y']) for p in projects if not args.target or p['name']==args.target}
    if not targets:
        parser.error('No matching NASA target.')
    hashes = {p.name:digest(p) for p in project_paths(args.data_root, 'NASA_D2')}
    if 'mda' in args.methods:
        import numpy as np
        bad = [p['name'] for p in projects if np.any(p['X'].sum(axis=1)==0)]
        if bad:
            raise ValueError(f'MDA paper preprocessing has zero-sum rows in {bad}; no automatic deletion.')
    out = args.output_root.resolve()
    out.mkdir(parents=True, exist_ok=True)
    manifest_path = out/'resume_sources.json'
    manifest = json.loads(manifest_path.read_text(encoding='utf-8')) if manifest_path.exists() else {}
    summaries, all_means = [], []
    for key in sorted(args.methods, key=EXECUTION_ORDER.index):
        label, method = METHODS[key]
        dest = out/method
        native_file = dest/'per_run_metrics.csv'
        legacy_folder = project/'results'/LEGACY[key] if key in LEGACY else None
        legacy_rows, source_info = {}, {}
        if legacy_folder is not None and (legacy_folder/'per_run_metrics.csv').exists():
            source_info = validate_legacy(legacy_folder, key, method, hashes)
            legacy_rows = checked_rows(legacy_folder/'per_run_metrics.csv', method, targets)
        added = checked_rows(native_file, method, targets)
        combined = merge_runs(legacy_rows, added)
        pending = pending_groups(targets, args.seeds, combined)
        missing_count = sum(len(seeds)*len(names) for seeds,names in pending.items())
        print(f'{label}: {len(targets)*len(args.seeds)-missing_count} complete; '
              f'{missing_count} remaining.', flush=True)
        if args.check_only:
            continue
        dest.mkdir(parents=True, exist_ok=True)
        copied = []
        if legacy_folder is not None and pending:
            # Reuse the already selected source-only parameters without altering
            # old experiment files. Each copy is recorded with its source hash.
            for target in targets:
                src = legacy_folder/'tuning'/f'NASA_D2__{target}.json'
                dst = dest/'tuning'/src.name
                if src.exists() and not dst.exists():
                    dst.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copyfile(src, dst)
                    copied.append(dict(path=str(src.resolve()), sha256=digest(src)))
        manifest[method] = dict(legacy=source_info, legacy_result=str(legacy_folder/'per_run_metrics.csv') if legacy_rows else None,
            new_result=str(native_file), copied_tuning=copied or manifest.get(method,{}).get('copied_tuning',[]),
            policy='Legacy rows retain original signatures and paths; new runs are separate; target/seed identities merged only for summary.')
        manifest_path.write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
        for seeds,names in pending.items():
            batches = [None] if len(names)==len(targets) and not args.target else names
            for target in batches:
                command = [sys.executable,'-B']
                if key=='mda':
                    command += [str(Path(__file__).with_name('run_mda.py')),'--project-root',str(project)]
                else:
                    command += ['-m','experiments.'+method]
                command += ['--dataset','NASA_D2','--data-root',str(args.data_root.resolve()),
                    '--output-dir',str(dest),'--budget-fraction','.25' if key=='nearest' else '1',
                    '--seeds',*map(str,seeds)]
                if key=='dssdpp':
                    # RQ1's saved source_ranking uses 30 MMD feature draws.
                    # The current native default is corr, so pin the RQ1 variant.
                    command += ['--dssdpp-selection','mmd','--dssdpp-repeats','30',
                                '--dssdpp-bandwidth-limit','0']
                if target:
                    command += ['--target',target]
                print(f'Running {label}: '+(target or 'all NASA targets'),flush=True)
                env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',PYTHONUTF8='1')
                subprocess.run(command,cwd=project,env=env,check=True)
        combined = merge_runs(legacy_rows,checked_rows(native_file,method,targets))
        means, summary = summarize(dest,label,method,combined,targets,args.seeds)
        all_means += means
        if summary:
            summaries.append(summary)
        if not summary or not summary['complete']:
            raise RuntimeError(f'{label} is incomplete; resume with the same command.')
    if not args.check_only:
        method_order = {value[1]:i for i,value in enumerate(METHODS.values())}
        summaries.sort(key=lambda r:method_order[r['method']])
        all_means.sort(key=lambda r:(method_order[r['method']],r['target']))
        write_csv(out/'comparison_target_means.csv',all_means)
        write_csv(out/'comparison_summary.csv',summaries)
        print('Saved '+str(out/'comparison_summary.csv'),flush=True)


if __name__=='__main__':
    main()
