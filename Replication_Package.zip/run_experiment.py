"""Seventeen selection/learning arms; same-family multi-source leave-one-project-out CPDP."""
import argparse
import csv
import hashlib
import json
import time
from pathlib import Path

import numpy as np
from sklearn.metrics import (roc_auc_score, average_precision_score, matthews_corrcoef,
                             f1_score, precision_score, recall_score, accuracy_score)
from threadpoolctl import threadpool_limits

from dataset_loader import DEFAULT_ROOT, FAMILIES, load_family, project_paths
from selection import METHODS, select_all, compress, positive_probability
from selection import fit_lr
from graph_lr import GRAPH_METHODS, target_graph, fit_graph_lr
from graph_tuning import tune_graph
from transfer_baselines import TRANSFER_METHODS, baseline_prediction, scaled_metrics
from sklearn.neighbors import NearestNeighbors

BENCHMARK_METHODS = METHODS + GRAPH_METHODS + TRANSFER_METHODS


def write_csv(path, rows):
    if not rows:
        return
    with path.open('w', encoding='utf-8-sig', newline='') as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def score(y, p):
    prediction = p >= .5
    return dict(auc=float(roc_auc_score(y, p)) if len(np.unique(y)) == 2 else None,
                average_precision=float(average_precision_score(y, p)),
                mcc=float(matthews_corrcoef(y, prediction)), f1=float(f1_score(y, prediction, zero_division=0)),
                precision=float(precision_score(y, prediction, zero_division=0)),
                recall=float(recall_score(y, prediction, zero_division=0)),
                accuracy=float(accuracy_score(y, prediction)))


def source_unique(project):
    # Feature-only exact deduplication; keep first row, audit label conflicts.
    _, first, inverse = np.unique(project['X'], axis=0, return_index=True, return_inverse=True)
    first = np.sort(first)
    low = np.full(inverse.max()+1, 2)
    high = np.full(inverse.max()+1, -1)
    np.minimum.at(low, inverse, project['y'])
    np.maximum.at(high, inverse, project['y'])
    return first, int((low != high).sum())


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--data-root', type=Path, default=DEFAULT_ROOT)
    parser.add_argument('--dataset', choices=(*FAMILIES, 'paper', 'all'), default='ReLink')
    parser.add_argument('--target')
    parser.add_argument('--seeds', nargs='+', type=int, default=[0])
    parser.add_argument('--methods', nargs='+', choices=(*BENCHMARK_METHODS, 'all'), default=['all'])
    parser.add_argument('--graph-beta', type=float, default=.1)
    parser.add_argument('--graph-neighbors', type=int, default=10)
    parser.add_argument('--graph-tuning', choices=['source_lopo', 'fixed'], default='source_lopo')
    parser.add_argument('--graph-beta-grid', nargs='+', type=float, default=[0., .03, .1, .3])
    parser.add_argument('--graph-neighbor-grid', nargs='+', type=int, default=[5, 10])
    parser.add_argument('--graph-c', type=float, default=1.)
    parser.add_argument('--graph-c-grid', nargs='+', type=float, default=[.1, 1., 10.],
                        help='C grid for coverage_uncertainty_graph_lr only')
    parser.add_argument('--nn-filter-neighbors', type=int, default=10)
    parser.add_argument('--peters-cluster-size', type=int, default=10)
    parser.add_argument('--tca-dimension', type=int, default=10)
    parser.add_argument('--tca-mu', type=float, default=1.)
    parser.add_argument('--kmm-bound', type=float, default=10.)
    parser.add_argument('--kmm-landmarks', type=int, default=256)
    parser.add_argument('--kmm-exact-limit', type=int, default=1500,
                        help='RBF KMM exact up to this source size, Nystrom above it; recorded in audit')
    parser.add_argument('--budget-fraction', type=float, default=.5)
    parser.add_argument('--budget', type=int, help='Fixed K instead of budget fraction; capped at source pool size')
    parser.add_argument('--low-fraction', type=float, default=.2)
    parser.add_argument('--target-regions', type=int, default=5)
    parser.add_argument('--distance-quantiles', nargs=2, type=float, default=[.5, .95])
    parser.add_argument('--candidate-multiplier', type=float, default=3.)
    parser.add_argument('--information-ridge', type=float, default=1.,
                        help='Positive fixed ridge for the local Fisher information surrogate')
    parser.add_argument('--coverage-references', type=int, default=512,
                        help='Maximum uniform target reference samples for the gain objective')
    parser.add_argument('--output-dir', type=Path, default=Path('results/first_version'))
    args = parser.parse_args()
    vals = [args.budget_fraction, args.low_fraction, *args.distance_quantiles, args.candidate_multiplier]
    if (not np.isfinite(vals).all() or not 0 < args.budget_fraction <= 1
            or not 0 < args.low_fraction < 1 or args.target_regions < 1
            or not 0 <= args.distance_quantiles[0] < args.distance_quantiles[1] <= 1
            or (args.budget is not None and args.budget < 2)
            or args.candidate_multiplier < 1 or args.coverage_references < 1
            or not np.isfinite(args.information_ridge) or args.information_ridge <= 0
            or not np.isfinite(args.graph_beta) or args.graph_beta < 0 or args.graph_neighbors < 1
            or not np.isfinite(args.graph_beta_grid).all() or min(args.graph_beta_grid) < 0
            or min(args.graph_neighbor_grid) < 1
            or not np.isfinite(args.graph_c) or args.graph_c <= 0
            or not np.isfinite(args.graph_c_grid).all() or min(args.graph_c_grid) <= 0
            or args.nn_filter_neighbors < 1 or args.peters_cluster_size < 1
            or args.tca_dimension < 1 or not np.isfinite(args.tca_mu) or args.tca_mu <= 0
            or not np.isfinite(args.kmm_bound) or args.kmm_bound < 1
            or args.kmm_landmarks < 1 or args.kmm_exact_limit < 1):
        parser.error('Invalid budget, fraction, quantiles or region count.')
    families = list(FAMILIES[:5]) if args.dataset == 'paper' else list(FAMILIES) if args.dataset == 'all' else [args.dataset]
    methods = list(BENCHMARK_METHODS) if 'all' in args.methods else list(dict.fromkeys(args.methods))
    config = {k: v for k, v in vars(args).items() if k not in ('output_dir', 'seeds', 'target', 'methods')}
    config['data_root'] = str(args.data_root.resolve())
    config['code_hash'] = hashlib.sha256(b''.join((Path(__file__).parent / f).read_bytes()
        for f in ('selection.py', 'graph_lr.py', 'graph_tuning.py', 'transfer_baselines.py', 'dataset_loader.py', 'run_experiment.py'))).hexdigest()
    config['data_hashes'] = {str(p): hashlib.sha256(p.read_bytes()).hexdigest()
                             for family in families for p in project_paths(args.data_root, family)}
    signature = hashlib.sha256(json.dumps(config, sort_keys=True).encode()).hexdigest()[:16]
    args.output_dir.mkdir(parents=True, exist_ok=True)
    manifest = args.output_dir / 'config.json'
    if manifest.exists() and json.loads(manifest.read_text(encoding='utf-8')) != config:
        parser.error('Configuration/code/data changed; use a fresh output directory.')
    manifest.write_text(json.dumps(config, ensure_ascii=False, indent=2), encoding='utf-8')
    result_path = args.output_dir / 'per_run_metrics.csv'
    rows = list(csv.DictReader(result_path.open(encoding='utf-8-sig', newline=''))) if result_path.exists() else []
    done = {(r['dataset'], r['target'], int(r['seed']), r['method']) for r in rows}
    matched = False
    for family in families:
        projects = load_family(args.data_root, family)
        for target in projects:
            if args.target and target['name'].lower() != args.target.lower():
                continue
            matched = True
            sources = [p for p in projects if p is not target]
            Xs, ys, groups, source_rows, project_names, audits = [], [], [], [], [], []
            for j, source in enumerate(sources):
                indices, conflicts = source_unique(source)
                Xs.append(source['X'][indices]); ys.append(source['y'][indices])
                groups.extend([j]*len(indices)); project_names.extend([source['name']]*len(indices))
                source_rows.extend(source['row_indices'][indices].tolist())
                audits.append(dict(project=source['name'], original_rows=source['original_rows'],
                                   invalid_rows=source['invalid_rows'], retained=len(indices),
                                   duplicate_features_removed=len(source['X'])-len(indices), conflicting_feature_groups=conflicts))
            X, y, groups = np.vstack(Xs), np.concatenate(ys), np.asarray(groups)
            K = min(len(X), args.budget) if args.budget is not None else max(2, int(len(X)*args.budget_fraction))
            graph_settings = {}
            requested_graph = [m for m in methods if m in GRAPH_METHODS
                and any((family, target['name'], s, m) not in done for s in args.seeds)]
            if requested_graph and args.graph_tuning == 'source_lopo':
                cache = args.output_dir/'tuning'/f'{family}__{target["name"]}.json'
                graph_settings = json.loads(cache.read_text(encoding='utf-8')) if cache.exists() else {}
                missing = [m for m in requested_graph if m not in graph_settings]
                if missing:
                    print(f'Tuning source LOPO {family}/{target["name"]}: {len(missing)} graph method(s); reused across seeds', flush=True)
                    tuning_started = time.perf_counter()
                    tuned = tune_graph(X, y, groups, missing, budget=args.budget,
                        budget_fraction=args.budget_fraction, low_fraction=args.low_fraction,
                        regions=args.target_regions, quantiles=args.distance_quantiles,
                        candidate_multiplier=args.candidate_multiplier, information_ridge=args.information_ridge,
                        betas=args.graph_beta_grid, neighbors=list(dict.fromkeys(args.graph_neighbor_grid)),
                        c_grid=args.graph_c_grid)
                    for setting in tuned.values():
                        setting['tuning_seconds_batch'] = time.perf_counter()-tuning_started
                    graph_settings.update(tuned)
                    cache.parent.mkdir(exist_ok=True)
                    cache.write_text(json.dumps(graph_settings, indent=2), encoding='utf-8')
                for method in requested_graph:
                    print(f'  {method}: {graph_settings[method]["best"]}', flush=True)
            for seed in dict.fromkeys(args.seeds):
                todo = [m for m in methods if (family, target['name'], seed, m) not in done]
                if not todo:
                    print(f'Skip completed {family}/{target["name"]} seed={seed}', flush=True)
                    continue
                started = time.perf_counter()
                if any(m not in TRANSFER_METHODS for m in todo):
                    selections, distance, uncertainty, audit = select_all(
                        X, y, groups, target['X'], K, args.low_fraction, args.target_regions,
                        args.distance_quantiles, seed, candidate_multiplier=args.candidate_multiplier,
                        max_references=args.coverage_references,
                        include_gain=any(m in todo for m in METHODS[8:10]),
                        include_information='coverage_uncertainty_information' in todo,
                        information_ridge=args.information_ridge)
                else:
                    source_scaled, target_scaled = scaled_metrics(X, target['X'])
                    distance = NearestNeighbors(n_neighbors=1, n_jobs=1).fit(target_scaled).kneighbors(source_scaled)[0][:, 0]
                    uncertainty = np.full(len(X), np.nan)
                    selections, audit = {}, dict(budget=K, high_size=0, oof_protocol='not needed for external baselines')
                prep_seconds = time.perf_counter()-started
                needed_k = {graph_settings[m]['best']['neighbors'] if m in graph_settings else args.graph_neighbors
                            for m in todo if m in GRAPH_METHODS}
                edges = {k: target_graph(compress(X), compress(target['X']), k) for k in needed_k}
                detail = args.output_dir / 'runs' / f'{family}__{target["name"]}__seed{seed}'
                detail.mkdir(parents=True, exist_ok=True)
                audit.update(sources=audits, target_rows=len(target['X']),
                             target_invalid_rows=target['invalid_rows'], target_duplicates_retained=True,
                             features=target['features'], source_count=len(sources),
                             selection_seconds=prep_seconds)
                (detail/'audit.json').write_text(json.dumps(audit, indent=2), encoding='utf-8')
                print(f'[{family}/{target["name"]}] seed={seed} pool={len(X)} K={K}', flush=True)
                for method in todo:
                    started = time.perf_counter()
                    selection_method = {'all_source_graph_lr': 'all_source',
                        'coverage_uncertainty_graph_lr': 'coverage_uncertainty'}.get(method, method)
                    chosen = selections.get(selection_method)
                    training_audit = {}
                    beta, neighbors = args.graph_beta, args.graph_neighbors
                    c = args.graph_c if method == 'coverage_uncertainty_graph_lr' else 1.
                    if method in TRANSFER_METHODS:
                        probability, chosen, sample_weights, training_audit = baseline_prediction(
                            method, X, y, target['X'], seed,
                            nn_neighbors=args.nn_filter_neighbors, peters_size=args.peters_cluster_size,
                            tca_dimension=args.tca_dimension, tca_mu=args.tca_mu,
                            kmm_bound=args.kmm_bound, kmm_landmarks=args.kmm_landmarks,
                            kmm_exact_limit=args.kmm_exact_limit)
                    elif method in GRAPH_METHODS:
                        if method in graph_settings:
                            beta = graph_settings[method]['best']['beta']
                            neighbors = graph_settings[method]['best']['neighbors']
                            c = graph_settings[method]['best']['c']
                        model, training_audit = fit_graph_lr(compress(X[chosen]), y[chosen],
                            compress(target['X']), edges[neighbors], seed, beta, c=c)
                        training_audit.update(tuning=args.graph_tuning, neighbors=neighbors)
                    else:
                        model = fit_lr(compress(X[chosen]), y[chosen], seed)
                    (detail/f'{method}_training.json').write_text(json.dumps(training_audit, indent=2), encoding='utf-8')
                    if method not in TRANSFER_METHODS:
                        probability = positive_probability(model, compress(target['X']))
                        sample_weights = np.ones(len(chosen))
                    metrics = score(target['y'], probability)
                    classes = len(np.unique(y[chosen]))
                    class_counts = np.bincount(y[chosen].astype(int), minlength=2)
                    effective = sample_weights*(len(chosen)/(2*class_counts[y[chosen].astype(int)]) if classes == 2 else 1.)
                    row = dict(signature=signature, dataset=family, target=target['name'], seed=seed,
                               method=method, classifier='graph_lr' if method in GRAPH_METHODS else 'lr',
                               graph_beta=beta if method in GRAPH_METHODS else 0.,
                               lr_c=c,
                               graph_neighbors=neighbors if method in GRAPH_METHODS else 0,
                               graph_tuning=args.graph_tuning if method in GRAPH_METHODS else 'none',
                               threshold=.5, source_samples=len(X),
                               selected_samples=len(chosen), selected_defect_ratio=float(y[chosen].mean()),
                               weighted_defect_ratio=float(np.dot(effective, y[chosen])/effective.sum()),
                               single_class_support=classes == 1, target_samples=len(target['X']),
                               budget=K, low_fraction=args.low_fraction, selection_seconds=prep_seconds,
                               seconds=time.perf_counter()-started, **metrics)
                    write_csv(detail/f'{method}_selection.csv', [dict(
                        pool_index=int(i), project=project_names[i], input_row=int(source_rows[i]),
                        sample_weight=float(sample_weights[pos]),
                        label=int(y[i]), target_distance=float(distance[i]), oof_uncertainty=float(uncertainty[i]),
                        role=('all' if selection_method == 'all_source' else 'H' if method.startswith('coverage_')
                              and method != 'coverage_budget' and pos < audit['high_size'] else 'L'
                              if method.startswith('coverage_') and method != 'coverage_budget' else 'selected'))
                        for pos, i in enumerate(chosen)])
                    write_csv(detail/f'{method}_predictions.csv', [dict(input_row=int(i), label=int(a),
                        probability=float(b), prediction=int(b >= .5))
                        for i, a, b in zip(target['row_indices'], target['y'], probability)])
                    rows.append(row); write_csv(result_path, rows)
                    done.add((family, target['name'], seed, method))
                    print(f'  {method}: AUC={metrics["auc"]} MCC={metrics["mcc"]:.4f} F1={metrics["f1"]:.4f}', flush=True)
    if not matched:
        parser.error('No target matched the selected dataset.')
    print(f'Saved {result_path.resolve()}')


if __name__ == '__main__':
    with threadpool_limits(limits=4):
        main()
