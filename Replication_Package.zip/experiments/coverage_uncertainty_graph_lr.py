"""Target coverage H + uncertain L -> target graph -> graph LR -> probabilities."""
import numpy as np
from selection import compress, positive_probability
from graph_lr import target_graph, fit_graph_lr
from experiments.common import Result, run_cli
from experiments.graph_support import parameters
from experiments.selection_support import coverage_inputs

METHOD = 'coverage_uncertainty_graph_lr'
DEFAULTS = dict(graph_tuning='source_lopo', graph_c=1.,
                graph_c_grid=[.1, 1., 10.], graph_beta_grid=[0., .03, .1, .3],
                graph_neighbor_grid=[5, 10])


def prepare(X, y, groups, args, cache):
    return parameters(METHOD, X, y, groups, args, cache)


def run(X, y, groups, T, seed, args, settings):
    context = coverage_inputs(X, y, groups, T, seed, args, need_uncertainty=True)
    supplement = context.remaining[np.argsort(-context.uncertainty[context.remaining], kind='stable')[:context.n_low]]
    chosen = np.r_[context.high, supplement]
    distance, uncertainty, audit = context.distance, context.uncertainty, context.audit
    beta, k, c = settings['beta'], settings['neighbors'], settings['c']
    source, target = compress(X), compress(T)
    edges = target_graph(source, target, k)
    model, training = fit_graph_lr(source[chosen], y[chosen], target, edges, seed, beta, c=c)
    training.update(classifier='graph_lr', neighbors=k, tuning=args.graph_tuning)
    return Result(positive_probability(model, target), chosen, np.ones(len(chosen)),
                  training=training, selection=audit, distance=distance, uncertainty=uncertainty)


def main():
    run_cli(METHOD, run, DEFAULTS, prepare=prepare)


if __name__ == '__main__':
    main()
