"""H/L -> fixed pilot Graph LR -> soft-class linear MMD projection -> Graph LR."""
from experiments.common import run_cli
from experiments.fine_alignment_graph_support import DEFAULTS, parameters, run_fine

METHOD = 'coverage_uncertainty_conditional_graph_lr'


def prepare(X, y, groups, args, cache):
    return parameters(METHOD, 'conditional', X, y, groups, args, cache)


def run(X, y, groups, T, seed, args, settings):
    return run_fine('conditional', X, y, groups, T, seed, args, settings)


def main():
    run_cli(METHOD, run, DEFAULTS, prepare=prepare)


if __name__ == '__main__':
    main()
