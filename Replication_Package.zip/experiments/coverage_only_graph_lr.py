"""Coverage-only ablation: all B slots use the main model's coverage order."""
from experiments.fair_ablation_support import main

if __name__ == '__main__':
    main('coverage_only_graph_lr', 'coverage', True)
