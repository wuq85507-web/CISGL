"""All source rows -> source-LOPO-tuned balanced ordinary LR -> predictions."""
import numpy as np
from selection import compress, fit_lr, positive_probability
from experiments.common import Result, run_cli
from experiments.all_source_support import parameters

METHOD = 'all_source'
DEFAULTS = dict(lr_c=1., budget_fraction=1., graph_tuning='source_lopo',
                graph_c_grid=[.1, 1., 10.])


def prepare(X, y, groups, args, cache):
    return parameters(METHOD, False, X, y, groups, args, cache)


def run(X, y, groups, T, seed, args, settings=None):
    if settings is None:
        if args.graph_tuning != 'fixed':
            raise ValueError('Source-LOPO settings are required; run prepare before fitting.')
        settings = dict(c=args.lr_c, candidate_count=1)
    chosen = np.arange(len(X))
    c = settings['c']
    model = fit_lr(compress(X), y, seed, c=c)
    return Result(positive_probability(model, compress(T)), chosen, np.ones(len(chosen)),
        training=dict(classifier='lr', c=c, tuning=args.graph_tuning,
                      candidate_count=settings['candidate_count']),
        selection=dict(rule='all source rows', original_size=len(X),
                       sampled_size=len(X), sample_rate=1.))


def main():
    run_cli(METHOD, run, DEFAULTS, prepare=prepare)


if __name__ == '__main__':
    main()
