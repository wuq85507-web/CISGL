"""ASCSA: adaptive source clustering -> structural ranking -> DNN + MMD."""
from experiments.paper_baseline_support import run_paper_cli

if __name__ == '__main__':
    run_paper_cli('ascsa_dnn_mmd')
