"""Numerical primitives for paper-based CPDP baselines; no target labels."""
import numpy as np
from scipy.linalg import eigh
from sklearn.preprocessing import StandardScaler
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics.pairwise import rbf_kernel


def project_zscore(X):
    X = np.asarray(X, dtype=float)
    scale = X.std(axis=0, ddof=1) if len(X) > 1 else np.ones(X.shape[1])
    scale = np.where(np.isfinite(scale) & (scale > 1e-12), scale, 1.)
    return (X-X.mean(axis=0))/scale


def matrix_power_psd(matrix, exponent):
    values, vectors = eigh((matrix+matrix.T)/2)
    return (vectors*np.maximum(values, 1e-12)**exponent) @ vectors.T


def coral(source, target):
    """CCPDP equations 10--13: per-domain z-score, covariance + I, whiten/recolor."""
    source, target = project_zscore(source), project_zscore(target)
    d = source.shape[1]
    cs = source.T @ source/max(len(source)-1, 1) + np.eye(d)
    ct = target.T @ target/max(len(target)-1, 1) + np.eye(d)
    transform = matrix_power_psd(cs, -.5) @ matrix_power_psd(ct, .5)
    return source @ transform, target, dict(covariance_ridge=1.,
        preprocessing='independent source/target z-score; sample standard deviation',
        transform_condition=float(np.linalg.cond(transform)))


def normalized_rows(X):
    return X/np.maximum(np.linalg.norm(X, axis=1, keepdims=True), 1e-12)


def wbda_plus(source, labels, target, dimension=10, regularization=1., iterations=10, mu=.8):
    """Unsupervised adaptation of the released WBDA_PLUS ratio objective.

    The released code returns inside its first iteration (before pseudo labels).
    Here iteration and 1NN pseudo-label updates are retained from the BDA base
    algorithm. No fine-tuning using target labels. Uses the released nt/ns factor.
    Primal matrix algebra is exactly equivalent to materializing the MMD matrix.
    """
    data = normalized_rows(np.vstack((source, target)))
    ns, nt, d = len(source), len(target), data.shape[1]
    if not 0 <= mu < 1 or regularization <= 0 or iterations < 1 or dimension < 1:
        raise ValueError('Invalid WBDA parameters.')
    classes = np.unique(labels)
    marginal = np.r_[np.full(ns, 1/ns), np.full(nt, -1/nt)]
    centered = data-data.mean(axis=0)
    scatter = centered.T @ centered
    # Whitening the positive scatter eigenspace avoids adding arbitrary ridge
    # to the generalized eigenproblem's constraint.
    values, vectors = eigh((scatter+scatter.T)/2)
    keep = values > max(float(values.max()), 1.)*1e-12
    if not keep.any():
        return data[:ns, :1], data[ns:, :1], dict(iterations=0, degenerate_features=True)
    whitening = vectors[:, keep]/np.sqrt(values[keep])
    rank = min(dimension, whitening.shape[1])
    pseudo, history = None, []
    for step in range(iterations):
        columns = [np.sqrt((1-mu)*len(classes))*marginal]
        missing = []
        if pseudo is not None:
            for label in classes:
                sm, tm = labels == label, pseudo == label
                if not tm.any():
                    missing.append(int(label))
                    continue
                vector = np.zeros(ns+nt)
                vector[:ns][sm] = 1/sm.sum()
                prior_ratio = (tm.sum()/nt)/(sm.sum()/ns)
                vector[ns:][tm] = -prior_ratio/tm.sum()
                columns.append(np.sqrt(mu*nt/ns)*vector)
        coefficients = np.column_stack(columns)
        # ||VV^T||_F = ||V^TV||_F, computed in the few-class space.
        norm = max(float(np.linalg.norm(coefficients.T @ coefficients, 'fro')), 1e-15)
        projected = data.T @ coefficients
        objective = projected @ projected.T/norm + regularization*np.eye(d)
        reduced = whitening.T @ objective @ whitening
        _, eigenvectors = eigh((reduced+reduced.T)/2, subset_by_index=[0, rank-1])
        transformed = normalized_rows(data @ whitening @ eigenvectors)
        sx, tx = transformed[:ns], transformed[ns:]
        updated = KNeighborsClassifier(n_neighbors=1).fit(sx, labels).predict(tx)
        history.append(dict(iteration=step+1, pseudo_positive_fraction=float(updated.mean()),
                            missing_target_classes=missing))
        pseudo = updated
    return sx, tx, dict(iterations=iterations, dimension=rank, regularization=regularization,
        mu=mu, target_source_ratio=nt/ns, pseudo_label_history=history,
        kernel='primal', target_labels_used=False,
        protocol='unsupervised adaptation; released ratio objective + restored pseudo-label iteration')


def mmd_squared(source, target, sigma, block=256):
    gamma = 1/(2*sigma*sigma)

    def mean_kernel(a, b):
        total = 0.
        for start in range(0, len(a), block):
            for other in range(0, len(b), block):
                total += float(rbf_kernel(a[start:start+block], b[other:other+block], gamma=gamma).sum())
        return total/(len(a)*len(b))

    return max(0., mean_kernel(source, source)+mean_kernel(target, target)-2*mean_kernel(source, target))
