"""Shared target-coverage H plus random L -> target graph-regularized LR."""
import numpy as np
from selection import compress, positive_probability
from graph_lr import target_graph, fit_graph_lr
from experiments.common import Result, run_cli
from experiments.graph_support import parameters
from experiments.selection_support import coverage_inputs

METHOD = 'coverage_random_graph_lr'
DEFAULTS = dict(graph_tuning='source_lopo', graph_c=1.,
                graph_c_grid=[.1, 1., 10.], graph_beta_grid=[0., .03, .1, .3],
                graph_neighbor_grid=[5, 10])


def prepare(X, y, groups, args, cache):
    return parameters(METHOD, X, y, groups, args, cache)


def run(X, y, groups, T, seed, args, settings):
    context = coverage_inputs(X, y, groups, T, seed, args)
    rng = np.random.default_rng(seed)
    rng.choice(len(X), context.budget, replace=False)  # Match coverage_random.
    supplement = rng.choice(context.remaining, context.n_low, replace=False)
    chosen = np.r_[context.high, supplement]
    beta, k, c = settings['beta'], settings['neighbors'], settings['c']
    source, target = compress(X), compress(T)
    edges = target_graph(source, target, k)
    model, training = fit_graph_lr(source[chosen], y[chosen], target, edges, seed, beta, c=c)
    training.update(classifier='graph_lr', neighbors=k, tuning=args.graph_tuning)
    return Result(positive_probability(model, target), chosen, np.ones(len(chosen)),
                  training=training, selection=context.audit,
                  distance=context.distance, uncertainty=context.uncertainty)


def main():
    run_cli(METHOD, run, DEFAULTS, prepare=prepare)


if __name__ == '__main__':
    main()
