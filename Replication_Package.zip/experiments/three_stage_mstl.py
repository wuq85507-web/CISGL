"""3SW-MSTL paper-based reconstruction; details recorded in baseline protocol."""
from experiments.paper_baseline_support import run_paper_cli

if __name__ == '__main__':
    run_paper_cli('three_stage_mstl')
