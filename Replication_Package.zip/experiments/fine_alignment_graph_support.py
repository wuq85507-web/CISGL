"""Regional / soft-class linear MMD projection after unchanged H/L selection.

The projection minimizes mean discrepancies under a pooled variance constraint.
It is learned per task/fold and frozen before final convex Graph LR fitting.
These are metric-space adaptations, not a reproduction of the DSAN network.
"""
import json
import time

import numpy as np
from sklearn.cluster import KMeans, MiniBatchKMeans
from sklearn.metrics import roc_auc_score, matthews_corrcoef
from sklearn.neighbors import NearestNeighbors
from sklearn.preprocessing import StandardScaler

from experiments.alignment_graph_support import select_source, DEFAULTS as BASE_DEFAULTS
from experiments.common import Result
from graph_lr import target_graph, graph_quadratic, fit_graph_lr
from selection import compress, fit_lr, positive_probability


DEFAULTS = dict(BASE_DEFAULTS, fine_alignment_protocol='linear-local-conditional-v1')
PILOT = dict(c=1., beta=.1, neighbors=10)


def regional_memberships(source_geometry, target_geometry, regions, seed):
    count = min(regions, len(np.unique(target_geometry, axis=0)))
    clusterer = (MiniBatchKMeans(n_clusters=count, random_state=seed, n_init=3,
                                batch_size=1024) if len(target_geometry) > 2000 else
                 KMeans(n_clusters=count, random_state=seed, n_init=10))
    target_regions = clusterer.fit_predict(target_geometry)
    closest = NearestNeighbors(n_neighbors=1, n_jobs=1).fit(target_geometry)
    neighbors = closest.kneighbors(source_geometry, return_distance=False)[:, 0]
    return target_regions[neighbors], target_regions


def regional_discrepancy(source, target, source_regions, target_regions, min_rows=2):
    differences, counts = [], []
    for region in np.unique(target_regions):
        sm, tm = source_regions == region, target_regions == region
        eligible = int(sm.sum()) >= min_rows and int(tm.sum()) >= min_rows
        counts.append(dict(region=int(region), source_rows=int(sm.sum()),
                           target_rows=int(tm.sum()), used=bool(eligible)))
        if eligible:
            differences.append(source[sm].mean(axis=0)-target[tm].mean(axis=0))
    fallback = not differences
    if fallback:
        differences = [source.mean(axis=0)-target.mean(axis=0)]
    vectors = np.asarray(differences)
    matrix = vectors.T @ vectors / len(vectors)
    return matrix, dict(regions=counts, eligible_regions=sum(row['used'] for row in counts),
                         minimum_rows=min_rows, region_weighting='uniform over eligible regions',
                         fallback='global linear MMD' if fallback else None)


def conditional_discrepancy(source, labels, target, probability, min_rows=2):
    probability = np.asarray(probability, dtype=float)
    if (probability.shape != (len(target),) or not np.isfinite(probability).all()
            or ((probability < 0) | (probability > 1)).any()):
        raise ValueError('Pilot probabilities must be finite and in [0, 1].')
    differences, counts = [], []
    for label in (0, 1):
        mask = labels == label
        weights = probability if label else 1-probability
        mass = float(weights.sum())
        effective = mass**2/max(float(weights @ weights), 1e-30)
        eligible = int(mask.sum()) >= min_rows and mass > 1e-12 and effective >= min_rows
        counts.append(dict(label=label, source_rows=int(mask.sum()), target_soft_mass=mass,
                           target_effective_rows=effective, used=bool(eligible)))
        if eligible:
            differences.append(source[mask].mean(axis=0) - weights @ target / mass)
    if not differences:
        return np.zeros((source.shape[1], source.shape[1])), dict(
            classes=counts, minimum_rows=min_rows, fallback='identity; insufficient class support')
    vectors = np.asarray(differences)
    return vectors.T @ vectors / len(vectors), dict(
        classes=counts, minimum_rows=min_rows, class_weighting='uniform over eligible classes',
        source_membership='true source class', target_membership='pilot soft probability',
        fallback=None)


def learn_projection(source, target, discrepancy, dimension=10, regularization=1.):
    """min tr(A^T (D/||D||F + mu I) A), A^T Cov(Z) A = I.

    Covariance whitening removes its nullspace. The constraint prevents the
    constant-map solution; the learned projection is shared by source/target.
    """
    d = source.shape[1]
    if dimension < 1 or not np.isfinite(regularization) or regularization <= 0:
        raise ValueError('Projection dimension and regularization must be positive.')
    discrepancy = (discrepancy+discrepancy.T)/2
    norm = float(np.linalg.norm(discrepancy, 'fro'))
    z = np.vstack((source, target))
    centered = z-z.mean(axis=0)
    scatter = centered.T @ centered / max(len(z)-1, 1)
    values, vectors = np.linalg.eigh(scatter)
    keep = values > max(float(values.max()), 1.)*1e-12
    if not keep.any() or norm <= 1e-12:
        return source.copy(), target.copy(), np.eye(d), dict(
            dimension=d, regularization=regularization, solver='identity fallback',
            fallback='zero pooled variance' if not keep.any() else 'zero discrepancy',
            discrepancy_frobenius=norm)
    whitening = vectors[:, keep]/np.sqrt(values[keep])
    objective = discrepancy/norm + regularization*np.eye(d)
    reduced = whitening.T @ objective @ whitening
    eigenvalues, rotation = np.linalg.eigh((reduced+reduced.T)/2)
    count = min(dimension, whitening.shape[1])
    transform = whitening @ rotation[:, :count]
    sx, tx = source @ transform, target @ transform
    if not np.isfinite(sx).all() or not np.isfinite(tx).all():
        raise RuntimeError('Non-finite aligned representation.')
    return sx, tx, transform, dict(
        dimension=count, requested_dimension=dimension, regularization=regularization,
        solver='linear MMD generalized eigensystem with pooled covariance constraint',
        discrepancy_frobenius=norm, eigenvalues=eigenvalues[:count].tolist(),
        pooled_rank=int(keep.sum()),
        variance_constraint_error=float(np.linalg.norm(transform.T @ scatter @ transform-np.eye(count))),
        target_labels_used=False)


def aligned_features(kind, raw_source, labels, raw_target, chosen, context, seed, args):
    """Only selected source labels and unlabeled target features are accepted."""
    scaler = StandardScaler().fit(raw_source[chosen])
    sx, tx = scaler.transform(raw_source[chosen]), scaler.transform(raw_target)
    pilot_audit = None
    if kind == 'local':
        sr, tr = regional_memberships(context.S[chosen], context.Z, args.target_regions, seed)
        discrepancy, membership = regional_discrepancy(sx, tx, sr, tr)
    elif kind == 'conditional':
        edges = target_graph(raw_source, raw_target, PILOT['neighbors'])
        pilot, pilot_training = fit_graph_lr(raw_source[chosen], labels[chosen], raw_target,
            edges, seed, PILOT['beta'], c=PILOT['c'])
        probability = positive_probability(pilot, raw_target)
        discrepancy, membership = conditional_discrepancy(sx, labels[chosen], tx, probability)
        pilot_audit = dict(PILOT, training=pilot_training, source_rows=len(chosen),
                           probability_min=float(probability.min()),
                           probability_max=float(probability.max()),
                           probability_mean=float(probability.mean()),
                           fitted_per_fold=True, parameter_search=False)
    else:
        raise ValueError(f'Unknown fine alignment: {kind}')
    sx, tx, transform, projection = learn_projection(
        sx, tx, discrepancy, args.tca_dimension, args.tca_mu)
    return sx, tx, dict(kind=kind, kernel='linear', source_rows=len(chosen),
                       target_rows=len(raw_target), membership=membership, projection=projection,
                       transform=transform.tolist(), pilot=pilot_audit,
                       scaling='selected source fitted StandardScaler after signed log',
                       target_labels_used=False)


def tune_fine(kind, X, y, groups, args):
    neighbors = list(dict.fromkeys(args.graph_neighbor_grid))
    candidates = [(float(c), float(beta), int(k)) for c in dict.fromkeys(args.graph_c_grid)
                  for beta in dict.fromkeys(args.graph_beta_grid)
                  for k in (neighbors[:1] if beta == 0 else neighbors)]
    rows, audits = [], []
    for held_out in np.unique(groups):
        train, valid = groups != held_out, groups == held_out
        if train.sum() < 2 or len(np.unique(y[valid])) < 2:
            continue
        chosen, context = select_source(X[train], y[train], groups[train], X[valid], 0, args)
        raw_source, raw_target = compress(X[train]), compress(X[valid])
        sx, tx, audit = aligned_features(kind, raw_source, y[train], raw_target,
                                         chosen, context, 0, args)
        audits.append(dict(held_out_source=int(held_out), alignment=audit))
        edges = {k: target_graph(raw_source, raw_target, k) for k in neighbors}
        sy = y[train][chosen]
        bases = {c: fit_lr(sx, sy, 0, c=c) for c in dict.fromkeys(args.graph_c_grid)}
        scaled_target = next(iter(bases.values())).steps[0][1].transform(tx)
        quadratics = {k: graph_quadratic(scaled_target, edges[k]) for k in neighbors}
        for c, beta, k in candidates:
            model, _ = fit_graph_lr(sx, sy, tx, edges[k], 0, beta,
                                   base_model=bases[c], quadratic=quadratics[k], c=c)
            probability = positive_probability(model, tx)
            rows.append(dict(held_out_source=int(held_out), c=c, beta=beta, neighbors=k,
                auc=float(roc_auc_score(y[valid], probability)),
                mcc=float(matthews_corrcoef(y[valid], probability >= .5))))
    if not rows:
        raise ValueError('No two-class source LOPO fold; use --graph-tuning fixed.')
    summaries = []
    for c, beta, k in candidates:
        matches = [r for r in rows if (r['c'], r['beta'], r['neighbors']) == (c, beta, k)]
        summaries.append(dict(c=c, beta=beta, neighbors=k, folds=len(matches),
                              auc=float(np.mean([r['auc'] for r in matches])),
                              mcc=float(np.mean([r['mcc'] for r in matches]))))
    best = max(summaries, key=lambda r: (r['auc'], r['mcc'], -r['beta'], -r['neighbors']))
    return dict(best=best, candidates=summaries, folds=rows, alignment_folds=audits,
                real_target_used=False, alignment=kind,
                protocol='source-project LOPO; mean project AUC; MCC breaks exact ties; selection seed=0')


def parameters(method, kind, X, y, groups, args, cache):
    if args.graph_tuning == 'fixed':
        return dict(c=args.graph_c, beta=args.graph_beta, neighbors=args.graph_neighbors)
    records = json.loads(cache.read_text(encoding='utf-8')) if cache.exists() else {}
    if method not in records:
        print(f'Source LOPO tuning: {method}; reused across seeds', flush=True)
        started = time.perf_counter()
        record = tune_fine(kind, X, y, groups, args)
        record['tuning_seconds_batch'] = time.perf_counter()-started
        records[method] = record
        cache.parent.mkdir(parents=True, exist_ok=True)
        cache.write_text(json.dumps(records, indent=2), encoding='utf-8')
    return records[method]['best']


def run_fine(kind, X, y, groups, target, seed, args, settings):
    chosen, context = select_source(X, y, groups, target, seed, args)
    raw_source, raw_target = compress(X), compress(target)
    started = time.perf_counter()
    sx, tx, audit = aligned_features(kind, raw_source, y, raw_target, chosen, context, seed, args)
    audit['seconds_including_pilot'] = time.perf_counter()-started
    c, beta, k = settings['c'], settings['beta'], settings['neighbors']
    edges = target_graph(raw_source, raw_target, k)
    model, training = fit_graph_lr(sx, y[chosen], tx, edges, seed, beta, c=c)
    training.update(classifier='graph_lr', neighbors=k, tuning=args.graph_tuning,
                    alignment=audit, target_labels_used=False,
                    graph_protocol='original full-source-scaled metric edges and weights')
    return Result(positive_probability(model, tx), chosen, np.ones(len(chosen)),
        training=training, selection=dict(context.audit, alignment=kind, original_main_selection=True),
        distance=context.distance, uncertainty=context.uncertainty)
