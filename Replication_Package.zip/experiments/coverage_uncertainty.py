"""Shared H plus source-OOF uncertainty complement + ordinary LR.

Input: source X/y/groups and unlabeled target T; target labels are never accepted.
Output: source indices, target probabilities, weights and audit; common.run_cli
loads the dataset and writes metrics/selection/prediction files.
"""
import json
import time
import numpy as np
from selection import compress, fit_lr, positive_probability
from graph_tuning import tune_graph
from experiments.common import Result, run_cli
from experiments.selection_support import sample_budget, geometry, coverage_inputs, uncertain_pool

METHOD = 'coverage_uncertainty'
DEFAULTS = dict(lr_c=1., graph_tuning='source_lopo', graph_c_grid=[.1, 1., 10.])


def prepare(X, y, groups, args, cache):
    if args.graph_tuning == 'fixed':
        return dict(c=args.lr_c, candidate_count=1)
    records = json.loads(cache.read_text(encoding='utf-8')) if cache.exists() else {}
    if METHOD not in records:
        print(f'Source LOPO tuning: {METHOD}; ordinary LR; reused across seeds', flush=True)
        started = time.perf_counter()
        # Reuse the main model's source folds, selector and scoring. At beta=0,
        # fit_graph_lr returns the exact ordinary LR fit, without graph optimization.
        selector = 'coverage_uncertainty_graph_lr'
        record = tune_graph(X, y, groups, [selector], budget=args.budget,
            budget_fraction=args.budget_fraction, low_fraction=args.low_fraction,
            regions=args.target_regions, quantiles=args.distance_quantiles,
            candidate_multiplier=args.candidate_multiplier,
            information_ridge=args.information_ridge,
            betas=[0.], neighbors=[1], c_grid=args.graph_c_grid,
            tune_all_c=True)[selector]
        record.update(tuning_seconds_batch=time.perf_counter()-started,
                      classifier='lr', candidate_count=len(record['candidates']),
                      source_policy='reselect H/L within each source-LOPO training fold')
        records[METHOD] = record
        cache.parent.mkdir(parents=True, exist_ok=True)
        cache.write_text(json.dumps(records, indent=2), encoding='utf-8')
    record = records[METHOD]
    return dict(record['best'], candidate_count=len(record['candidates']))


def run(X, y, groups, T, seed, args, settings=None):
    if not settings:
        if args.graph_tuning != 'fixed':
            raise ValueError('Source-LOPO settings are required; run prepare before fitting.')
        settings = dict(c=args.lr_c, candidate_count=1)
    context = coverage_inputs(X, y, groups, T, seed, args, need_uncertainty=True)
    supplement = context.remaining[np.argsort(-context.uncertainty[context.remaining], kind='stable')[:context.n_low]]
    chosen = np.r_[context.high, supplement]
    distance, uncertainty, audit = context.distance, context.uncertainty, context.audit
    source_features = compress(X[chosen])
    target_features = compress(T)
    # StandardScaler is fitted only on selected source rows inside fit_lr.
    c = settings['c']
    model = fit_lr(source_features, y[chosen], seed, c=c)
    probability = positive_probability(model, target_features)
    return Result(probability, chosen, np.ones(len(chosen)),
                  training=dict(classifier='lr', c=c, tuning=args.graph_tuning,
                                candidate_count=settings.get('candidate_count', 1)),
                  selection=audit, distance=distance, uncertainty=uncertainty)


def main():
    run_cli(METHOD, run, DEFAULTS, prepare=prepare)


if __name__ == '__main__':
    main()
