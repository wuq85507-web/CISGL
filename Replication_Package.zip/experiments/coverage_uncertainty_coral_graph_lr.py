"""Original H/L -> selected-source CORAL -> original target graph -> Graph LR."""
from experiments.common import run_cli
from experiments.alignment_graph_support import DEFAULTS, parameters, run_aligned

METHOD = 'coverage_uncertainty_coral_graph_lr'


def prepare(X, y, groups, args, cache):
    return parameters(METHOD, 'coral', X, y, groups, args, cache)


def run(X, y, groups, T, seed, args, settings):
    return run_aligned('coral', X, y, groups, T, seed, args, settings)


def main():
    run_cli(METHOD, run, DEFAULTS, prepare=prepare)


if __name__ == '__main__':
    main()
