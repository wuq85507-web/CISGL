"""Paper-based 3SW-MSTL reconstruction: bellwether, KMM, graph weighted vote."""
import numpy as np
from scipy.optimize import minimize
from sklearn.dummy import DummyClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score
from sklearn.metrics.pairwise import rbf_kernel
from sklearn.preprocessing import MinMaxScaler

from experiments.paper_math import project_zscore
from transfer_baselines import kmm_weights
from selection import positive_probability


def weighted_lr(X, y, seed, c=1., weights=None):
    model = (LogisticRegression(C=c, class_weight='balanced', max_iter=2000,
                               solver='lbfgs', random_state=seed)
             if len(np.unique(y)) == 2 else DummyClassifier(strategy='prior'))
    return model.fit(X, y, sample_weight=weights)


def bellwether_order(X, y, groups, seed, c=1.):
    """Source-only project transfer ranking; target project is absent.

    Uses mean source-to-other-source AUC. This explicit ranking is a
    reconstruction: the paper's Algorithm 1 and author code are unavailable in
    machine-readable form. Do not label this a byte-for-byte replication.
    """
    scores = []
    for source in np.unique(groups):
        mask = groups == source
        model = weighted_lr(project_zscore(X[mask]), y[mask], seed, c)
        performance = []
        for valid in np.unique(groups):
            selected = groups == valid
            if valid == source or len(np.unique(y[selected])) < 2:
                continue
            performance.append(roc_auc_score(y[selected], positive_probability(model, project_zscore(X[selected]))))
        scores.append(dict(source_group=int(source), mean_auc=float(np.mean(performance)) if performance else .5))
    return sorted(scores, key=lambda row: (-row['mean_auc'], row['source_group']))


def target_vote_quadratic(T, hypotheses, sigma=.1):
    """H^T L H for the full Gaussian target graph, blocked for memory only."""
    z = MinMaxScaler().fit_transform(T)
    q = np.zeros((hypotheses.shape[1], hypotheses.shape[1]))
    for start in range(0, len(T), 128):
        stop = min(start+128, len(T))
        weights = rbf_kernel(z[start:stop], z, gamma=1/sigma**2)
        left = hypotheses[start:stop]
        q += left.T @ (weights.sum(axis=1)[:, None]*left-weights @ hypotheses)
    return (q+q.T)/2


def solve_vote_weights(quadratic):
    n = len(quadratic)
    if n == 1:
        return np.ones(1), dict(status='single-source vote', kkt_gap=0.)
    scale = max(float(np.linalg.norm(quadratic, 2)), 1e-12)
    q = quadratic/scale
    result = minimize(lambda x: (float(x @ q @ x), 2*q @ x),
        np.full(n, 1/n), jac=True, method='SLSQP', bounds=[(0, 1)]*n,
        constraints=[dict(type='eq', fun=lambda x: x.sum()-1, jac=lambda x: np.ones(n))],
        options=dict(maxiter=2000, ftol=1e-12))
    if not result.success:
        raise RuntimeError(f'3SW-MSTL graph simplex solve failed: {result.message}')
    gradient = 2*q @ result.x
    gap = float(gradient @ result.x-gradient.min())
    if gap > 1e-5 or abs(result.x.sum()-1) > 1e-7:
        raise RuntimeError(f'3SW-MSTL simplex optimality check failed: gap={gap:g}')
    return result.x, dict(status=result.message, kkt_gap=gap, objective=float(result.x @ quadratic @ result.x))


def predict_three_stage(X, y, groups, T, seed, args, c, ranking=None):
    ranking = bellwether_order(X, y, groups, seed, c) if ranking is None else ranking
    sources = [row['source_group'] for row in ranking[:min(args.mstl_sources, len(ranking))]]
    columns, chosen, instance_weights, transfers = [], [], [], []
    for group in sources:
        indices = np.flatnonzero(groups == group)
        source, target = project_zscore(X[indices]), project_zscore(T)
        weights, info = kmm_weights(source, target, seed, bound=args.kmm_bound,
            landmarks=args.kmm_landmarks, exact_limit=args.kmm_exact_limit)
        model = weighted_lr(source, y[indices], seed, c, weights)
        columns.append((positive_probability(model, target) >= .5).astype(float))
        chosen.extend(indices.tolist())
        instance_weights.extend(weights.tolist())
        transfers.append(dict(source_group=group, **info))
    h = np.column_stack(columns)
    beta, optimization = solve_vote_weights(target_vote_quadratic(T, h))
    # Paper Eq.4 uses log(1/beta), rather than beta itself. Clamp only for log(0).
    vote = -np.log(np.clip(beta, 1e-12, 1.))
    if len(vote) == 1 or vote.sum() <= 1e-12:
        vote = np.ones(len(vote))
    vote /= vote.sum()
    order = np.argsort(chosen)
    chosen, instance_weights = np.asarray(chosen)[order], np.asarray(instance_weights)[order]
    return h @ vote, chosen, instance_weights, dict(
        bellwether_ranking=ranking, selected_sources=sources, kmm=transfers,
        graph_beta=beta.tolist(), final_vote_weights=vote.tolist(), graph_solve=optimization,
        adaptation='paper-based reconstruction; source-only mean-AUC bellwether ranking',
        graph='full Gaussian; sigma=.1; target Min-Max; hard source hypotheses',
        final_score='normalized log(1/beta)-weighted hard vote; paper Eq.4')
