"""Paper baseline fitting and source-only parameter selection.

All methods receive source labels and target features only. No Graph LR is
silently appended to a complete baseline. Core-specific preprocessing is logged.
"""
import hashlib
import json
import time
from pathlib import Path

import numpy as np
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import roc_auc_score, matthews_corrcoef

from experiments.common import Result, run_cli
from experiments.paper_math import coral, wbda_plus, project_zscore
from experiments.three_stage_core import weighted_lr, predict_three_stage
from selection import positive_probability

METHODS = ('ascsa_dnn_mmd', 'dssdpp', 'wbda_plus_unsupervised_lr', 'ccpdp_rf', 'ccpdp_lr',
           'three_stage_mstl')
DEFAULTS = dict(paper_protocol='ascsa-cited-baselines-v1', budget_fraction=1.,
                baseline_tuning='source_lopo')


def configure(parser):
    parser.add_argument('--baseline-tuning', choices=['source_lopo', 'fixed'], default='source_lopo')
    parser.add_argument('--baseline-device', choices=['auto', 'cpu', 'cuda'], default='auto')
    parser.add_argument('--ascsa-epochs', type=int, default=20)
    parser.add_argument('--ascsa-max-clusters', type=int, default=30)
    parser.add_argument('--dssdpp-selection', choices=['corr', 'mmd'], default='mmd',
                        help='corr: released main single-source demo; mmd: previous variant')
    parser.add_argument('--dssdpp-repeats', '--dssdpp-mmd-repeats',
                        dest='dssdpp_mmd_repeats', type=int, default=30)
    parser.add_argument('--dssdpp-bandwidth-limit', type=int, default=0,
                        help='0: exact original median; >=2: explicitly approximate bandwidth')
    parser.add_argument('--wbda-iterations', type=int, default=10)
    parser.add_argument('--mstl-sources', type=int, default=5)
    # The jar is not Python; put its digest in the run configuration as well.
    jar = Path(__file__).with_name('paper_assets')/'weka.jar'
    parser.set_defaults(weka_sha256=hashlib.sha256(jar.read_bytes()).hexdigest() if jar.exists() else None)


def validate(args):
    if (args.ascsa_epochs < 1 or args.ascsa_max_clusters < 0 or args.dssdpp_mmd_repeats < 1
            or args.wbda_iterations < 1 or args.mstl_sources < 1
            or args.dssdpp_bandwidth_limit < 0 or args.dssdpp_bandwidth_limit == 1):
        raise ValueError('Invalid paper baseline iteration, source or cluster limit.')
    # These are whole-method comparisons with their native selection rules.
    # Reject a budget rather than silently ignore a requested 25% control.
    if args.budget is not None or args.budget_fraction != 1.:
        raise ValueError('Paper baselines use native source selection; omit --budget/--budget-fraction. '
                         'Use the separate budgeted selector experiments for matched-budget comparisons.')


def fit_predict(method, X, y, groups, T, seed, args, settings):
    validate(args)
    chosen, weights = np.arange(len(X)), np.ones(len(X))
    audit = dict(protocol='whole-method comparison; shared target rows; native selection',
                 target_labels_used=False, source_pool=len(X))
    c = settings.get('c', args.lr_c)
    training = dict(classifier=method, tuning=args.baseline_tuning)
    balanced = True
    if method in ('ccpdp_rf', 'ccpdp_lr'):
        source, target, detail = coral(X, T)
        if method == 'ccpdp_rf':
            model = RandomForestClassifier(n_estimators=100, random_state=seed, n_jobs=4,
                max_depth=settings.get('depth'), min_samples_leaf=settings.get('leaf', 1),
                class_weight=None).fit(source, y)
            balanced = False
            training.update(trees=100, depth=settings.get('depth'), leaf=settings.get('leaf', 1))
        else:
            model = weighted_lr(source, y, seed, c)
            training['c'] = c
        p = positive_probability(model, target)
        audit.update(detail, classifier='RF (original family)' if method == 'ccpdp_rf' else 'LR controlled adaptation',
                     multi_source='pool remaining source projects before CORAL')
    elif method == 'wbda_plus_unsupervised_lr':
        dimension, regularization = settings.get('dimension', 10), settings.get('regularization', 1.)
        source, target, detail = wbda_plus(X, y, T, dimension=dimension,
            regularization=regularization, iterations=args.wbda_iterations)
        model = weighted_lr(source, y, seed, c)
        p = positive_probability(model, target)
        audit.update(detail, original_target_finetuning_removed=True,
                     classifier='LR replaces original XGBoost; explicitly unsupervised adaptation')
        training.update(c=c, dimension=dimension, regularization=regularization)
    elif method == 'dssdpp':
        from experiments.dssdpp_core import select_source, select_source_corr, mpos, weka_cfs, domain_program
        if args.dssdpp_selection == 'corr':
            # Author precomputes CORR_ID once and resets rng('default') before MPOS.
            chosen, detail = select_source_corr(X, y, groups, T, seed=0,
                                                repeats=args.dssdpp_mmd_repeats)
            sampling_seed = 0
        else:
            chosen, detail = select_source(X, groups, T, seed, args.dssdpp_mmd_repeats,
                                           args.dssdpp_bandwidth_limit)
            detail.update(source_selector='MMD', source_variant='previous single-source variant')
            sampling_seed = seed
        source, labels, generated = mpos(X[chosen], y[chosen], sampling_seed)
        features = weka_cfs(source, labels) if len(np.unique(labels)) == 2 else np.arange(X.shape[1])
        source, target = project_zscore(source[:, features]), project_zscore(T[:, features])
        p, lp = domain_program(source, labels, target)
        audit.update(detail, feature_indices=features.tolist(), feature_selection='original Weka CFS + BestFirst -D 1 -N 5',
            generated_rows=generated, classifier_training_rows=len(source),
            training_positive_fraction=float(labels.mean()), mp_os='released anchor-including nearest neighbor behavior',
            score_scope='original LP annotation, possibly hard 0/1; no artificial soft score')
        audit.update(mpos_seed=sampling_seed,
            preprocessing='independent source/target z-score; sample standard deviation',
            evaluation_protocol='common full-target evaluation; source feature deduplication',
            implementation='Python port of released v3; NumPy RNG and HiGHS differ from MATLAB')
        training.update(lp, tuning='fixed published algorithm; no target-label selection')
        weights, balanced = np.ones(len(chosen)), False
    elif method == 'ascsa_dnn_mmd':
        from experiments.ascsa_reference import ASCSAFramework
        pooled = np.concatenate([np.flatnonzero(groups == group) for group in np.unique(groups)])
        sources = [np.column_stack((X[groups == group], y[groups == group])) for group in np.unique(groups)]
        model = ASCSAFramework(random_state=seed, classifier='dnn', top_k=5,
            epochs=args.ascsa_epochs, batch_size=64, learning_rate=.001,
            mmd_weight=.5, hidden_dims=[128, 128], device=args.baseline_device,
            max_clusters=args.ascsa_max_clusters)
        model.fit(sources, T)
        p = model.predict_proba(T)
        chosen = pooled[model.selected_original_indices_]
        if not len(chosen):
            raise RuntimeError('ASCSA selected only synthetic rows; cannot export original-row selection provenance.')
        weights, balanced = np.ones(len(chosen)), False
        audit.update(preprocessing='per-project source SMOTE then independent project Min-Max',
            selected_clusters=np.asarray(model.selected_clusters_).tolist(),
            clustering=model.clustering_audit_, cluster_details=model.cluster_audit_,
            source_preprocessing=model.preprocessing_audit_,
            classifier_training_rows=model.selected_samples_, original_training_rows=len(chosen),
            synthetic_training_rows=model.selected_samples_-len(chosen),
            training_positive_fraction=model.selected_defect_ratio_,
            eigengap_search_limit=args.ascsa_max_clusters,
            eigengap_note='paper range unspecified; explicit bounded search from existing implementation')
        training.update(tuning='fixed paper settings', epochs=args.ascsa_epochs,
            device=str(model.device), hidden_dims=[128, 128], dropout=.2, batch_size=64,
            learning_rate=.001, mmd_weight=.5, history=model.training_history_)
    elif method == 'three_stage_mstl':
        p, chosen, weights, detail = predict_three_stage(X, y, groups, T, seed, args, c)
        audit.update(detail)
        training.update(c=c, tuning='fixed paper LR C=1; no target-label tuning',
                        adaptation='source-only bellwether reconstruction; see protocol')
    else:
        raise ValueError(f'Unknown paper baseline: {method}')
    return Result(p, chosen, weights, training=training, selection=audit,
                  balanced_class_weights=balanced,
                  strict_positive_threshold=(method == 'dssdpp' and args.dssdpp_selection == 'corr'))


def candidate_settings(method, X, args):
    if method == 'ccpdp_rf':
        return [dict(depth=depth, leaf=leaf) for depth in (None, 3, 5, 8, 12, 20, 30) for leaf in (1, 2, 5)]
    if method == 'ccpdp_lr':
        return [dict(c=float(c)) for c in args.graph_c_grid]
    if method == 'wbda_plus_unsupervised_lr':
        return [dict(c=float(c), dimension=dimension, regularization=1.)
                for c in args.graph_c_grid
                for dimension in sorted({min(d, X.shape[1]) for d in (5, 10, 15, 20, 25, 30, 40)})]
    return [dict(c=1.)]


def parameters(method, X, y, groups, args, cache):
    validate(args)
    if args.baseline_tuning == 'fixed' or method in ('ascsa_dnn_mmd', 'dssdpp', 'three_stage_mstl'):
        return dict(c=args.lr_c)
    if cache.exists():
        return json.loads(cache.read_text(encoding='utf-8'))['best']
    print(f'Source LOPO tuning: {method}; reused across seeds', flush=True)
    started, summaries, rows = time.perf_counter(), [], []
    candidates = candidate_settings(method, X, args)
    # Compute CORAL/WBDA once per fold and parameterized representation, not per C.
    for group in np.unique(groups):
        train, valid = groups != group, groups == group
        if not train.any() or len(np.unique(y[valid])) < 2:
            continue
        representations = {}
        for index, setting in enumerate(candidates):
            if method.startswith('ccpdp'):
                key = 'coral'
                if key not in representations:
                    representations[key] = coral(X[train], X[valid])[:2]
            else:
                key = setting['dimension']
                if key not in representations:
                    representations[key] = wbda_plus(X[train], y[train], X[valid],
                        dimension=key, iterations=args.wbda_iterations)[:2]
            sx, tx = representations[key]
            if method == 'ccpdp_rf':
                model = RandomForestClassifier(n_estimators=100, random_state=0, n_jobs=4,
                    max_depth=setting['depth'], min_samples_leaf=setting['leaf']).fit(sx, y[train])
            else:
                model = weighted_lr(sx, y[train], 0, setting['c'])
            p = positive_probability(model, tx)
            rows.append(dict(candidate=index, held_out_source=int(group),
                auc=float(roc_auc_score(y[valid], p)),
                mcc=float(matthews_corrcoef(y[valid], p >= .5))))
    if not rows:
        raise ValueError('No two-class pseudo-target LOPO fold; use --baseline-tuning fixed explicitly.')
    for index, setting in enumerate(candidates):
        matches = [row for row in rows if row['candidate'] == index]
        summaries.append(dict(settings=setting, folds=len(matches),
            auc=float(np.mean([row['auc'] for row in matches])),
            mcc=float(np.mean([row['mcc'] for row in matches]))))
    best = max(summaries, key=lambda row: (row['auc'], row['mcc']))
    record = dict(best=best['settings'], candidates=summaries, folds=rows,
        real_target_used=False, tuning_seconds_batch=time.perf_counter()-started,
        protocol='source-project LOPO; equal weight per project; mean AUC then MCC')
    cache.parent.mkdir(parents=True, exist_ok=True)
    cache.write_text(json.dumps(record, indent=2), encoding='utf-8')
    return record['best']


def run_paper_cli(method):
    def prepare(X, y, groups, args, cache):
        return parameters(method, X, y, groups, args, cache)

    def run(X, y, groups, T, seed, args, settings):
        return fit_predict(method, X, y, groups, T, seed, args, settings)

    defaults = dict(DEFAULTS)
    if method == 'dssdpp':
        defaults.update(paper_protocol='dssdpp-released-corr-single-source-v1')
    run_cli(method, run, defaults, prepare=prepare, configure=configure)
