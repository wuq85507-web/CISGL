"""DSSDPP source selection, released MPOS, Weka CFS, and domain LP."""
import re
import shutil
import subprocess
import tempfile
from pathlib import Path

import numpy as np
from scipy.optimize import linprog
from scipy.stats import rankdata
from scipy.sparse import coo_matrix
from scipy.spatial.distance import pdist, cdist
from sklearn.metrics.pairwise import rbf_kernel

from experiments.paper_math import project_zscore

WEKA = Path(__file__).with_name('paper_assets')/'weka.jar'


def select_source(X, groups, T, seed, repeats=30, bandwidth_limit=0):
    """Mean RBF MMD to independent 10% target-feature draws, as in the paper.

    Exact default: re-estimate the median pairwise bandwidth from source plus
    each normalized target draw. Optional bandwidth subsampling is explicit.
    """
    rng = np.random.default_rng(seed)
    draws = [rng.choice(len(T), min(len(T), max(2, int(.1*len(T)))), replace=False)
             if len(T) >= 2 else np.arange(len(T)) for _ in range(repeats)]
    records = []
    for group in np.unique(groups):
        indices = np.flatnonzero(groups == group)
        source = project_zscore(X[indices])
        values, widths, exact = [], [], True
        source_means = {}
        for draw in draws:
            target = project_zscore(T[draw])
            combined = np.vstack((source, target))
            if bandwidth_limit and len(combined) > bandwidth_limit:
                combined = combined[np.sort(rng.choice(len(combined), bandwidth_limit, replace=False))]
                exact = False
            sigma = max(float(np.median(pdist(combined))), 1e-12)
            gamma = 1/(2*sigma*sigma)
            widths.append(sigma)
            if sigma not in source_means:
                total = 0.
                for start in range(0, len(source), 256):
                    for other in range(0, len(source), 256):
                        total += float(rbf_kernel(source[start:start+256], source[other:other+256], gamma=gamma).sum())
                source_means[sigma] = total/len(source)**2
            cross = sum(float(rbf_kernel(source[start:start+256], target, gamma=gamma).sum())
                        for start in range(0, len(source), 256))/(len(source)*len(target))
            values.append(abs(source_means[sigma]+float(rbf_kernel(target, gamma=gamma).mean())-2*cross))
        records.append(dict(source_group=int(group), mean_mmd=float(np.mean(values)),
            sigma_per_draw=widths, bandwidth_limit=bandwidth_limit, bandwidth_exact=exact))
    winner = min(records, key=lambda row: (row['mean_mmd'], row['source_group']))
    return np.flatnonzero(groups == winner['source_group']), dict(source_ranking=records,
        selected_source=winner['source_group'], repeats=repeats, target_fraction=.1,
        selection_protocol='paper MMD to 30 independent 10% target feature draws; full target evaluated',
        bandwidth_limit=bandwidth_limit)


def _spearman_distance(a, b):
    # pdist2(..., 'spearman') is 1-rho, including NaN for constant rows.
    a, b = rankdata(a), rankdata(b)
    a, b = a-a.mean(), b-b.mean()
    denominator = np.linalg.norm(a)*np.linalg.norm(b)
    return float(1-np.dot(a, b)/denominator) if denominator > 0 else float('nan')


def corr_distance(source, labels, target):
    """Port released CORR.m literally; input here is instances x metrics.

    The release sorts metric-label Spearman *distances* descending. Its nested
    loop overwrites Q(i), retaining the last non-self comparison for each i.
    Preserve both behaviors rather than substitute an improved CORR variant.
    """
    if source.shape[1] < 3:
        raise ValueError('Released CORR requires at least three metrics.')
    relevance = np.array([_spearman_distance(source[:, j], labels)
                          for j in range(source.shape[1])])
    relevance = np.nan_to_num(relevance, nan=0.)
    top = np.argsort(-relevance, kind='stable')[:3]
    q, r = source[:, top], target[:, top]
    # Last j != i for i=0,1,2 in the author's nested MATLAB loop.
    other = (2, 2, 1)
    qs = np.array([_spearman_distance(q[:, i], q[:, j]) for i, j in enumerate(other)])
    rs = np.array([_spearman_distance(r[:, i], r[:, j]) for i, j in enumerate(other)])
    return float(np.linalg.norm(qs-rs)), top


def select_source_corr(X, y, groups, T, seed=0, repeats=30):
    """Single-source demo: average CORR over 30 shared 10% target draws."""
    count = int(.1*len(T))
    if count < 1 or repeats < 1:
        raise ValueError('CORR needs >=10 target rows for the released 10% sampling protocol.')
    rng = np.random.default_rng(seed)
    draws = [rng.permutation(len(T))[:count] for _ in range(repeats)]
    targets = [project_zscore(T[draw]) for draw in draws]
    records, means = [], []
    for group in np.unique(groups):
        indices = np.flatnonzero(groups == group)
        source = project_zscore(X[indices])
        distances = [corr_distance(source, y[indices], target) for target in targets]
        values = np.array([distance for distance, _ in distances])
        mean = float(np.mean(values))  # MATLAB mean, not nanmean.
        means.append(mean)
        records.append(dict(source_group=int(group),
            mean_corr_distance=mean if np.isfinite(mean) else None,
            corr_per_draw=[float(v) if np.isfinite(v) else None for v in values],
            undefined_draws=int((~np.isfinite(values)).sum()),
            selected_metric_indices=distances[0][1].tolist()))
    # MATLAB ascending sort places NaNs last and preserves input order on ties.
    order = np.argsort(np.asarray(means), kind='stable')
    winner = records[int(order[0])]['source_group']
    return np.flatnonzero(groups == winner), dict(
        source_selector='CORR', source_variant='single-source (demo_DSSDPP.m)',
        source_ranking=[records[int(i)] for i in order], selected_source=winner,
        repeats=repeats, target_fraction=.1, target_draw_rows=count, selection_seed=seed,
        target_draw_indices=[draw.tolist() for draw in draws],
        all_source_distances_undefined=not np.isfinite(means).any(),
        selection_protocol='released CORR.m over shared 10% target feature draws; full target evaluated',
        corr_release_behavior='descending 1-Spearman to label; last non-self pair per metric; NaNs sorted last')


def mpos(X, y, seed):
    """Released MPOS includes the anchor itself in its nearest neighbors.

    Consequently mutation is zero and each new coordinate is sampled from a
    random positive source row. Preserve that exact released behavior.
    """
    positive = X[y == 1]
    count = int((y == 0).sum()-len(positive))
    if count <= 0 or not len(positive):
        return X.copy(), y.copy(), 0
    rng = np.random.default_rng(seed)
    indices = rng.integers(len(positive), size=(count, X.shape[1]))
    generated = positive[indices, np.arange(X.shape[1])[None, :]]
    return np.vstack((generated, X)), np.r_[np.ones(count, dtype=int), y], count


def weka_cfs(X, y):
    java = shutil.which('java')
    if not java or not WEKA.is_file():
        raise RuntimeError('DSSDPP requires Java and the bundled original Weka jar for exact CFS.')
    with tempfile.TemporaryDirectory(prefix='cpdp_cfs_') as temporary:
        path = Path(temporary)/'source.arff'
        with path.open('w', encoding='ascii') as stream:
            stream.write('@relation source\n')
            for column in range(X.shape[1]):
                stream.write(f'@attribute f{column} numeric\n')
            stream.write('@attribute class {0,1}\n@data\n')
            for row, label in zip(X, y):
                stream.write(','.join(format(float(value), '.17g') for value in row)+f',{int(label)}\n')
        result = subprocess.run([java, '-Xmx1024m', '-cp', str(WEKA),
            'weka.attributeSelection.CfsSubsetEval', '-i', str(path), '-c', 'last',
            '-s', 'weka.attributeSelection.BestFirst -D 1 -N 5'],
            text=True, encoding='utf-8', errors='replace', capture_output=True, timeout=300)
    if result.returncode:
        raise RuntimeError(f'Weka CFS failed: {result.stderr[-1500:]}')
    match = re.search(r'Selected attributes:\s*([\d, ]+)', result.stdout)
    if not match:
        raise RuntimeError(f'Cannot parse Weka CFS selection: {result.stdout[-1500:]}')
    selected = np.asarray([int(value)-1 for value in match.group(1).split(',') if value.strip()])
    selected = selected[(selected >= 0) & (selected < X.shape[1])]
    if not len(selected):
        raise RuntimeError('Weka CFS selected no predictive features; no silent replacement applied.')
    return selected


def domain_program(source, labels, target):
    if len(np.unique(labels)) < 2:
        return np.full(len(target), float(labels[0])), dict(status='single-class source')
    means = np.vstack([source[labels == c].mean(axis=0) for c in (0, 1)])
    scale = target.std(axis=0, ddof=1) if len(target) > 1 else np.ones(target.shape[1])
    scale = np.where(np.isfinite(scale) & (scale > 1e-12), scale, 1.)
    distances = cdist(target/scale, means/scale)
    n = len(target)
    if n < 2:
        raise ValueError('The original DPP class-mass constraints require at least two target rows.')
    # Each target has class mass 1; each class has total mass >= 1.
    equality = coo_matrix((np.ones(2*n), (np.repeat(np.arange(n), 2), np.arange(2*n))), shape=(n, 2*n)).tocsr()
    lower = coo_matrix((-np.ones(2*n), (np.tile([0, 1], n), np.arange(2*n))), shape=(2, 2*n)).tocsr()
    result = linprog(distances.ravel(), A_ub=lower, b_ub=-np.ones(2),
                     A_eq=equality, b_eq=np.ones(n), bounds=(0, 1), method='highs')
    if not result.success:
        raise RuntimeError(f'DPP LP failed: {result.message}')
    annotation = result.x.reshape(n, 2)
    return annotation[:, 1], dict(status=result.message, objective=float(result.fun),
        class_mass=annotation.sum(axis=0).tolist(), score='LP positive-class annotation; often 0/1')
