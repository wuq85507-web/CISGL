"""Shared IO, evaluation and CLI; no model selection/training branches."""
import argparse
import csv
import hashlib
import json
import time
from dataclasses import dataclass, field
from pathlib import Path

import numpy as np
from threadpoolctl import threadpool_limits
from sklearn.metrics import (roc_auc_score, average_precision_score, matthews_corrcoef,
                             f1_score, precision_score, recall_score, accuracy_score)
from dataset_loader import DEFAULT_ROOT, FAMILIES, load_family, project_paths

ROOT = Path(__file__).resolve().parents[1]


@dataclass
class Result:
    probability: np.ndarray
    selected: np.ndarray
    weights: np.ndarray
    training: dict = field(default_factory=dict)
    selection: dict = field(default_factory=dict)
    distance: object = None
    uncertainty: object = None
    balanced_class_weights: bool = True
    strict_positive_threshold: bool = False


def write_csv(path, rows):
    if not rows:
        return
    with path.open('w', encoding='utf-8-sig', newline='') as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def score(y, p, strict_positive_threshold=False):
    prediction = p > .5 if strict_positive_threshold else p >= .5
    return dict(auc=float(roc_auc_score(y, p)) if len(np.unique(y)) == 2 else None,
                average_precision=float(average_precision_score(y, p)),
                mcc=float(matthews_corrcoef(y, prediction)), f1=float(f1_score(y, prediction, zero_division=0)),
                precision=float(precision_score(y, prediction, zero_division=0)),
                recall=float(recall_score(y, prediction, zero_division=0)),
                accuracy=float(accuracy_score(y, prediction)))


def source_unique(project):
    # Feature-only exact deduplication; keep first row, audit label conflicts.
    _, first, inverse = np.unique(project['X'], axis=0, return_index=True, return_inverse=True)
    first = np.sort(first)
    low = np.full(inverse.max()+1, 2)
    high = np.full(inverse.max()+1, -1)
    np.minimum.at(low, inverse, project['y'])
    np.maximum.at(high, inverse, project['y'])
    return first, int((low != high).sum())




def parser_for(method, defaults):
    parser = argparse.ArgumentParser(description=f'Independent experiment: {method}')
    parser.add_argument('--data-root', type=Path, default=DEFAULT_ROOT)
    parser.add_argument('--dataset', choices=(*FAMILIES, 'paper', 'all'), default='ReLink')
    parser.add_argument('--target')
    parser.add_argument('--seeds', nargs='+', type=int, default=[0])
    parser.add_argument('--graph-beta', type=float, default=.1)
    parser.add_argument('--graph-neighbors', type=int, default=10)
    parser.add_argument('--graph-tuning', choices=['source_lopo', 'fixed'], default='source_lopo')
    parser.add_argument('--graph-beta-grid', nargs='+', type=float, default=[0., .03, .1, .3])
    parser.add_argument('--graph-neighbor-grid', nargs='+', type=int, default=[5, 10])
    parser.add_argument('--graph-c', type=float, default=1.)
    parser.add_argument('--graph-c-grid', nargs='+', type=float, default=[.1, 1., 10.],
                        help='C grid for graph experiments supporting source LOPO tuning')
    parser.add_argument('--nn-filter-neighbors', type=int, default=10)
    parser.add_argument('--peters-cluster-size', type=int, default=10)
    parser.add_argument('--tca-dimension', type=int, default=10)
    parser.add_argument('--tca-mu', type=float, default=1.)
    parser.add_argument('--kmm-bound', type=float, default=10.)
    parser.add_argument('--kmm-landmarks', type=int, default=256)
    parser.add_argument('--kmm-exact-limit', type=int, default=1500,
                        help='RBF KMM exact up to this source size, Nystrom above it; recorded in audit')
    parser.add_argument('--budget-fraction', type=float, default=.5)
    parser.add_argument('--budget', type=int, help='Fixed K instead of budget fraction; capped at source pool size')
    parser.add_argument('--low-fraction', type=float, default=.2)
    parser.add_argument('--target-regions', type=int, default=5)
    parser.add_argument('--distance-quantiles', nargs=2, type=float, default=[.5, .95])
    parser.add_argument('--candidate-multiplier', type=float, default=3.)
    parser.add_argument('--information-ridge', type=float, default=1.,
                        help='Positive fixed ridge for the local Fisher information surrogate')
    parser.add_argument('--coverage-references', type=int, default=512,
                        help='Maximum uniform target reference samples for the gain objective')
    parser.add_argument('--output-dir', type=Path, default=Path('results')/f'independent_{method}')

    parser.add_argument('--lr-c', type=float, default=1.)
    parser.set_defaults(**defaults)
    return parser


def run_cli(method, run, defaults, prepare=None, configure=None):
    parser = parser_for(method, defaults)
    if configure is not None:
        configure(parser)
    args = parser.parse_args()
    vals = [args.budget_fraction, args.low_fraction, *args.distance_quantiles, args.candidate_multiplier]
    if (not np.isfinite(vals).all() or not 0 < args.budget_fraction <= 1
            or not 0 < args.low_fraction < 1 or args.target_regions < 1
            or not 0 <= args.distance_quantiles[0] < args.distance_quantiles[1] <= 1
            or (args.budget is not None and args.budget < 2)
            or args.candidate_multiplier < 1 or args.coverage_references < 1
            or not np.isfinite(args.information_ridge) or args.information_ridge <= 0
            or not np.isfinite(args.graph_beta) or args.graph_beta < 0 or args.graph_neighbors < 1
            or not np.isfinite(args.graph_beta_grid).all() or min(args.graph_beta_grid) < 0
            or min(args.graph_neighbor_grid) < 1
            or not np.isfinite(args.graph_c) or args.graph_c <= 0
            or not np.isfinite(args.graph_c_grid).all() or min(args.graph_c_grid) <= 0
            or args.nn_filter_neighbors < 1 or args.peters_cluster_size < 1
            or args.tca_dimension < 1 or not np.isfinite(args.tca_mu) or args.tca_mu <= 0
            or not np.isfinite(args.kmm_bound) or args.kmm_bound < 1
            or args.kmm_landmarks < 1 or args.kmm_exact_limit < 1
            or not np.isfinite(args.lr_c) or args.lr_c <= 0):
        parser.error('Invalid budget, fraction, quantiles or region count.')

    families = list(FAMILIES[:5]) if args.dataset == 'paper' else list(FAMILIES) if args.dataset == 'all' else [args.dataset]
    config = {k: v for k, v in vars(args).items() if k not in ('output_dir', 'seeds', 'target')}
    config['data_root'] = str(args.data_root.resolve())
    config['method'] = method
    config['entrypoint'] = f'experiments.{method}'
    paths = [ROOT/f for f in ('selection.py', 'graph_lr.py', 'graph_tuning.py', 'transfer_baselines.py', 'dataset_loader.py', 'budget_graph_selection.py')]
    paths += sorted((ROOT/'experiments').glob('*.py'))
    config['code_hash'] = hashlib.sha256(b''.join(p.read_bytes() for p in paths)).hexdigest()
    config['data_hashes'] = {str(p): hashlib.sha256(p.read_bytes()).hexdigest()
                            for family in families for p in project_paths(args.data_root, family)}
    signature = hashlib.sha256(json.dumps(config, sort_keys=True).encode()).hexdigest()[:16]
    args.output_dir.mkdir(parents=True, exist_ok=True)
    manifest = args.output_dir/'config.json'
    encoded = json.dumps(config, ensure_ascii=False, indent=2)
    if manifest.exists() and json.loads(manifest.read_text(encoding='utf-8')) != config:
        parser.error('Configuration/code/data changed; use a fresh output directory.')
    manifest.write_text(encoded, encoding='utf-8')
    output = args.output_dir/'per_run_metrics.csv'
    rows = list(csv.DictReader(output.open(encoding='utf-8-sig', newline=''))) if output.exists() else []
    done = {(r['dataset'], r['target'], int(r['seed'])) for r in rows}
    matched = False
    with threadpool_limits(limits=4):
        for family in families:
            projects = load_family(args.data_root, family)
            for target in projects:
                if args.target and target['name'].lower() != args.target.lower():
                    continue
                matched = True
                remaining_seeds = [s for s in dict.fromkeys(args.seeds) if (family, target['name'], s) not in done]
                if not remaining_seeds:
                    print(f'Skip completed {family}/{target["name"]}: {method}', flush=True)
                    continue
                source_projects = [p for p in projects if p is not target]
                xs, ys, groups, names, indices, audits = [], [], [], [], [], []
                for group, project in enumerate(source_projects):
                    first, conflicts = source_unique(project)
                    xs.append(project['X'][first]); ys.append(project['y'][first])
                    groups.extend([group]*len(first)); names.extend([project['name']]*len(first))
                    indices.extend(project['row_indices'][first].tolist())
                    audits.append(dict(project=project['name'], retained=len(first),
                        duplicate_features_removed=len(project['X'])-len(first), conflicting_feature_groups=conflicts))
                X, y, groups = np.vstack(xs), np.concatenate(ys), np.asarray(groups)
                cache = args.output_dir/'tuning'/f'{family}__{target["name"]}.json'
                # prepare receives source data only. True target labels never reach model code.
                settings = prepare(X, y, groups, args, cache) if prepare else {}
                for seed in remaining_seeds:
                    started = time.perf_counter()
                    result = run(X, y, groups, target['X'], seed, args, settings)
                    elapsed = time.perf_counter()-started
                    chosen = np.asarray(result.selected, dtype=int)
                    probability = np.asarray(result.probability)
                    if len(probability) != len(target['X']) or not np.isfinite(probability).all():
                        raise ValueError('Invalid model probability output.')
                    if len(chosen) != len(np.unique(chosen)) or (chosen < 0).any() or (chosen >= len(X)).any():
                        raise ValueError('Invalid selected source indices.')
                    metrics = score(target['y'], probability, result.strict_positive_threshold)
                    predictions = probability > .5 if result.strict_positive_threshold else probability >= .5
                    classes = len(np.unique(y[chosen]))
                    counts = np.bincount(y[chosen].astype(int), minlength=2)
                    effective = result.weights*(len(chosen)/(2*counts[y[chosen].astype(int)])
                        if classes == 2 and result.balanced_class_weights else 1.)
                    detail = args.output_dir/'runs'/f'{family}__{target["name"]}__seed{seed}'
                    detail.mkdir(parents=True, exist_ok=True)
                    audit = dict(result.selection, sources=audits, target_rows=len(target['X']),
                        target_duplicates_retained=True, features=target['features'],
                        model_module=f'experiments/{method}.py', elapsed_seconds=elapsed)
                    (detail/'audit.json').write_text(json.dumps(audit, indent=2), encoding='utf-8')
                    (detail/f'{method}_training.json').write_text(json.dumps(result.training, indent=2), encoding='utf-8')
                    row = dict(signature=signature, dataset=family, target=target['name'], seed=seed,
                        method=method, classifier=result.training.get('classifier', 'lr'), threshold=.5,
                        threshold_rule='>' if result.strict_positive_threshold else '>=',
                        source_samples=len(X), selected_samples=len(chosen), target_samples=len(target['X']),
                        selected_defect_ratio=float(y[chosen].mean()),
                        weighted_defect_ratio=float(np.dot(effective, y[chosen])/effective.sum()),
                        single_class_support=classes == 1,
                        lr_c=result.training.get('c', args.lr_c),
                        graph_beta=result.training.get('beta', 0.),
                        graph_neighbors=result.training.get('neighbors', 0),
                        graph_tuning=result.training.get('tuning', 'none'),
                        seconds=elapsed, **metrics)
                    write_csv(detail/f'{method}_selection.csv', [dict(pool_index=int(i), project=names[i],
                        input_row=int(indices[i]), label=int(y[i]), sample_weight=float(result.weights[pos]),
                        target_distance=float(result.distance[i]) if result.distance is not None else '',
                        oof_uncertainty=float(result.uncertainty[i]) if result.uncertainty is not None else '',
                        role='all' if method in ('all_source', 'all_source_graph_lr', 'kmm_lr', 'tca_lr')
                        else 'H' if pos < result.selection.get('high_size', 0)
                        else 'L' if result.selection.get('high_size', 0) else 'selected')
                        for pos, i in enumerate(chosen)])
                    write_csv(detail/f'{method}_predictions.csv', [dict(input_row=int(i), label=int(label),
                        probability=float(p), prediction=int(pred))
                        for i, label, p, pred in zip(target['row_indices'], target['y'], probability, predictions)])
                    rows.append(row); write_csv(output, rows)
                    done.add((family, target['name'], seed))
                    print(f'[{family}/{target["name"]}] seed={seed} {method}: AUC={metrics["auc"]} MCC={metrics["mcc"]:.4f}', flush=True)
    if not matched:
        parser.error('No target matched the selected dataset.')
    print(f'Saved {output.resolve()}', flush=True)
