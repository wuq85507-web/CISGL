"""Original H/L -> selected-source linear TCA -> original target graph -> Graph LR."""
from experiments.common import run_cli
from experiments.alignment_graph_support import DEFAULTS, parameters, run_aligned

METHOD = 'coverage_uncertainty_tca_graph_lr'


def prepare(X, y, groups, args, cache):
    return parameters(METHOD, 'tca', X, y, groups, args, cache)


def run(X, y, groups, T, seed, args, settings):
    return run_aligned('tca', X, y, groups, T, seed, args, settings)


def main():
    run_cli(METHOD, run, DEFAULTS, prepare=prepare)


if __name__ == '__main__':
    main()
