"""
Adaptive Spectral Clustering and Structural Alignment (ASCSA)
for Cross-Project Defect Prediction

Based on Singh & Kumar (2026) - IEEE TSE
Implementation of the ASCSA framework for handling intra-project heterogeneity
and structural distribution mismatch in cross-project defect prediction.
"""

import numpy as np
import pandas as pd
from typing import List, Tuple, Dict, Optional
from sklearn.preprocessing import MinMaxScaler
from sklearn.neighbors import NearestNeighbors
from sklearn.cluster import KMeans
from sklearn.linear_model import LogisticRegression
from sklearn.dummy import DummyClassifier
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import TensorDataset, DataLoader, WeightedRandomSampler
from scipy.sparse import csr_matrix
from scipy.linalg import eigh
from scipy.sparse.csgraph import laplacian, connected_components
from scipy.sparse.linalg import eigsh
from imblearn.over_sampling import SMOTE
import warnings



class AdaptiveSpectralClustering:
    """
    Adaptive Spectral Clustering module that partitions source projects
    into coherent clusters to handle intra-project heterogeneity.

    Parameters:
    -----------
    n_neighbors : int or None, default=None
        None uses ceil(log(n)); self is excluded by index, including tied rows.
    sigma : float, default='auto'
        Gaussian kernel bandwidth. If 'auto', estimated from neighbor distances
    """

    def __init__(self, n_neighbors: Optional[int] = None, sigma: str = 'auto',
                 random_state: int = 42, max_clusters: int = 30):
        self.n_neighbors = n_neighbors
        self.sigma = sigma
        self.random_state = random_state
        self.max_clusters = max_clusters
        self.clusters = None
        self.n_clusters = None

    def _estimate_bandwidth(self, distances: np.ndarray) -> float:
        """Estimate Gaussian kernel bandwidth from neighbor distances."""
        return max(float(np.median(distances[:, -1])), 1e-8)

    def _construct_knn_graph(self, X: np.ndarray) -> np.ndarray:
        """Construct k-NN similarity graph using Gaussian kernel."""
        n_samples = X.shape[0]

        # Find k nearest neighbors
        k = min(self.n_neighbors or max(1, int(np.ceil(np.log(n_samples)))), n_samples - 1)
        nbrs = NearestNeighbors(n_neighbors=k + 1).fit(X)
        raw_distances, raw_indices = nbrs.kneighbors(X)
        indices = np.empty((n_samples, k), dtype=int)
        distances = np.empty((n_samples, k), dtype=float)
        for i in range(n_samples):
            keep = raw_indices[i] != i
            indices[i] = raw_indices[i, keep][:k]
            distances[i] = raw_distances[i, keep][:k]

        # Estimate bandwidth
        if self.sigma == 'auto':
            sigma = self._estimate_bandwidth(distances)
        else:
            sigma = float(self.sigma)
        if sigma <= 0:
            raise ValueError('Graph bandwidth must be positive.')
        self.bandwidth_ = sigma
        self.n_neighbors_ = k

        # Build sparse adjacency matrix with Gaussian kernel weights
        # Construct directed edges once, then use the union of kNN neighborhoods.
        # Adding both directions before CSR construction doubles mutual edges.
        W = csr_matrix((np.exp(-distances.ravel() ** 2 / (2 * sigma ** 2)),
                        (np.repeat(np.arange(n_samples), k), indices.ravel())),
                       shape=(n_samples, n_samples))
        return W.maximum(W.T)

    def _compute_laplacian(self, W: np.ndarray) -> np.ndarray:
        """Compute symmetric normalized graph Laplacian."""
        return laplacian(W, normed=True)

    def _estimate_clusters(self, eigenvalues: np.ndarray) -> int:
        """Estimate optimal number of clusters using eigengap heuristic."""
        gaps = np.diff(eigenvalues)
        k = np.argmax(gaps) + 1
        return max(1, int(k))

    def fit_predict(self, X: np.ndarray) -> Tuple[np.ndarray, int]:
        """
        Partition source project into coherent clusters.

        Returns:
        --------
        cluster_labels : np.ndarray
            Cluster assignment for each instance
        n_clusters : int
            Number of clusters identified
        """
        n_samples = X.shape[0]

        if n_samples < 3:
            # If dataset too small, return single cluster
            self.n_clusters = 1
            self.clusters = np.zeros(n_samples, dtype=int)
            self.diagnostics_ = dict(samples=n_samples, clusters=1, neighbors=0,
                                     bandwidth=None, components=n_samples,
                                     eigenvalues=[], search_limit_hit=False)
            return np.zeros(n_samples, dtype=int), 1

        # Step 1: Construct k-NN graph
        W = self._construct_knn_graph(X)

        # Step 2: Compute normalized Laplacian
        L_sym = self._compute_laplacian(W)

        # Step 3: Eigen-decomposition
        # The paper does not give an eigengap search range. Expose the bounded
        # approximation; max_clusters=0 requests its literal full-spectrum rule.
        if self.max_clusters < 0:
            raise ValueError('max_clusters must be nonnegative.')
        if self.max_clusters == 0 and n_samples > 2000:
            raise ValueError('Full spectrum is limited to 2000 rows to avoid dense allocation. '
                             'Use an explicitly bounded --max-clusters for this project.')
        n_eigen = min(self.max_clusters + 1, n_samples) if self.max_clusters else n_samples
        if n_samples <= 512 or n_eigen == n_samples:
            eigenvalues, eigenvectors = eigh(L_sym.toarray(), subset_by_index=[0, n_eigen - 1])
        else:
            rng = np.random.default_rng(self.random_state)
            # L_sym is positive semidefinite. A negative shift selects the
            # same smallest eigenvalues without factoring the singular L_sym.
            eigenvalues, eigenvectors = eigsh(
                L_sym.tocsc(), k=n_eigen, sigma=-1e-5, which='LM',
                v0=rng.normal(size=n_samples), tol=1e-7,
                ncv=min(n_samples, max(4 * n_eigen + 1, 80)), maxiter=3000)
            order = np.argsort(eigenvalues)
            eigenvalues, eigenvectors = eigenvalues[order], eigenvectors[:, order]
        eigenvalues = np.real(eigenvalues)
        residual = np.linalg.norm(
            L_sym @ eigenvectors - eigenvectors * eigenvalues, axis=0)
        if (len(eigenvalues) != n_eigen or not np.isfinite(residual).all()
                or float(residual.max()) > 1e-6):
            raise RuntimeError('ASCSA eigenpairs failed the original-Laplacian residual check.')

        # Step 4: Determine optimal number of clusters
        self.n_clusters = self._estimate_clusters(eigenvalues)
        self.diagnostics_ = dict(samples=n_samples, clusters=self.n_clusters,
                                 neighbors=self.n_neighbors_, bandwidth=self.bandwidth_,
                                 components=int(connected_components(W, directed=False)[0]),
                                 eigenvalues=eigenvalues.tolist(),
                                 eigensolver='dense_eigh' if n_samples <= 512 or n_eigen == n_samples else 'shift_invert',
                                 eigen_shift=None if n_samples <= 512 or n_eigen == n_samples else -1e-5,
                                 max_eigen_residual=float(residual.max()),
                                 search_limit_hit=bool(n_eigen < n_samples and
                                                       self.n_clusters == n_eigen - 1))

        # Step 5: Spectral embedding using first C eigenvectors
        U = eigenvectors[:, :self.n_clusters]

        # Step 6: Apply k-means to spectral embedding
        kmeans = KMeans(n_clusters=self.n_clusters, random_state=self.random_state, n_init=10)
        labels = kmeans.fit_predict(U)

        self.clusters = labels
        return labels, self.n_clusters


class StructuralAlignment:
    """
    Structural Alignment module that selects source clusters whose
    metric relationships most closely resemble the target project.

    Parameters:
    -----------
    top_k : int, default=None
        Number of top-ranked clusters to select. If None, select top 50%.
    """

    def __init__(self, top_k: Optional[int] = None):
        self.top_k = top_k
        self.similarity_scores = None

    def _compute_correlation_structure(self, X: np.ndarray) -> np.ndarray:
        """Compute Pearson correlation matrix for features."""
        if len(X) < 2:
            return np.eye(X.shape[1])
        with np.errstate(divide='ignore', invalid='ignore'):
            correlation = np.atleast_2d(np.corrcoef(X, rowvar=False))
        correlation = np.nan_to_num(correlation, nan=0.0)
        np.fill_diagonal(correlation, 1.0)
        return correlation

    def _compute_frobenius_distance(self, R1: np.ndarray, R2: np.ndarray) -> float:
        """Compute Frobenius norm distance between correlation matrices."""
        return np.linalg.norm(R1 - R2, ord='fro')

    def select_clusters(self, source_clusters: List[np.ndarray],
                       target_data: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
        """
        Select structurally similar source clusters for training.

        Parameters:
        -----------
        source_clusters : List[np.ndarray]
            List of source cluster data arrays
        target_data : np.ndarray
            Target project feature matrix

        Returns:
        --------
        selected_data : np.ndarray
            Combined data from selected clusters
        selected_indices : np.ndarray
            Indices of selected clusters
        """
        # Compute target correlation structure
        R_target = self._compute_correlation_structure(target_data)

        # Compute structural similarity for each cluster
        scores = []
        for cluster_data in source_clusters:
            if len(cluster_data) >= 2:
                R_cluster = self._compute_correlation_structure(cluster_data)
                score = self._compute_frobenius_distance(R_cluster, R_target)
                scores.append(score)
            else:
                scores.append(np.inf)

        self.similarity_scores = np.array(scores)

        # Determine number of clusters to select
        n_clusters = len(source_clusters)
        k = self.top_k if self.top_k is not None else max(1, n_clusters // 2)
        k = min(k, int(np.isfinite(scores).sum()))
        if k < 1:
            raise ValueError('No source cluster has at least two rows for correlation ranking.')

        # Select top-k clusters with lowest structural distance
        selected_indices = np.argsort(scores, kind='stable')[:k]

        # Combine selected cluster data
        selected_data = np.vstack([source_clusters[i] for i in selected_indices
                                 if len(source_clusters[i]) > 0])

        return selected_data, selected_indices


class MMDLoss(nn.Module):
    """
    Maximum Mean Discrepancy (MMD) loss for distribution alignment.
    Minimizes the distance between source and target feature distributions.

    Parameters:
    -----------
    kernel : str, default='rbf'
        Kernel type: 'rbf' or 'linear'
    """

    def __init__(self, kernel: str = 'rbf', sigma: float = 1.0):
        super(MMDLoss, self).__init__()
        self.kernel = kernel
        self.sigma = sigma

    def _compute_kernel(self, X: torch.Tensor, Y: torch.Tensor) -> torch.Tensor:
        """Compute kernel matrix between samples."""
        if self.kernel == 'rbf':
            # RBF kernel: exp(-||x-y||^2 / (2*sigma^2))
            XX = torch.mm(X, X.t())
            YY = torch.mm(Y, Y.t())
            XY = torch.mm(X, Y.t())

            X_sqnorms = torch.diagonal(XX)
            Y_sqnorms = torch.diagonal(YY)

            K_XX = X_sqnorms.unsqueeze(1) + X_sqnorms.unsqueeze(0) - 2 * XX
            K_YY = Y_sqnorms.unsqueeze(1) + Y_sqnorms.unsqueeze(0) - 2 * YY
            K_XY = X_sqnorms.unsqueeze(1) + Y_sqnorms.unsqueeze(0) - 2 * XY

            K_XX = torch.exp(-K_XX.clamp_min(0) / (2 * self.sigma ** 2))
            K_YY = torch.exp(-K_YY.clamp_min(0) / (2 * self.sigma ** 2))
            K_XY = torch.exp(-K_XY.clamp_min(0) / (2 * self.sigma ** 2))
        else:  # linear kernel
            K_XX = torch.mm(X, X.t())
            K_YY = torch.mm(Y, Y.t())
            K_XY = torch.mm(X, Y.t())

        return K_XX, K_YY, K_XY

    def forward(self, X: torch.Tensor, Y: torch.Tensor) -> torch.Tensor:
        """
        Compute MMD loss.

        Parameters:
        -----------
        X : torch.Tensor
            Source domain features
        Y : torch.Tensor
            Target domain features

        Returns:
        --------
        mmd_loss : torch.Tensor
            Scalar MMD loss value
        """
        K_XX, K_YY, K_XY = self._compute_kernel(X, Y)

        m = X.size(0)
        n = Y.size(0)

        # MMD = || E_X[phi(x)] - E_Y[phi(y)] ||^2
        # = E[k(x,x')] + E[k(y,y')] - 2*E[k(x,y)]
        mmd_loss = (K_XX.sum() / (m * m) +
                   K_YY.sum() / (n * n) -
                   2 * K_XY.sum() / (m * n))

        return torch.clamp(mmd_loss, min=0.0)


class DefectPredictionDNN(nn.Module):
    """
    Deep Neural Network for defect prediction with MMD-based domain adaptation.

    Parameters:
    -----------
    input_dim : int
        Input feature dimension
    hidden_dims : List[int], default=[128, 128]
        Hidden layer dimensions
    dropout_rate : float, default=0.2
        Dropout rate for regularization
    """

    def __init__(self, input_dim: int, hidden_dims: List[int] = None,
                 dropout_rate: float = 0.2):
        super(DefectPredictionDNN, self).__init__()

        if hidden_dims is None:
            hidden_dims = [128, 128]

        layers = []
        prev_dim = input_dim

        # Build hidden layers
        for hidden_dim in hidden_dims:
            layers.append(nn.Linear(prev_dim, hidden_dim))
            layers.append(nn.ReLU())
            layers.append(nn.Dropout(dropout_rate))
            prev_dim = hidden_dim

        self.feature_extractor = nn.Sequential(*layers)
        self.classifier = nn.Linear(prev_dim, 1)

    def forward_with_features(self, x: torch.Tensor):
        features = self.feature_extractor(x)
        return self.classifier(features), features

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """Forward pass for defect prediction."""
        return torch.sigmoid(self.forward_with_features(x)[0])

    def extract_features(self, x: torch.Tensor) -> torch.Tensor:
        """Extract learned features (before output layer)."""
        return self.feature_extractor(x)


class ASCSAFramework:
    """
    Complete ASCSA framework for cross-project defect prediction.

    Parameters:
    -----------
    n_neighbors : int or None, default=None
        Number of neighbors for spectral clustering
    top_k : int, default=5
        Top-k clusters selected globally across all source projects
    learning_rate : float, default=0.001
        Learning rate for DNN training
    epochs : int, default=20
        Number of training epochs
    batch_size : int, default=64
        Batch size for training
    mmd_weight : float, default=0.5
        Weight for MMD loss term
    """

    def __init__(self, n_neighbors: Optional[int] = None, top_k: Optional[int] = 5,
                 learning_rate: float = 0.001, epochs: int = 20,
                 batch_size: int = 64, mmd_weight: float = 0.5,
                 hidden_dims: List[int] = None, random_state: int = 42,
                 device: str = 'auto', max_clusters: int = 30,
                 mmd_sigma: float = 1.0, classifier: str = 'dnn'):

        self.n_neighbors = n_neighbors
        self.top_k = top_k
        self.learning_rate = learning_rate
        self.epochs = epochs
        self.batch_size = batch_size
        self.mmd_weight = mmd_weight
        self.hidden_dims = hidden_dims or [128, 128]
        self.random_state = random_state
        self.max_clusters = max_clusters
        self.mmd_sigma = mmd_sigma
        self.classifier_name = classifier
        if mmd_sigma <= 0 or classifier not in ('dnn', 'lr'):
            raise ValueError('Use a positive MMD sigma and classifier dnn or lr.')

        self.scaler = MinMaxScaler()
        self.model = None
        self.device = torch.device(('cuda' if torch.cuda.is_available() else 'cpu') if device == 'auto' else device)

    def preprocess(self, sources: List[np.ndarray], target: np.ndarray) -> Tuple[List[np.ndarray], np.ndarray]:
        """
        Sources include labels in the last column; target contains features only.
        Deduplicate feature vectors, keep first row in file order, source-only
        SMOTE, then independent Min-Max per project. Target labels are absent.
        """
        # Remove missing values and duplicates
        def clean_data(data, labeled):
            data = np.asarray(data, dtype=float)
            finite_indices = np.flatnonzero(np.isfinite(data).all(axis=1))
            finite = data[finite_indices]
            features = finite[:, :-1] if labeled else finite
            _, first, inverse = np.unique(features, axis=0, return_index=True, return_inverse=True)
            keep = np.sort(first)
            conflicts = 0
            if labeled and len(finite):
                lower = np.full(len(first), np.inf)
                upper = np.full(len(first), -np.inf)
                np.minimum.at(lower, inverse, finite[:, -1])
                np.maximum.at(upper, inverse, finite[:, -1])
                conflicts = int((lower != upper).sum())
            if not len(keep):
                raise ValueError('Project is empty after cleaning.')
            return finite[keep], finite_indices[keep], dict(
                input_rows=len(data), invalid_rows=len(data) - len(finite),
                duplicate_features_removed=len(finite) - len(keep),
                conflicting_feature_groups=conflicts, cleaned_rows=len(keep))

        self.preprocessing_audit_ = []
        sources_clean = []
        self.source_input_indices_ = []
        for source in sources:
            clean, input_indices, audit = clean_data(source, labeled=True)
            if not np.isin(clean[:, -1], [0, 1]).all():
                raise ValueError('Source labels must be binary 0/1.')
            sources_clean.append(clean)
            self.source_input_indices_.append(input_indices)
            self.preprocessing_audit_.append(audit)
        target_clean, self.target_indices_, self.target_audit_ = clean_data(target, labeled=False)

        # Apply SMOTE to source projects (with separate labels)
        # Note: Assuming last column is the label
        sources_balanced = []
        for source in sources_clean:
            X = source[:, :-1]
            y = source[:, -1]

            counts = np.unique(y, return_counts=True)[1]
            audit = self.preprocessing_audit_[len(sources_balanced)]
            audit['defects_before_smote'] = int(y.sum())
            audit['smote_neighbors'] = None
            if len(counts) == 2 and counts.min() >= 2 and counts[0] != counts[1]:
                neighbors = min(5, int(counts.min()) - 1)
                smote = SMOTE(random_state=self.random_state, k_neighbors=neighbors)
                X_balanced, y_balanced = smote.fit_resample(X, y)
                sources_balanced.append(np.column_stack([X_balanced, y_balanced]))
                audit['smote_neighbors'] = neighbors
            else:
                sources_balanced.append(source)
                if len(counts) < 2 or counts.min() < 2:
                    warnings.warn('SMOTE skipped: source has one class or fewer than two minority rows.')
            audit['resampled_rows'] = len(sources_balanced[-1])
            audit['defects_after_smote'] = int(sources_balanced[-1][:, -1].sum())

        # Independent source scalers; prediction reuses only the fitted target scaler.
        self.source_scalers_ = []
        sources_normalized = []
        for source in sources_balanced:
            X = source[:, :-1]
            y = source[:, -1:]
            scaler = MinMaxScaler()
            X_norm = scaler.fit_transform(X)
            self.source_scalers_.append(scaler)
            sources_normalized.append(np.column_stack([X_norm, y]))

        target_normalized = self.scaler.fit_transform(target_clean)

        return sources_normalized, target_normalized

    def fit(self, sources: List[np.ndarray], target: np.ndarray,
            target_labels: Optional[np.ndarray] = None, prepare_only: bool = False) -> 'ASCSAFramework':
        """
        Train ASCSA framework on source and target projects.
        """
        np.random.seed(self.random_state)
        torch.manual_seed(self.random_state)
        if torch.cuda.is_available():
            torch.cuda.manual_seed_all(self.random_state)
        feature_count = sources[0].shape[1] - 1
        # Compatibility with the previous synthetic demo: discard target labels
        # immediately. No target labels enter preprocessing, selection or loss.
        if target.shape[1] == feature_count + 1:
            target = target[:, :-1]
        if target.shape[1] != feature_count or any(s.shape[1] != feature_count + 1 for s in sources):
            raise ValueError('Source and target feature schemas must match.')
        self.training_history_ = []
        # Preprocessing
        sources_proc, target_proc = self.preprocess(sources, target)
        self.sources_processed_ = sources_proc
        self.target_processed_ = target_proc

        # Step 1: Adaptive Spectral Clustering
        print("Step 1: Performing Adaptive Spectral Clustering...")
        asc = AdaptiveSpectralClustering(n_neighbors=self.n_neighbors, random_state=self.random_state,
                                        max_clusters=self.max_clusters)
        source_clusters = []
        self.clustering_audit_ = []
        self.cluster_audit_ = []
        self.cluster_original_indices_ = []
        source_offset = 0

        for i, source in enumerate(sources_proc):
            X_source = source[:, :-1]
            y_source = source[:, -1]

            print(f"  Source {i}: clustering {len(X_source)} rows...", flush=True)
            labels, n_clusters = asc.fit_predict(X_source)
            self.clustering_audit_.append(dict(source_index=i, **asc.diagnostics_))
            clusters = [source[labels == j] for j in range(n_clusters)]
            for j, cluster in enumerate(clusters):
                original = self.source_input_indices_[i]
                self.cluster_original_indices_.append(
                    source_offset + original[labels[:len(original)] == j])
                self.cluster_audit_.append(dict(cluster_index=len(self.cluster_audit_),
                                               source_index=i, local_cluster=j,
                                               size=len(cluster),
                                               defect_ratio=float(cluster[:, -1].mean()),
                                               constant_features=int((np.ptp(cluster[:, :-1], axis=0) == 0).sum())))
            source_clusters.extend(clusters)
            source_offset += len(sources[i])
            print(f"  Source {i}: {n_clusters} clusters identified; max eigen residual={asc.diagnostics_.get('max_eigen_residual', 0.):.2e}", flush=True)

        # Step 2: Structural Alignment
        print("Step 2: Performing Structural Alignment...")
        sa = StructuralAlignment(top_k=self.top_k)
        X_target = target_proc

        _, selected_indices = sa.select_clusters([c[:, :-1] for c in source_clusters], X_target)
        selected_data = np.vstack([source_clusters[i] for i in selected_indices])
        self.selected_clusters_ = selected_indices
        self.cluster_distances_ = sa.similarity_scores
        self.selected_samples_ = len(selected_data)
        self.selected_original_indices_ = np.sort(np.concatenate(
            [self.cluster_original_indices_[i] for i in selected_indices]))
        self.source_clusters_ = source_clusters
        for i, audit in enumerate(self.cluster_audit_):
            score = sa.similarity_scores[i]
            audit['distance'] = float(score) if np.isfinite(score) else None
            audit['selected'] = bool(i in selected_indices)
        X_selected = selected_data[:, :-1]
        y_selected = selected_data[:, -1]
        self.selected_defect_ratio_ = float(y_selected.mean())
        print(f"  Selected {len(selected_indices)} clusters for training")

        if prepare_only:
            return self

        if self.classifier_name == 'lr':
            self.model = (LogisticRegression(C=1.0, solver='lbfgs', max_iter=1000,
                                            random_state=self.random_state)
                          if len(np.unique(y_selected)) > 1 else DummyClassifier(strategy='prior'))
            self.model.fit(X_selected, y_selected)
            return self

        # Step 3: Train DNN with MMD loss
        print("Step 3: Training DNN with MMD loss...")
        self.model = DefectPredictionDNN(input_dim=X_selected.shape[1],
                                         hidden_dims=self.hidden_dims, dropout_rate=0.2).to(self.device)

        self._train_mmd_model(X_selected, y_selected, X_target)

        return self

    def _train_mmd_model(self, X_source: np.ndarray, y_source: np.ndarray,
                        X_target: np.ndarray, sample_weights=None, epoch_samples=None):
        """Train DNN with classification and MMD losses."""
        # Convert to tensors
        X_src_tensor = torch.FloatTensor(X_source).to(self.device)
        y_src_tensor = torch.FloatTensor(y_source.reshape(-1, 1)).to(self.device)
        X_tgt_tensor = torch.FloatTensor(X_target).to(self.device)

        # Create data loaders
        source_dataset = TensorDataset(X_src_tensor, y_src_tensor)
        if sample_weights is None:
            source_loader = DataLoader(source_dataset, batch_size=self.batch_size, shuffle=True)
        else:
            probabilities = np.asarray(sample_weights, dtype=float)
            if (probabilities.shape != (len(X_source),) or not np.isfinite(probabilities).all()
                    or (probabilities < 0).any() or probabilities.sum() <= 0):
                raise ValueError('Invalid source sampling weights.')
            generator = torch.Generator().manual_seed(self.random_state)
            sampler = WeightedRandomSampler(torch.as_tensor(probabilities, dtype=torch.double),
                                            num_samples=epoch_samples or len(X_source),
                                            replacement=True, generator=generator)
            source_loader = DataLoader(source_dataset, batch_size=self.batch_size, sampler=sampler)

        # Optimizer and loss functions
        optimizer = optim.Adam(self.model.parameters(), lr=self.learning_rate)
        ce_loss = nn.BCEWithLogitsLoss()
        mmd_loss = MMDLoss(kernel='rbf', sigma=self.mmd_sigma)

        # Training loop
        self.model.train()
        for epoch in range(self.epochs):
            total_loss = 0.0
            classification_loss = 0.0
            alignment_loss = 0.0
            samples_seen = 0

            for X_batch, y_batch in source_loader:
                # Forward pass
                logits, features_source = self.model.forward_with_features(X_batch)

                # Classification loss
                ce = ce_loss(logits, y_batch)

                # MMD loss
                # Bound quadratic kernel memory by sampling an unlabeled target batch.
                target_idx = torch.randperm(len(X_tgt_tensor), device=self.device)[:self.batch_size]
                features_target = self.model.extract_features(X_tgt_tensor[target_idx])
                mmd = mmd_loss(features_source, features_target)

                # Combined loss
                loss = ce + self.mmd_weight * mmd
                if not torch.isfinite(loss):
                    raise FloatingPointError('Nonfinite training loss.')

                # Backward pass
                optimizer.zero_grad()
                loss.backward()
                optimizer.step()

                count = len(X_batch)
                total_loss += loss.item() * count
                classification_loss += ce.item() * count
                alignment_loss += mmd.item() * count
                samples_seen += count

            record = dict(epoch=epoch + 1, total=total_loss / samples_seen,
                          classification=classification_loss / samples_seen,
                          mmd=alignment_loss / samples_seen, source_samples_seen=samples_seen,
                          optimizer_steps=len(source_loader))
            self.training_history_.append(record)
            print(f"  Epoch {epoch + 1}/{self.epochs} total={record['total']:.4f} "
                  f"classification={record['classification']:.4f} mmd={record['mmd']:.4f}")

    def predict(self, X: np.ndarray) -> np.ndarray:
        """Predict defect labels for new instances."""
        X_norm = self.scaler.transform(X)
        if self.classifier_name == 'lr':
            probabilities = self.model.predict_proba(X_norm)
            classes = list(self.model.classes_)
            return probabilities[:, classes.index(1)] if 1 in classes else np.zeros(len(X_norm))
        X_tensor = torch.FloatTensor(X_norm).to(self.device)

        self.model.eval()
        with torch.no_grad():
            y_pred = self.model(X_tensor)

        return y_pred.cpu().numpy().flatten()

    def predict_proba(self, X: np.ndarray) -> np.ndarray:
        """Predict defect probabilities."""
        return self.predict(X)
