"""DSSDPP: source MMD -> released MPOS -> exact Weka CFS -> domain LP."""
from experiments.paper_baseline_support import run_paper_cli

if __name__ == '__main__':
    run_paper_cli('dssdpp')
