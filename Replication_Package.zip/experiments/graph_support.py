"""Source-only tuning shared by the two independent graph experiments."""
import json
import time
from graph_tuning import tune_graph
from budget_graph_selection import METHODS as BUDGET_GRAPH_METHODS


def parameters(method, X, y, groups, args, cache):
    if args.graph_tuning == 'fixed':
        return dict(beta=args.graph_beta, neighbors=args.graph_neighbors,
                    c=args.graph_c if args.dataset in ('GitHub15', 'NASA_D2') or method in ('coverage_uncertainty_graph_lr', 'coverage_random_graph_lr', *BUDGET_GRAPH_METHODS) else 1.)
    records = json.loads(cache.read_text(encoding='utf-8')) if cache.exists() else {}
    if method not in records:
        print(f'Source LOPO tuning: {method}; reused across seeds', flush=True)
        started = time.perf_counter()
        record = tune_graph(X, y, groups, [method], budget=args.budget,
            budget_fraction=args.budget_fraction, low_fraction=args.low_fraction,
            regions=args.target_regions, quantiles=args.distance_quantiles,
            candidate_multiplier=args.candidate_multiplier, information_ridge=args.information_ridge,
            betas=args.graph_beta_grid, neighbors=list(dict.fromkeys(args.graph_neighbor_grid)),
            c_grid=args.graph_c_grid, tune_all_c=args.dataset in ('GitHub15', 'NASA_D2'))[method]
        record['tuning_seconds_batch'] = time.perf_counter()-started
        records[method] = record
        cache.parent.mkdir(exist_ok=True)
        cache.write_text(json.dumps(records, indent=2), encoding='utf-8')
    return records[method]['best']
