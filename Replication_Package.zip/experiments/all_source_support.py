"""Source-only LOPO for full-source LR controls; same scorer as the main model."""
import json
import time
from graph_tuning import tune_graph


def parameters(method, graph, X, y, groups, args, cache):
    if args.graph_tuning == 'fixed':
        return dict(c=args.graph_c if graph else args.lr_c,
                    beta=args.graph_beta if graph else 0.,
                    neighbors=args.graph_neighbors if graph else 0,
                    candidate_count=1)
    records = json.loads(cache.read_text(encoding='utf-8')) if cache.exists() else {}
    if method not in records:
        print(f'Source LOPO tuning: {method}; full source; reused across seeds', flush=True)
        started = time.perf_counter()
        # The tuner only receives source features, labels and project groups.
        # Its all_source_graph_lr branch retains every training-source row.
        record = tune_graph(X, y, groups, ['all_source_graph_lr'],
            budget=None, budget_fraction=1., low_fraction=args.low_fraction,
            regions=args.target_regions, quantiles=args.distance_quantiles,
            candidate_multiplier=args.candidate_multiplier,
            information_ridge=args.information_ridge,
            betas=args.graph_beta_grid if graph else [0.],
            neighbors=list(dict.fromkeys(args.graph_neighbor_grid)) if graph else [1],
            c_grid=args.graph_c_grid, tune_all_c=True)['all_source_graph_lr']
        record.update(tuning_seconds_batch=time.perf_counter()-started,
                      source_policy='all original source rows in every LOPO training fold',
                      classifier='graph_lr' if graph else 'lr',
                      candidate_count=len(record['candidates']))
        records[method] = record
        cache.parent.mkdir(parents=True, exist_ok=True)
        cache.write_text(json.dumps(records, indent=2), encoding='utf-8')
    record = records[method]
    return dict(record['best'], candidate_count=len(record['candidates']))
