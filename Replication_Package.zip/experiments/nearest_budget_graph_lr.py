"""Fixed-budget nearest-target source selection + target graph LR."""
from experiments.common import run_cli
from experiments.graph_support import parameters
from experiments.budget_graph_support import DEFAULTS, run_selected

METHOD = 'nearest_budget_graph_lr'


def prepare(X, y, groups, args, cache):
    return parameters(METHOD, X, y, groups, args, cache)


def run(X, y, groups, T, seed, args, settings):
    return run_selected(METHOD, X, y, groups, T, seed, args, settings)


def main():
    run_cli(METHOD, run, DEFAULTS, prepare=prepare)


if __name__ == '__main__':
    main()
