"""Shared distance/coverage primitives; each model owns its final selection rule."""
from types import SimpleNamespace
import numpy as np
from sklearn.neighbors import NearestNeighbors
from sklearn.preprocessing import StandardScaler
from selection import compress, coverage_order, oof_uncertainty


def sample_budget(X, args):
    count = min(len(X), args.budget) if args.budget is not None else max(2, int(len(X)*args.budget_fraction))
    if not 2 <= count <= len(X):
        raise ValueError('Budget must be between 2 and source pool size.')
    return count


def geometry(X, T):
    raw_source, raw_target = compress(X), compress(T)
    scaler = StandardScaler().fit(raw_source)
    S, Z = scaler.transform(raw_source), scaler.transform(raw_target)
    distance = NearestNeighbors(n_neighbors=1, n_jobs=1).fit(Z).kneighbors(S)[0][:, 0]
    return raw_source, raw_target, S, Z, distance


def coverage_inputs(X, y, groups, T, seed, args, need_uncertainty=False, need_low=False):
    budget = sample_budget(X, args)
    raw_source, raw_target, S, Z, distance = geometry(X, T)
    coverage = coverage_order(S, Z, args.target_regions, seed)
    n_low = max(1, min(budget-1, round(budget*args.low_fraction)))
    high = coverage[:budget-n_low]
    remaining = np.setdiff1d(np.arange(len(X)), high)
    uncertainty, protocol = (oof_uncertainty(raw_source, y, groups, seed) if need_uncertainty
                             else (None, 'not used by this model'))
    low = None
    audit = dict(budget=budget, high_size=len(high), low_size=n_low,
        oof_protocol=protocol, target_regions=min(args.target_regions, len(np.unique(Z, axis=0))))
    if need_low:
        lower, upper = np.quantile(distance, args.distance_quantiles)
        low = remaining[(distance[remaining] >= lower) & (distance[remaining] <= upper)]
        if len(low) < n_low:
            raise ValueError(f'Only {len(low)} low-similarity candidates for {n_low} slots.')
        audit.update(low_candidates=len(low), distance_lower=float(lower), distance_upper=float(upper))
    return SimpleNamespace(budget=budget, raw_source=raw_source, raw_target=raw_target,
        S=S, Z=Z, distance=distance, coverage=coverage, n_low=n_low, high=high,
        remaining=remaining, uncertainty=uncertainty, low=low, audit=audit)


def uncertain_pool(context, args):
    count = min(len(context.remaining), max(context.n_low, int(np.ceil(args.candidate_multiplier*context.n_low))))
    return context.remaining[np.argsort(-context.uncertainty[context.remaining], kind='stable')[:count]]
