"""Random fixed-budget subset; same C/beta/k LOPO grid as the main model."""
from experiments.fair_ablation_support import main

if __name__ == '__main__':
    main('fair_random_graph_lr', 'random', True)
