"""Random fixed-budget source subset; C chosen by source-project LOPO."""
from experiments.fair_ablation_support import main

if __name__ == '__main__':
    main('fair_random_lr', 'random', False)
