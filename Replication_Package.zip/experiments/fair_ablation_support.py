"""Fixed-budget ablations with source-project LOPO; no real target labels.

Standalone extension: existing selection, graph, optimizer and IO are reused.
No changes to graph_tuning.py or any existing experiment are required.
"""
import json
import time
import numpy as np
from sklearn.metrics import roc_auc_score, matthews_corrcoef
from selection import compress, coverage_order, oof_uncertainty, fit_lr, positive_probability
from graph_lr import target_graph, graph_quadratic, fit_graph_lr
from experiments.common import Result, run_cli
from experiments.selection_support import sample_budget, geometry

DEFAULTS = dict(budget_fraction=.25, graph_tuning='source_lopo', graph_c=1.,
                graph_c_grid=[.1, 1., 10.], graph_beta_grid=[0., .03, .1, .3],
                graph_neighbor_grid=[5, 10])


def select(rule, X, y, groups, T, seed, args):
    count = sample_budget(X, args)
    distance, uncertainty = None, None
    audit = dict(budget=count, original_size=len(X), sampled_size=count,
                 sample_rate=count/len(X), high_size=0, low_size=0)
    if rule == 'random':
        chosen = np.sort(np.random.default_rng(seed).choice(len(X), count, replace=False))
        audit.update(rule='uniform random source subset, without replacement')
    elif rule == 'coverage':
        _, _, source, target, distance = geometry(X, T)
        chosen = coverage_order(source, target, args.target_regions, seed)[:count]
        audit.update(rule='target-region coverage only; full retained budget', high_size=count,
                     target_regions=min(args.target_regions, len(np.unique(target, axis=0))))
    elif rule == 'uncertainty':
        uncertainty, protocol = oof_uncertainty(compress(X), y, groups, seed)
        chosen = np.argsort(-uncertainty, kind='stable')[:count]
        audit.update(rule='project-grouped OOF uncertainty only; full retained budget',
                     low_size=count, oof_protocol=protocol)
    else:
        raise ValueError(f'Unknown ablation rule: {rule}')
    assert len(chosen) == count and len(np.unique(chosen)) == count
    return chosen, distance, uncertainty, audit


def candidates(args, graph):
    cs = list(dict.fromkeys(float(c) for c in args.graph_c_grid))
    if not graph:
        return [(c, 0., 0) for c in cs]
    ks = list(dict.fromkeys(int(k) for k in args.graph_neighbor_grid))
    return [(c, float(beta), k) for c in cs
            for beta in dict.fromkeys(args.graph_beta_grid)
            for k in (ks[:1] if beta == 0 else ks)]


def tune(rule, graph, X, y, groups, args):
    grid = candidates(args, graph)
    rows = []
    for held_out in np.unique(groups):
        train, valid = groups != held_out, groups == held_out
        if np.unique(y[valid]).size < 2:
            continue
        if int(train.sum()) < 2:
            continue
        sx, sy, sg, target = X[train], y[train], groups[train], X[valid]
        chosen, _, _, _ = select(rule, sx, sy, sg, target, 0, args)
        source, target = compress(sx), compress(target)
        bases = {c: fit_lr(source[chosen], sy[chosen], 0, c=c) for c in {g[0] for g in grid}}
        if graph:
            edges = {k: target_graph(source, target, k) for k in {g[2] for g in grid}}
            base = next(iter(bases.values()))
            scaled_target = base.steps[0][1].transform(target)
            quadratics = {k: graph_quadratic(scaled_target, edge) for k, edge in edges.items()}
        for c, beta, k in grid:
            if graph:
                model, _ = fit_graph_lr(source[chosen], sy[chosen], target, edges[k], 0,
                    beta, c=c, base_model=bases[c], quadratic=quadratics[k])
            else:
                model = bases[c]
            probability = positive_probability(model, target)
            rows.append(dict(held_out_source=int(held_out), c=c, beta=beta, neighbors=k,
                source_samples=len(sx), selected_samples=len(chosen),
                auc=float(roc_auc_score(y[valid], probability)),
                mcc=float(matthews_corrcoef(y[valid], probability >= .5))))
    if not rows:
        raise ValueError('No eligible source-LOPO fold. Use --graph-tuning fixed explicitly.')
    summaries = []
    for c, beta, k in grid:
        matches = [r for r in rows if (r['c'], r['beta'], r['neighbors']) == (c, beta, k)]
        summaries.append(dict(c=c, beta=beta, neighbors=k, folds=len(matches),
            auc=float(np.mean([r['auc'] for r in matches])),
            mcc=float(np.mean([r['mcc'] for r in matches]))))
    best = max(summaries, key=lambda r: (r['auc'], r['mcc'], -r['beta'], -r['neighbors']))
    return dict(best=best, candidates=summaries, folds=rows,
        protocol='source-project LOPO; mean AUC; MCC exact ties; then smaller beta and k; selection seed=0',
        real_target_used=False, rule=rule, graph=graph)


def prepare(method, rule, graph, X, y, groups, args, cache):
    if args.graph_tuning == 'fixed':
        return dict(c=args.graph_c if graph else args.lr_c,
                    beta=args.graph_beta if graph else 0.,
                    neighbors=args.graph_neighbors if graph else 0)
    records = json.loads(cache.read_text(encoding='utf-8')) if cache.exists() else {}
    if method not in records:
        print(f'Source LOPO tuning: {method}; reused across seeds', flush=True)
        started = time.perf_counter()
        record = tune(rule, graph, X, y, groups, args)
        record['tuning_seconds_batch'] = time.perf_counter()-started
        records[method] = record
        cache.parent.mkdir(parents=True, exist_ok=True)
        cache.write_text(json.dumps(records, indent=2), encoding='utf-8')
    return records[method]['best']


def run(rule, graph, X, y, groups, T, seed, args, settings):
    chosen, distance, uncertainty, audit = select(rule, X, y, groups, T, seed, args)
    source, target = compress(X), compress(T)
    c, beta, k = settings['c'], settings['beta'], settings['neighbors']
    if graph:
        edges = target_graph(source, target, k)
        model, training = fit_graph_lr(source[chosen], y[chosen], target, edges, seed, beta, c=c)
    else:
        model = fit_lr(source[chosen], y[chosen], seed, c=c)
        training = dict(c=c, beta=0., status='ordinary class-balanced LR')
    training.update(classifier='graph_lr' if graph else 'lr', neighbors=k,
                    tuning=args.graph_tuning, ablation_rule=rule)
    return Result(positive_probability(model, target), chosen, np.ones(len(chosen)),
                  training=training, selection=audit, distance=distance, uncertainty=uncertainty)


def main(method, rule, graph):
    def prepare_model(X, y, groups, args, cache):
        return prepare(method, rule, graph, X, y, groups, args, cache)

    def run_model(X, y, groups, T, seed, args, settings):
        return run(rule, graph, X, y, groups, T, seed, args, settings)

    run_cli(method, run_model, DEFAULTS, prepare=prepare_model)
