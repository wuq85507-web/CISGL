"""Original H/L with a node-permuted target graph and the original Graph LR."""
from experiments.common import run_cli
from experiments.mechanism_control_support import DEFAULTS, parameters, run_control

METHOD = 'coverage_uncertainty_permuted_graph_lr'
CONTROL = 'permuted_graph'


def prepare(X, y, groups, args, cache):
    return parameters(METHOD, CONTROL, X, y, groups, args, cache)


def run(X, y, groups, target, seed, args, settings):
    return run_control(CONTROL, X, y, groups, target, seed, args, settings)


def main():
    run_cli(METHOD, run, DEFAULTS, prepare=prepare)


if __name__ == '__main__':
    main()
