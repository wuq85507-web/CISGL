"""Source/target scaling -> RBF KMM importance weights -> weighted ordinary LR."""
import numpy as np
from selection import compress, fit_lr, positive_probability
from transfer_baselines import scaled_metrics, kmm_weights
from experiments.common import Result, run_cli

METHOD = 'kmm_lr'
DEFAULTS = dict(lr_c=1., kmm_bound=10., kmm_landmarks=256, kmm_exact_limit=1500)


def run(X, y, groups, T, seed, args, settings=None):
    source, target = scaled_metrics(X, T)
    weights, audit = kmm_weights(source, target, seed, args.kmm_bound,
                                 args.kmm_landmarks, args.kmm_exact_limit)
    raw_source = compress(X)
    model = fit_lr(raw_source, y, seed, c=args.lr_c)
    if len(np.unique(y)) == 2:
        counts = np.bincount(y.astype(int), minlength=2)
        model.steps[-1][1].set_params(class_weight={i: len(y)/(2*counts[i]) for i in (0, 1)})
    model.steps[-1][1].fit(model.steps[0][1].transform(raw_source), y, sample_weight=weights)
    audit.update(classifier='lr', c=args.lr_c,
        class_policy='raw KMM weights times explicit count-based balanced class weights')
    return Result(positive_probability(model, compress(T)), np.arange(len(X)), weights,
                  training=audit, selection=dict(rule='all source rows; KMM sample weighting'))


def main():
    run_cli(METHOD, run, DEFAULTS)


if __name__ == '__main__':
    main()
