"""Pooled clustering -> source-to-target fans -> representative source rows -> LR."""
import numpy as np
from selection import compress, fit_lr, positive_probability
from transfer_baselines import scaled_metrics, peters_filter
from experiments.common import Result, run_cli

METHOD = 'peters_filter_lr'
DEFAULTS = dict(lr_c=1., peters_cluster_size=10)


def run(X, y, groups, T, seed, args, settings=None):
    source, target = scaled_metrics(X, T)
    chosen, audit = peters_filter(source, target, seed, args.peters_cluster_size)
    model = fit_lr(compress(X[chosen]), y[chosen], seed, c=args.lr_c)
    return Result(positive_probability(model, compress(T)), chosen, np.ones(len(chosen)),
                  training=dict(audit, classifier='lr', c=args.lr_c), selection=audit)


def main():
    run_cli(METHOD, run, DEFAULTS)


if __name__ == '__main__':
    main()
