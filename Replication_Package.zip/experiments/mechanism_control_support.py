"""Controlled replacements of target graph assignment or source OOF grouping."""
import hashlib
import json
import time

import numpy as np
from sklearn.metrics import matthews_corrcoef, roc_auc_score
from sklearn.model_selection import StratifiedKFold

from experiments.common import Result
from experiments.selection_support import coverage_inputs
from graph_lr import fit_graph_lr, graph_quadratic, target_graph
from selection import fit_lr, positive_probability


DEFAULTS = dict(budget_fraction=.25, graph_tuning='source_lopo', graph_c=1.,
                graph_c_grid=[.1, 1., 10.], graph_beta_grid=[0., .03, .1, .3],
                graph_neighbor_grid=[5, 10])
CONTROLS = ('permuted_graph', 'instance_oof')


def instance_oof_uncertainty(source, labels, groups, seed):
    """Stratified row OOF; source scaling and balanced C=1 LR fit per fold."""
    projects = np.unique(groups)
    requested = min(5, len(projects)) if len(projects) >= 2 else 5
    counts = np.bincount(labels.astype(int), minlength=2)
    folds = min(requested, int(counts.min()))
    audit = dict(protocol='source-instance-stratified OOF', requested_folds=requested,
                 effective_folds=folds, fold_details=[], auxiliary_c=1.,
                 target_labels_used=False)
    if folds < 2:
        audit.update(effective_folds=0, fallback='insufficient source class support; zero uncertainty')
        return np.zeros(len(labels)), audit
    probability = np.empty(len(labels))
    splitter = StratifiedKFold(n_splits=folds, shuffle=True, random_state=seed)
    for train, valid in splitter.split(source, labels):
        model = fit_lr(source[train], labels[train], seed, c=1.)
        probability[valid] = positive_probability(model, source[valid])
        train_projects, valid_projects = np.unique(groups[train]), np.unique(groups[valid])
        audit['fold_details'].append(dict(train_rows=len(train), validation_rows=len(valid),
            training_projects=train_projects.tolist(), validation_projects=valid_projects.tolist(),
            overlapping_projects=np.intersect1d(train_projects, valid_projects).tolist()))
    return 1-2*np.abs(probability-.5), audit


def select_sources(control, X, y, groups, target, seed, args):
    if control not in CONTROLS:
        raise ValueError(f'Unknown mechanism control: {control}')
    context = coverage_inputs(X, y, groups, target, seed, args,
                              need_uncertainty=control == 'permuted_graph')
    detail = None
    if control == 'instance_oof':
        context.uncertainty, detail = instance_oof_uncertainty(
            context.raw_source, y, groups, seed)
        context.audit['oof_protocol'] = detail['protocol']
    ranked = np.argsort(-context.uncertainty[context.remaining], kind='stable')
    supplement = context.remaining[ranked[:context.n_low]]
    chosen = np.r_[context.high, supplement]
    audit = dict(context.audit, control=control, high_indices=context.high.tolist(),
        low_indices=supplement.tolist(), target_labels_used=False)
    if detail is not None:
        audit['instance_oof'] = detail
    return chosen, context, audit


def permute_graph(edges, target_count, seed):
    """Reassign a weighted graph to target rows; preserve all graph invariants."""
    permutation = np.random.default_rng(seed).permutation(target_count)
    left, right, weights = edges
    a, b = permutation[left], permutation[right]
    # Edge order is retained, so every weight stays on its original abstract edge.
    permuted = (np.minimum(a, b), np.maximum(a, b), weights.copy())
    return permuted, permutation


def candidate_graph(control, raw_source, raw_target, neighbors, seed):
    edges = target_graph(raw_source, raw_target, neighbors)
    if control == 'permuted_graph':
        actual, permutation = permute_graph(edges, len(raw_target), seed)
    else:
        actual, permutation = edges, None
    return actual, edges, permutation


def tune_control(control, X, y, groups, args):
    neighbors = list(dict.fromkeys(args.graph_neighbor_grid))
    grid = [(float(c), float(beta), int(k)) for c in dict.fromkeys(args.graph_c_grid)
            for beta in dict.fromkeys(args.graph_beta_grid)
            for k in (neighbors[:1] if beta == 0 else neighbors)]
    rows, audits = [], []
    for held_out in np.unique(groups):
        train, valid = groups != held_out, groups == held_out
        if train.sum() < 2 or np.unique(y[valid]).size < 2:
            continue
        chosen, context, audit = select_sources(
            control, X[train], y[train], groups[train], X[valid], 0, args)
        sx, sy = context.raw_source[chosen], y[train][chosen]
        bases = {c: fit_lr(sx, sy, 0, c=c) for c in dict.fromkeys(args.graph_c_grid)}
        scaled_target = next(iter(bases.values())).steps[0][1].transform(context.raw_target)
        graphs = {k: candidate_graph(control, context.raw_source, context.raw_target, k, 0)
                  for k in neighbors}
        quadratics = {k: graph_quadratic(scaled_target, graph[0]) for k, graph in graphs.items()}
        permutation = graphs[neighbors[0]][2]
        audits.append(dict(held_out_source=int(held_out), training_source_rows=int(train.sum()),
            target_rows=int(valid.sum()), high_size=len(context.high), low_size=context.n_low,
            selection_hash=hashlib.sha256(chosen.tobytes()).hexdigest(),
            oof_protocol=audit['oof_protocol'], instance_oof=audit.get('instance_oof'),
            permutation_hash=hashlib.sha256(permutation.tobytes()).hexdigest()
                if permutation is not None else None))
        for c, beta, k in grid:
            model, _ = fit_graph_lr(sx, sy, context.raw_target, graphs[k][0], 0, beta,
                                   base_model=bases[c], quadratic=quadratics[k], c=c)
            probability = positive_probability(model, context.raw_target)
            rows.append(dict(held_out_source=int(held_out), c=c, beta=beta, neighbors=k,
                auc=float(roc_auc_score(y[valid], probability)),
                mcc=float(matthews_corrcoef(y[valid], probability >= .5))))
    if not rows:
        raise ValueError('No two-class source LOPO fold; use --graph-tuning fixed explicitly.')
    summaries = []
    for c, beta, k in grid:
        matches = [r for r in rows if (r['c'], r['beta'], r['neighbors']) == (c, beta, k)]
        summaries.append(dict(c=c, beta=beta, neighbors=k, folds=len(matches),
            auc=float(np.mean([r['auc'] for r in matches])),
            mcc=float(np.mean([r['mcc'] for r in matches]))))
    best = max(summaries, key=lambda r: (r['auc'], r['mcc'], -r['beta'], -r['neighbors']))
    return dict(best=best, candidates=summaries, folds=rows, control=control,
        construction_folds=audits, real_target_used=False,
        protocol='source-project LOPO; mean project AUC; MCC then smaller beta/k breaks exact ties; construction seed=0')


def parameters(method, control, X, y, groups, args, cache):
    if args.graph_tuning == 'fixed':
        return dict(c=args.graph_c, beta=args.graph_beta, neighbors=args.graph_neighbors)
    records = json.loads(cache.read_text(encoding='utf-8')) if cache.exists() else {}
    if method not in records:
        print(f'Source LOPO tuning: {method}; reused across seeds', flush=True)
        started = time.perf_counter()
        record = tune_control(control, X, y, groups, args)
        record['tuning_seconds_batch'] = time.perf_counter()-started
        records[method] = record
        cache.parent.mkdir(parents=True, exist_ok=True)
        cache.write_text(json.dumps(records, indent=2), encoding='utf-8')
    return records[method]['best']


def run_control(control, X, y, groups, target, seed, args, settings):
    chosen, context, audit = select_sources(control, X, y, groups, target, seed, args)
    c, beta, k = settings['c'], settings['beta'], settings['neighbors']
    edges, original, permutation = candidate_graph(
        control, context.raw_source, context.raw_target, k, seed)
    model, training = fit_graph_lr(context.raw_source[chosen], y[chosen], context.raw_target,
                                   edges, seed, beta, c=c)
    training.update(classifier='graph_lr', neighbors=k, tuning=args.graph_tuning,
                    mechanism_control=control, target_labels_used=False)
    if permutation is not None:
        scaled = model.steps[0][1].transform(context.raw_target)
        audit['graph_permutation'] = dict(seed=int(seed), permutation=permutation.tolist(),
            changed_nodes=int(np.count_nonzero(permutation != np.arange(len(target)))),
            target_count=len(target), original_edges=len(original[2]), permuted_edges=len(edges[2]),
            total_edge_weight=float(edges[2].sum()),
            weight_sequence_unchanged=bool(np.array_equal(original[2], edges[2])),
            original_quadratic_trace=float(np.trace(graph_quadratic(scaled, original))),
            permuted_quadratic_trace=float(np.trace(graph_quadratic(scaled, edges))),
            protocol='one seed-defined permutation shared across k; no target labels')
    return Result(positive_probability(model, context.raw_target), chosen, np.ones(len(chosen)),
                  training=training, selection=audit, distance=context.distance,
                  uncertainty=context.uncertainty)
