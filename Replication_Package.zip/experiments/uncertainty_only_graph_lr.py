"""Uncertainty-only ablation: all B slots use source-project OOF ambiguity."""
from experiments.fair_ablation_support import main

if __name__ == '__main__':
    main('uncertainty_only_graph_lr', 'uncertainty', True)
