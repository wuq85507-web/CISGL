"""WBDA_PLUS ratio objective with source-only labels and an LR classifier."""
from experiments.paper_baseline_support import run_paper_cli

if __name__ == '__main__':
    run_paper_cli('wbda_plus_unsupervised_lr')
