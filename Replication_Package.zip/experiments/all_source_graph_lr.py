"""All source rows -> source-LOPO-tuned target Graph LR -> predictions."""
import numpy as np
from selection import compress, positive_probability
from graph_lr import target_graph, fit_graph_lr
from experiments.common import Result, run_cli
from experiments.all_source_support import parameters

METHOD = 'all_source_graph_lr'
DEFAULTS = dict(budget_fraction=1., graph_tuning='source_lopo', graph_c=1.,
                graph_beta=.1, graph_neighbors=10, graph_c_grid=[.1, 1., 10.],
                graph_beta_grid=[0., .03, .1, .3], graph_neighbor_grid=[5, 10])


def prepare(X, y, groups, args, cache):
    return parameters(METHOD, True, X, y, groups, args, cache)


def run(X, y, groups, T, seed, args, settings=None):
    if settings is None:
        if args.graph_tuning != 'fixed':
            raise ValueError('Source-LOPO settings are required; run prepare before fitting.')
        settings = dict(c=args.graph_c, beta=args.graph_beta,
                        neighbors=args.graph_neighbors, candidate_count=1)
    chosen = np.arange(len(X))
    beta, k, c = settings['beta'], settings['neighbors'], settings['c']
    source, target = compress(X), compress(T)
    edges = target_graph(source, target, k)
    model, training = fit_graph_lr(source, y, target, edges, seed, beta, c=c)
    training.update(classifier='graph_lr', neighbors=k, tuning=args.graph_tuning,
                    candidate_count=settings['candidate_count'])
    return Result(positive_probability(model, target), chosen, np.ones(len(chosen)),
        training=training,
        selection=dict(rule='all source rows', original_size=len(X),
                       sampled_size=len(X), sample_rate=1.))


def main():
    run_cli(METHOD, run, DEFAULTS, prepare=prepare)


if __name__ == '__main__':
    main()
