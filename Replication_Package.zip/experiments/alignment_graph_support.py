"""Post-selection unsupervised alignment; preserve H/L and raw-metric graph edges."""
import json
import time

import numpy as np
from sklearn.metrics import roc_auc_score, matthews_corrcoef
from sklearn.preprocessing import StandardScaler

from experiments.common import Result
from experiments.selection_support import coverage_inputs
from graph_lr import target_graph, graph_quadratic, fit_graph_lr
from selection import compress, fit_lr, positive_probability
from transfer_baselines import linear_tca


DEFAULTS = dict(graph_tuning='source_lopo', graph_c=1., budget_fraction=.25,
                graph_c_grid=[.1, 1., 10.], graph_beta_grid=[0., .03, .1, .3],
                graph_neighbor_grid=[5, 10], tca_dimension=10, tca_mu=1.,
                alignment_protocol='post-selection-fixed-geometry-v1')


def select_source(X, y, groups, target, seed, args):
    context = coverage_inputs(X, y, groups, target, seed, args, need_uncertainty=True)
    ranked = np.argsort(-context.uncertainty[context.remaining], kind='stable')
    chosen = np.r_[context.high, context.remaining[ranked[:context.n_low]]]
    return chosen, context


def _covariance(x):
    centered = x - x.mean(axis=0)
    return centered.T @ centered / max(len(x)-1, 1)


def _power(matrix, exponent):
    values, vectors = np.linalg.eigh((matrix+matrix.T)/2)
    return (vectors*np.maximum(values, 1e-12)**exponent) @ vectors.T


def align_selected(kind, source, target, args):
    """Inputs are signed-log metrics. No labels enter the alignment stage.

    Source scaling uses the selected training rows only. CORAL additionally
    translates source means to target means; covariance ridge is fixed at 1.
    TCA reuses the repository's exact low-rank linear-kernel implementation.
    """
    scaler = StandardScaler().fit(source)
    sx, tx = scaler.transform(source), scaler.transform(target)
    audit = dict(alignment=kind, source_rows=len(sx), target_rows=len(tx),
                 scaling='selected source fitted StandardScaler after signed log',
                 target_labels_used=False, alignment_labels_used=False)
    if kind == 'coral':
        cs, ct = _covariance(sx), _covariance(tx)
        identity = np.eye(sx.shape[1])
        transform = _power(cs+identity, -.5) @ _power(ct+identity, .5)
        mapped = (sx-sx.mean(axis=0)) @ transform + tx.mean(axis=0)
        audit.update(covariance_ridge=1., mean_translation=True,
                     transform_condition=float(np.linalg.cond(transform)),
                     mean_gap_before=float(np.linalg.norm(sx.mean(axis=0)-tx.mean(axis=0))),
                     mean_gap_after=float(np.linalg.norm(mapped.mean(axis=0)-tx.mean(axis=0))),
                     covariance_gap_before=float(np.linalg.norm(cs-ct, 'fro')),
                     covariance_gap_after=float(np.linalg.norm(_covariance(mapped)-ct, 'fro')))
        return mapped, tx, audit
    if kind == 'tca':
        sx, tx, details = linear_tca(sx, tx, args.tca_dimension, args.tca_mu)
        audit.update(details)
        return sx, tx, audit
    raise ValueError(f'Unknown alignment: {kind}')


def tune_alignment(kind, X, y, groups, args):
    """Only source projects are accepted; each held-out source is a pseudo-target."""
    neighbors = list(dict.fromkeys(args.graph_neighbor_grid))
    candidates = [(float(c), float(beta), int(k))
                  for c in dict.fromkeys(args.graph_c_grid)
                  for beta in dict.fromkeys(args.graph_beta_grid)
                  for k in (neighbors[:1] if beta == 0 else neighbors)]
    rows, audits = [], []
    for held_out in np.unique(groups):
        train, valid = groups != held_out, groups == held_out
        if train.sum() < 2 or len(np.unique(y[valid])) < 2:
            continue
        source, labels, target = X[train], y[train], X[valid]
        chosen, _ = select_source(source, labels, groups[train], target, 0, args)
        raw_source, raw_target = compress(source), compress(target)
        sx, tx, audit = align_selected(kind, raw_source[chosen], raw_target, args)
        audits.append(dict(held_out_source=int(held_out), alignment=audit,
                          selected_indices=chosen.tolist()))
        # Same target topology AND weights as the unaligned main model.
        edges = {k: target_graph(raw_source, raw_target, k) for k in neighbors}
        sy = labels[chosen]
        bases = {c: fit_lr(sx, sy, 0, c=c) for c in dict.fromkeys(args.graph_c_grid)}
        scaled_target = next(iter(bases.values())).steps[0][1].transform(tx)
        quadratics = {k: graph_quadratic(scaled_target, edges[k]) for k in neighbors}
        for c, beta, k in candidates:
            model, _ = fit_graph_lr(sx, sy, tx, edges[k], 0, beta,
                                   base_model=bases[c], quadratic=quadratics[k], c=c)
            probability = positive_probability(model, tx)
            rows.append(dict(held_out_source=int(held_out), c=c, beta=beta, neighbors=k,
                             auc=float(roc_auc_score(y[valid], probability)),
                             mcc=float(matthews_corrcoef(y[valid], probability >= .5))))
    if not rows:
        raise ValueError('No source LOPO fold with two classes; use --graph-tuning fixed.')
    summaries = []
    for c, beta, k in candidates:
        matches = [row for row in rows if (row['c'], row['beta'], row['neighbors']) == (c, beta, k)]
        summaries.append(dict(c=c, beta=beta, neighbors=k, folds=len(matches),
                              auc=float(np.mean([row['auc'] for row in matches])),
                              mcc=float(np.mean([row['mcc'] for row in matches]))))
    best = max(summaries, key=lambda row: (row['auc'], row['mcc'], -row['beta'], -row['neighbors']))
    return dict(best=best, candidates=summaries, folds=rows, alignment_folds=audits,
                protocol='source-project LOPO; mean project AUC; MCC breaks exact ties; selection seed=0',
                alignment=kind, real_target_used=False,
                graph_protocol='original full-source-scaled metric edges and weights')


def parameters(method, kind, X, y, groups, args, cache):
    if args.graph_tuning == 'fixed':
        return dict(c=args.graph_c, beta=args.graph_beta, neighbors=args.graph_neighbors)
    records = json.loads(cache.read_text(encoding='utf-8')) if cache.exists() else {}
    if method not in records:
        print(f'Source LOPO tuning: {method}; reused across seeds', flush=True)
        started = time.perf_counter()
        record = tune_alignment(kind, X, y, groups, args)
        record['tuning_seconds_batch'] = time.perf_counter()-started
        records[method] = record
        cache.parent.mkdir(parents=True, exist_ok=True)
        cache.write_text(json.dumps(records, indent=2), encoding='utf-8')
    return records[method]['best']


def run_aligned(kind, X, y, groups, target, seed, args, settings):
    chosen, context = select_source(X, y, groups, target, seed, args)
    source, target = compress(X), compress(target)
    k, beta, c = settings['neighbors'], settings['beta'], settings['c']
    edges = target_graph(source, target, k)
    started = time.perf_counter()
    sx, tx, audit = align_selected(kind, source[chosen], target, args)
    audit['seconds'] = time.perf_counter()-started
    model, training = fit_graph_lr(sx, y[chosen], tx, edges, seed, beta, c=c)
    training.update(classifier='graph_lr', neighbors=k, tuning=args.graph_tuning,
                    alignment=audit, target_labels_used=False,
                    graph_protocol='original full-source-scaled metric edges and weights')
    selection = dict(context.audit, alignment_after_selection=True,
                     alignment=kind, original_main_selection=True)
    return Result(positive_probability(model, tx), chosen, np.ones(len(chosen)),
                  training=training, selection=selection,
                  distance=context.distance, uncertainty=context.uncertainty)
