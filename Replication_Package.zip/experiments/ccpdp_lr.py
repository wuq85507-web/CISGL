"""Classifier-controlled CCPDP adaptation using LR instead of original RF."""
from experiments.paper_baseline_support import run_paper_cli

if __name__ == '__main__':
    run_paper_cli('ccpdp_lr')
