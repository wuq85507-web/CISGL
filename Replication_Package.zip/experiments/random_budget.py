"""Random K source samples + ordinary LR.

Input: source X/y/groups and unlabeled target T; target labels are never accepted.
Output: source indices, target probabilities, weights and audit; common.run_cli
loads the dataset and writes metrics/selection/prediction files.
"""
import numpy as np
from selection import compress, fit_lr, positive_probability
from experiments.common import Result, run_cli
from experiments.selection_support import sample_budget, geometry, coverage_inputs, uncertain_pool

METHOD = 'random_budget'
DEFAULTS = dict(lr_c=1.)


def run(X, y, groups, T, seed, args, settings=None):
    chosen = np.random.default_rng(seed).choice(len(X), sample_budget(X, args), replace=False)
    distance, uncertainty, audit = None, None, dict(rule='uniform random K source rows')
    source_features = compress(X[chosen])
    target_features = compress(T)
    # StandardScaler is fitted only on selected source rows inside fit_lr.
    model = fit_lr(source_features, y[chosen], seed, c=args.lr_c)
    probability = positive_probability(model, target_features)
    return Result(probability, chosen, np.ones(len(chosen)),
                  training=dict(classifier='lr', c=args.lr_c),
                  selection=audit, distance=distance, uncertainty=uncertainty)


def main():
    run_cli(METHOD, run, DEFAULTS)


if __name__ == '__main__':
    main()
