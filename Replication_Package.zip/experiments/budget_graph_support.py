"""Shared training for two label-free selector controls."""
import numpy as np
from budget_graph_selection import select_budget
from selection import compress, positive_probability
from graph_lr import target_graph, fit_graph_lr
from experiments.common import Result
from experiments.selection_support import sample_budget

DEFAULTS = dict(graph_tuning='source_lopo', graph_c=1.,
                graph_c_grid=[.1, 1., 10.], graph_beta_grid=[0., .03, .1, .3],
                graph_neighbor_grid=[5, 10])


def run_selected(method, X, y, groups, T, seed, args, settings):
    chosen, distance, audit = select_budget(method, X, T, sample_budget(X, args), seed)
    beta, k, c = settings['beta'], settings['neighbors'], settings['c']
    source, target = compress(X), compress(T)
    edges = target_graph(source, target, k)
    model, training = fit_graph_lr(source[chosen], y[chosen], target, edges, seed, beta, c=c)
    training.update(classifier='graph_lr', neighbors=k, tuning=args.graph_tuning)
    return Result(positive_probability(model, target), chosen, np.ones(len(chosen)),
                  training=training, selection=audit, distance=distance)
