"""Compare the five independent runs using project means, not pooled seed rows."""
import argparse
from pathlib import Path
import numpy as np
import pandas as pd
from scipy.stats import rankdata, wilcoxon
from dataset_loader import NASA_D2_PROJECTS

METHODS = ('all_source', 'all_source_graph_lr', 'coverage_uncertainty_graph_lr',
           'nearest_budget_graph_lr', 'coreset_graph_lr')
MAIN = 'coverage_uncertainty_graph_lr'


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--results-root', type=Path, default=Path('results/nasa_d2_independent'))
    args = parser.parse_args()
    parts = []
    for method in METHODS:
        path = args.results_root/method/'per_run_metrics.csv'
        if not path.exists():
            continue
        part = pd.read_csv(path)
        if not part.method.eq(method).all() or not part.dataset.eq('NASA_D2').all():
            raise ValueError(f'Wrong experiment in {path}')
        if part.duplicated(['dataset', 'target', 'seed']).any():
            raise ValueError(f'Duplicate result identities: {path}')
        if method.startswith('all_source') and not part.selected_samples.eq(part.source_samples).all():
            raise ValueError(f'Full-source baseline subsampled: {path}')
        parts.append(part)
    if not parts:
        parser.error('No NASA_D2 result files found.')
    frame = pd.concat(parts, ignore_index=True)
    metrics = ['auc', 'mcc', 'f1', 'average_precision', 'precision', 'recall', 'accuracy']
    targets = frame.groupby(['dataset', 'target', 'method'])[metrics].mean().reset_index()
    summary = targets.groupby('method')[metrics].agg(['mean', 'std'])
    out = args.results_root/'statistics'
    out.mkdir(parents=True, exist_ok=True)
    summary.to_csv(out/'summary.csv')
    targets.to_csv(out/'target_means.csv', index=False)
    counts = frame.groupby('method').agg(runs=('seed','size'), targets=('target','nunique'), seeds=('seed','nunique'))
    counts['complete_12targets_5seeds'] = [
        set(zip(part.target, part.seed)) == {(t, s) for t in NASA_D2_PROJECTS for s in range(5)}
        for _, part in frame.groupby('method')]
    counts.to_csv(out/'completeness.csv')
    paired = []
    # Match identities BEFORE averaging to avoid comparing different seed sets.
    for metric in ('auc', 'mcc'):
        pivot = frame.pivot(index=['dataset','target','seed'], columns='method', values=metric)
        if MAIN not in pivot:
            continue
        for other in METHODS:
            if other == MAIN or other not in pivot:
                continue
            pair = pivot[[MAIN, other]].dropna()
            delta = (pair[MAIN]-pair[other]).groupby(level=['dataset','target']).mean()
            values = delta.to_numpy()
            if not len(values):
                continue
            rng = np.random.default_rng(20261018)
            boot = rng.choice(values, size=(20000, len(values)), replace=True).mean(axis=1)
            nonzero = values[values != 0]
            ranks = rankdata(abs(nonzero))
            effect = float(np.dot(ranks, np.sign(nonzero))/ranks.sum()) if len(nonzero) else 0.
            p = float(wilcoxon(values).pvalue) if len(values)>1 and len(nonzero) else 1.
            paired.append(dict(metric=metric, baseline=other, targets=len(values),
                wins=int((values>1e-12).sum()), ties=int((abs(values)<=1e-12).sum()), losses=int((values< -1e-12).sum()),
                mean_delta=values.mean(), ci95_low=np.quantile(boot,.025), ci95_high=np.quantile(boot,.975),
                wilcoxon_p=p, rank_biserial=effect))
    if paired:
        comparisons = pd.DataFrame(paired)
        p = comparisons.wilcoxon_p.to_numpy()
        order = np.argsort(p)
        q = np.minimum.accumulate((p[order]*len(p)/np.arange(1,len(p)+1))[::-1])[::-1]
        comparisons['bh_q'] = np.nan
        comparisons.loc[order,'bh_q'] = np.minimum(q,1.)
        comparisons.to_csv(out/'paired_main_vs_baselines.csv', index=False)
    print(summary.to_string())
    print(counts.to_string())
    print(f'Statistics saved to {out.resolve()}; seeds averaged within projects.')


if __name__ == '__main__':
    main()
