"""Paired R=5 vs R=1 H selection; retain the original H/L and Graph LR code."""
import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.stats import rankdata, wilcoxon
from sklearn.neighbors import NearestNeighbors
from threadpoolctl import threadpool_limits

from dataset_loader import FAMILIES, load_family
from experiments.common import source_unique
from experiments.selection_support import geometry
from selection import coverage_order

METHOD = 'coverage_uncertainty_graph_lr'
KEY = ['dataset', 'target', 'seed']
METRICS = ['auc', 'mcc']


def read_arm(directory, families, target, repetitions, regions):
    config = json.loads((directory/'config.json').read_text(encoding='utf-8-sig'))
    expected = dict(method=METHOD, budget_fraction=.25, budget=None, low_fraction=.2,
        target_regions=regions, graph_tuning='source_lopo', graph_c_grid=[.1, 1., 10.],
        graph_beta_grid=[0., .03, .1, .3], graph_neighbor_grid=[5, 10])
    for key, value in expected.items():
        if config.get(key) != value:
            raise ValueError(f'{directory}: expected {key}={value}, found {config.get(key)}')
    frame = pd.read_csv(directory/'per_run_metrics.csv')
    if frame.duplicated(KEY).any() or not frame.method.eq(METHOD).all():
        raise ValueError(f'{directory}: duplicate runs or unexpected method.')
    frame = frame[frame.dataset.isin(families) & frame.seed.isin(range(repetitions))].copy()
    if target:
        frame = frame[frame.target.str.lower().eq(target.lower())]
    expected_keys = {(family, project['name'], repeat)
        for family in families for project in load_family(Path(config['data_root']), family)
        if not target or project['name'].lower() == target.lower()
        for repeat in range(repetitions)}
    actual = set(frame[KEY].itertuples(index=False, name=None))
    if not expected_keys or actual != expected_keys:
        missing = sorted(expected_keys-actual)
        raise ValueError(f'{directory}: missing paired runs {missing[:5]}. '
                         'Use -RunReference to create matching R=5 runs, or point -ReferenceDir to complete results.')
    if not np.isfinite(frame[METRICS].to_numpy()).all():
        raise ValueError('Non-finite AUC or MCC.')
    return frame.sort_values(KEY), config


def paired_tests(target_means):
    rows = []
    for metric in METRICS:
        pivot = target_means.pivot(index=['dataset', 'target'], columns='arm', values=metric)
        delta = (pivot['region_round_robin']-pivot['global_nearest_h']).to_numpy()
        delta[np.abs(delta) <= 1e-12] = 0
        nonzero = delta[delta != 0]
        ranks = rankdata(np.abs(nonzero))
        rows.append(dict(metric=metric, targets=len(delta),
            delta_mean=float(delta.mean()), wins=int((delta > 0).sum()),
            ties=int((delta == 0).sum()), losses=int((delta < 0).sum()),
            p=float(wilcoxon(delta, alternative='two-sided').pvalue) if len(nonzero) else 1.,
            rank_biserial=float(np.dot(np.sign(nonzero), ranks)/ranks.sum()) if len(nonzero) else 0.))
    order = np.argsort([r['p'] for r in rows])
    corrected = np.minimum.accumulate(
        np.array([rows[i]['p']*len(rows)/(j+1) for j, i in enumerate(order)])[::-1])[::-1]
    for i, q in zip(order, corrected):
        rows[i]['bh_q'] = min(1., float(q))
    return pd.DataFrame(rows)


def saved_selection(directory, row, projects, source, labels, S, Z, regions):
    folder = directory/'runs'/f'{row.dataset}__{row.target}__seed{int(row.seed)}'
    audit = json.loads((folder/'audit.json').read_text(encoding='utf-8'))
    selected = pd.read_csv(folder/f'{METHOD}_selection.csv')
    chosen = selected.pool_index.to_numpy(dtype=int)
    count = max(2, int(len(source)*.25))
    low_count = max(1, min(count-1, round(count*.2)))
    if (len(chosen) != count or len(np.unique(chosen)) != count or
            np.any(chosen < 0) or np.any(chosen >= len(source))):
        raise ValueError('Invalid saved selection indices.')
    high = chosen[selected.role.eq('H').to_numpy()]
    low = chosen[selected.role.eq('L').to_numpy()]
    if len(high) != count-low_count or len(low) != low_count:
        raise ValueError('H/L sizes differ from the fixed 80:20 allocation.')
    expected = coverage_order(S, Z, regions, int(row.seed))[:len(high)]
    np.testing.assert_array_equal(high, expected, err_msg='Saved H differs from the stated region rule.')
    np.testing.assert_array_equal(selected.label.to_numpy(), labels[chosen])
    expected_audit = [dict(project=p['name'], retained=len(source_unique(p)[0])) for p in projects]
    if [(p['project'], p['retained']) for p in audit['sources']] != [
            (p['project'], p['retained']) for p in expected_audit]:
        raise ValueError('Saved source pool differs from the current loader.')
    if audit['high_size'] != len(high) or audit['low_size'] != len(low):
        raise ValueError('Selection audit counts do not match saved indices.')
    return chosen, high, selected, audit


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--reference-dir', type=Path, required=True)
    parser.add_argument('--control-dir', type=Path)
    parser.add_argument('--output-dir', type=Path)
    parser.add_argument('--dataset', choices=(*FAMILIES, 'paper'), default='paper')
    parser.add_argument('--target', default='')
    parser.add_argument('--repetitions', type=int, default=1)
    parser.add_argument('--check-reference', action='store_true')
    args = parser.parse_args()
    if args.repetitions < 1:
        parser.error('Repetitions must be positive.')
    families = list(FAMILIES[:5]) if args.dataset == 'paper' else [args.dataset]
    reference, config = read_arm(args.reference_dir, families, args.target, args.repetitions, 5)
    if args.check_reference:
        print(f'Existing reference ready: {len(reference)} matched runs; no reference training needed.')
        return
    if args.control_dir is None or args.output_dir is None:
        parser.error('--control-dir and --output-dir are required for analysis.')
    control, control_config = read_arm(args.control_dir, families, args.target, args.repetitions, 1)
    if any(config['data_hashes'].get(k) != v for k, v in control_config['data_hashes'].items()):
        raise ValueError('Reference and control have different data hashes.')
    coverage = []
    arms = [('region_round_robin', args.reference_dir, reference, 5),
            ('global_nearest_h', args.control_dir, control, 1)]
    with threadpool_limits(limits=4):
        for family in families:
            projects = load_family(Path(config['data_root']), family)
            for target in projects:
                subset = reference[reference.dataset.eq(family) & reference.target.eq(target['name'])]
                if subset.empty:
                    continue
                sources = [p for p in projects if p is not target]
                source = np.vstack([p['X'][source_unique(p)[0]] for p in sources])
                labels = np.concatenate([p['y'][source_unique(p)[0]] for p in sources])
                _, _, S, Z, _ = geometry(source, target['X'])
                selected_arms = {}
                for name, directory, frame, regions in arms:
                    for row in frame[frame.dataset.eq(family) & frame.target.eq(target['name'])].itertuples():
                        chosen, high, saved, audit = saved_selection(
                            directory, row, sources, source, labels, S, Z, regions)
                        selected_arms[(name, int(row.seed))] = (saved, audit)
                        item = dict(arm=name, dataset=family, target=target['name'], seed=int(row.seed),
                                    selected_samples=len(chosen), high_size=len(high), low_size=len(chosen)-len(high))
                        for scope, indices in [('h', high), ('subset', chosen)]:
                            distances = NearestNeighbors(n_neighbors=1, n_jobs=1).fit(S[indices]).kneighbors(Z)[0][:, 0]
                            item[f'{scope}_distance_mean'] = float(distances.mean())
                            item[f'{scope}_distance_p95'] = float(np.quantile(distances, .95))
                        coverage.append(item)
                for repeat in subset.seed:
                    left, la = selected_arms[('region_round_robin', int(repeat))]
                    right, ra = selected_arms[('global_nearest_h', int(repeat))]
                    if la['oof_protocol'] != ra['oof_protocol']:
                        raise ValueError('Different OOF protocols.')
                    shared = left.merge(right, on='pool_index', suffixes=('_r5', '_r1'))
                    np.testing.assert_allclose(shared.oof_uncertainty_r5, shared.oof_uncertainty_r1,
                                               atol=1e-12, rtol=0, err_msg='OOF scores differ between arms.')
    combined = pd.concat([frame.assign(arm=name) for name, _, frame, _ in arms], ignore_index=True)
    distances = pd.DataFrame(coverage)
    combined = combined.merge(distances, on=['arm', *KEY, 'selected_samples'], validate='one_to_one')
    fields = METRICS + ['h_distance_mean', 'h_distance_p95', 'subset_distance_mean', 'subset_distance_p95']
    means = combined.groupby(['arm', 'dataset', 'target'])[fields].mean().reset_index()
    summary = means.groupby('arm')[fields].mean()
    summary['targets'] = means.groupby('arm').size()
    summary['runs'] = combined.groupby('arm').size()
    tests = paired_tests(means)
    args.output_dir.mkdir(parents=True, exist_ok=True)
    for filename, frame in [('per_run_metrics.csv', combined), ('coverage_per_run.csv', distances),
                            ('target_means.csv', means), ('summary.csv', summary.reset_index()),
                            ('per_family.csv', means.groupby(['arm', 'dataset'])[fields].mean().reset_index()),
                            ('paired_tests.csv', tests)]:
        frame.to_csv(args.output_dir/filename, index=False, encoding='utf-8-sig')
    (args.output_dir/'protocol.json').write_text(json.dumps(dict(
        reference_dir=str(args.reference_dir.resolve()), control_dir=str(args.control_dir.resolve()),
        repetitions=args.repetitions, target_count=int(means.groupby('arm').size().iloc[0]),
        difference='R=5 minus R=1; positive AUC/MCC favors regional round robin',
        coverage='target-to-selected-source nearest distance, source-fitted signed-log geometry; lower is better',
        tests='two-sided Wilcoxon over target means; BH over AUC/MCC',
        tuning='source LOPO separately per arm; common 21 candidates',
        code_hashes=dict(reference=config['code_hash'], control=control_config['code_hash']),
        oof='same scorer, same counts; L membership may differ when H changes'), indent=2), encoding='utf-8')
    print(summary.to_string())
    print('\nPaired R=5 minus R=1 differences:')
    print(tests.to_string(index=False))
    print(f'Saved {args.output_dir.resolve()}')


if __name__ == '__main__':
    main()
