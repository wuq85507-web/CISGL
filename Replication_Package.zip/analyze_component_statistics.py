"""Paired component and 5%-budget interaction statistics; never trains models."""
import argparse
import hashlib
import json
from pathlib import Path
import numpy as np
import pandas as pd
from scipy.stats import rankdata, wilcoxon

KEY = ['dataset', 'target', 'seed']
TARGET = ['dataset', 'target']
METRICS = ['auc', 'mcc']
INPUTS = {
    'proposed25': ('budget_main_25percent_5seeds', 'coverage_uncertainty_graph_lr'),
    'H-only': ('fair_ablations_25percent_5seeds/coverage_only_graph_lr', 'coverage_only_graph_lr'),
    'L-only': ('fair_ablations_25percent_5seeds/uncertainty_only_graph_lr', 'uncertainty_only_graph_lr'),
    'Random+Graph': ('fair_ablations_25percent_5seeds/fair_random_graph_lr', 'fair_random_graph_lr'),
    'selected5_lr': ('coverage_uncertainty_lr_5percent_5seeds', 'coverage_uncertainty'),
    'selected5_graph': ('coverage_uncertainty_graph_lr_5percent_5seeds', 'coverage_uncertainty_graph_lr'),
    'all_lr': ('all_full_lopo_25targets_5seeds/all_source', 'all_source'),
    'all_graph': ('all_full_lopo_25targets_5seeds/all_source_graph_lr', 'all_source_graph_lr'),
}


def paired(values):
    difference = np.asarray(values, dtype=float).copy()
    if not np.isfinite(difference).all() or len(difference) < 2:
        raise ValueError('Paired tests require at least two finite target differences.')
    difference[np.abs(difference) <= 1e-12] = 0.
    nonzero = difference[difference != 0]
    ranks = rankdata(np.abs(nonzero))
    return dict(targets=len(difference), delta_mean=float(difference.mean()),
        wins=int((difference > 0).sum()), ties=int((difference == 0).sum()),
        losses=int((difference < 0).sum()),
        p=float(wilcoxon(difference, alternative='two-sided', zero_method='wilcox').pvalue)
          if len(nonzero) else 1.,
        rank_biserial=float(np.dot(np.sign(nonzero), ranks)/ranks.sum()) if len(nonzero) else 0.)


def bh(rows):
    order = sorted(range(len(rows)), key=lambda i: rows[i]['p'])
    adjusted = np.minimum.accumulate(np.array([
        rows[i]['p']*len(rows)/(j+1) for j, i in enumerate(order)])[::-1])[::-1]
    for i, value in zip(order, adjusted):
        rows[i]['bh_q'] = min(1., float(value))


def read(path, method):
    frame = pd.read_csv(path)
    required = KEY + METRICS + ['method', 'source_samples', 'selected_samples', 'target_samples']
    missing = set(required)-set(frame.columns)
    if missing:
        raise ValueError(f'{path}: missing columns {sorted(missing)}')
    if frame.duplicated(KEY).any() or not frame.method.eq(method).all():
        raise ValueError(f'{path}: duplicate identities or unexpected method.')
    if len(frame) != 125 or set(frame.seed) != set(range(5)):
        raise ValueError(f'{path}: expected 25 targets x seeds 0..4 (125 rows).')
    if frame.groupby(TARGET).ngroups != 25 or not frame.groupby(TARGET).size().eq(5).all():
        raise ValueError(f'{path}: incomplete target/seed coverage.')
    if not np.isfinite(frame[METRICS].to_numpy()).all():
        raise ValueError(f'{path}: nonfinite metrics.')
    return frame.set_index(KEY).sort_index()


def analyze(results_root):
    frames, metadata = {}, {}
    for label, (folder, method) in INPUTS.items():
        path = results_root/folder/'per_run_metrics.csv'
        frame = read(path, method)
        frames[label] = frame
        metadata[label] = dict(path=str(path.resolve()), sha256=hashlib.sha256(path.read_bytes()).hexdigest(),
            rows=len(frame), signatures=sorted(frame['signature'].unique().tolist()) if 'signature' in frame else [],
            tuning_modes=frame.graph_tuning.value_counts().to_dict() if 'graph_tuning' in frame else {})
    reference = frames['proposed25']
    for label, frame in frames.items():
        if not reference.index.equals(frame.index):
            raise ValueError(f'{label}: task/seed identities differ from the main model.')
        if not reference.target_samples.eq(frame.target_samples).all():
            raise ValueError(f'{label}: target sample counts differ.')
        if not reference.source_samples.eq(frame.source_samples).all():
            raise ValueError(f'{label}: source pool sizes differ.')
    for label in ['H-only', 'L-only', 'Random+Graph']:
        if not reference.selected_samples.eq(frames[label].selected_samples).all():
            raise ValueError(f'{label}: component budget does not match the main model.')
    if not frames['selected5_lr'].selected_samples.eq(frames['selected5_graph'].selected_samples).all():
        raise ValueError('The two 5% selection budgets differ.')
    for label in ['all_lr', 'all_graph']:
        if not frames[label].source_samples.eq(frames[label].selected_samples).all():
            raise ValueError(f'{label}: not full-source training.')
        if not frames[label].graph_tuning.eq('source_lopo').all():
            raise ValueError(f'{label}: expected source-LOPO-tuned full-source control.')
    means = {label: frame.groupby(level=TARGET)[METRICS].mean() for label, frame in frames.items()}
    components, component_differences = [], []
    for label in ['H-only', 'L-only', 'Random+Graph']:
        for metric in METRICS:
            delta = means['proposed25'][metric]-means[label][metric]
            components.append(dict(baseline=label, metric=metric,
                main_mean=float(means['proposed25'][metric].mean()),
                baseline_mean=float(means[label][metric].mean()), **paired(delta)))
            for (family, target), value in delta.items():
                component_differences.append(dict(dataset=family, target=target, baseline=label,
                                                  metric=metric, difference=float(value)))
    bh(components)  # One family: 3 ablations x 2 primary metrics.
    interactions, details = [], []
    for metric in METRICS:
        # Pair by task and seed first; target projects, not seeds, are test units.
        selected_gain = frames['selected5_graph'][metric]-frames['selected5_lr'][metric]
        all_gain = frames['all_graph'][metric]-frames['all_lr'][metric]
        delta = (selected_gain-all_gain).groupby(level=TARGET).mean()
        target_selected = selected_gain.groupby(level=TARGET).mean()
        target_all = all_gain.groupby(level=TARGET).mean()
        interactions.append(dict(metric=metric, selected_graph_gain=float(target_selected.mean()),
            all_graph_gain=float(target_all.mean()), **paired(delta)))
        for (family, target), value in delta.items():
            details.append(dict(dataset=family, target=target, metric=metric,
                selected_graph_gain=float(target_selected.loc[(family, target)]),
                all_graph_gain=float(target_all.loc[(family, target)]), interaction=float(value)))
    bh(interactions)  # Separate family: 5% interaction in AUC and MCC.
    target_means = pd.concat(means, names=['configuration']).reset_index()
    protocol = dict(aggregation='Mean five seeds per target, then equal-weight 25 target projects.',
        test='Two-sided Wilcoxon signed-rank; zero_method=wilcox; tie tolerance 1e-12.',
        effect='Paired rank-biserial correlation; positive favors the main model / positive interaction.',
        correction_families=dict(component_comparisons=6, interaction_5percent=2),
        interaction='(selected5_graph-selected5_lr)-(all_graph-all_lr)', inputs=metadata)
    return components, component_differences, interactions, details, target_means, protocol


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--results-root', type=Path, default=Path(__file__).resolve().parent/'results')
    parser.add_argument('--output-dir', type=Path, default=Path('results/component_statistics_20261022'))
    args = parser.parse_args()
    components, differences, interactions, details, means, protocol = analyze(args.results_root)
    args.output_dir.mkdir(parents=True, exist_ok=True)
    for filename, rows in [('component_paired_tests.csv', components),
                           ('component_differences_per_target.csv', differences),
                           ('interaction_5percent_tests.csv', interactions),
                           ('interaction_5percent_per_target.csv', details)]:
        pd.DataFrame(rows).to_csv(args.output_dir/filename, index=False, encoding='utf-8-sig')
    means.to_csv(args.output_dir/'target_means.csv', index=False, encoding='utf-8-sig')
    (args.output_dir/'protocol.json').write_text(json.dumps(protocol, ensure_ascii=False, indent=2), encoding='utf-8')
    print('\n25% component comparisons (BH family: 6 tests)')
    print(pd.DataFrame(components).to_string(index=False))
    print('\n5% four-pipeline interaction (BH family: 2 tests)')
    print(pd.DataFrame(interactions).to_string(index=False))
    print(f'\nSaved {args.output_dir.resolve()}')


if __name__ == '__main__':
    main()
