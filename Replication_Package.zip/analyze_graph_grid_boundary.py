"""Report saved source-only boundary selection and final main-model metrics."""
import argparse
import json
from pathlib import Path
import pandas as pd


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('input_root',type=Path)
    args=parser.parse_args()
    method='coverage_uncertainty_graph_lr'
    frame=pd.read_csv(args.input_root/'per_run_metrics.csv')
    if frame.duplicated(['dataset','target','seed']).any():
        raise ValueError('Duplicate task/seed identities.')
    targets=frame.groupby(['dataset','target'])[['auc','mcc']].mean()
    rows=[]
    for (family,target) in targets.index:
        record=json.loads((args.input_root/'tuning'/f'{family}__{target}.json').read_text())[method]
        old,new=record['original_best'],record['best']
        rows.append(dict(dataset=family,target=target,original_c=old['c'],original_beta=old['beta'],
            original_k=old['neighbors'],expanded_c=new['c'],expanded_beta=new['beta'],expanded_k=new['neighbors'],
            source_validation_auc_old=old['auc'],source_validation_auc_new=new['auc'],
            source_validation_auc_gain=record['validation_auc_gain'],selected_new_setting=record['selected_from_added_grid'],
            original_candidates=record['original_candidates'],added_candidates=record['added_candidates'],
            anchors_verified=record['verified_anchor_candidates'],
            final_auc=float(targets.loc[(family,target),'auc']),final_mcc=float(targets.loc[(family,target),'mcc'])))
    choices=pd.DataFrame(rows)
    out=args.input_root/'statistics'
    out.mkdir(exist_ok=True)
    choices.to_csv(out/'boundary_selection_per_target.csv',index=False,encoding='utf-8-sig')
    choices.groupby(['expanded_c','expanded_beta','expanded_k']).size().rename('targets').reset_index().to_csv(
        out/'boundary_parameter_counts.csv',index=False,encoding='utf-8-sig')
    summary=dict(targets=len(targets),runs=len(frame),selected_new_settings=int(choices.selected_new_setting.sum()),
        mean_source_validation_auc_gain=float(choices.source_validation_auc_gain.mean()),
        final_auc=float(targets.auc.mean()),final_mcc=float(targets.mcc.mean()))
    (out/'boundary_summary.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
    print('\nMAIN-MODEL BOUNDARY CHECK')
    print(choices.to_string(index=False))
    print(json.dumps(summary,indent=2))
    print(f'Saved {out.resolve()}')


if __name__=='__main__': main()
