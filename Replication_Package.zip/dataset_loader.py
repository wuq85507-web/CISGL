"""Load software-metric benchmark datasets with explicit feature/label schemas."""
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.io import arff


DEFAULT_ROOT = Path(__file__).resolve().parent / 'datasets'
FAMILIES = ('ReLink', 'AEEEM', 'JIRA', 'PROMISE', 'Kamei',
            'PROMISE_18', 'NASA_CSV', 'NASA_ARFF', 'GitHub15', 'NASA_D2')
NASA_D2_PROJECTS = 'CM1 JM1 KC1 KC3 MC1 MC2 MW1 PC1 PC2 PC3 PC4 PC5'.split()
NASA_D2_METRICS = ('BRANCH_COUNT CYCLOMATIC_COMPLEXITY DESIGN_COMPLEXITY ESSENTIAL_COMPLEXITY '
    'HALSTEAD_CONTENT HALSTEAD_DIFFICULTY HALSTEAD_EFFORT HALSTEAD_ERROR_EST '
    'HALSTEAD_LENGTH HALSTEAD_LEVEL HALSTEAD_PROG_TIME HALSTEAD_VOLUME '
    'LOC_CODE_AND_COMMENT LOC_COMMENTS LOC_EXECUTABLE LOC_TOTAL NUM_OPERANDS '
    'NUM_OPERATORS NUM_UNIQUE_OPERANDS NUM_UNIQUE_OPERATORS').split()
OO_METRICS = 'wmc dit noc cbo rfc lcom ca ce npm lcom3 loc dam moa mfa cam ic cbm amc max_cc avg_cc'.split()
JIT_METRICS = 'ns nm nf entropy la ld lt fix ndev pd npt exp rexp sexp'.split()
GITHUB_METRICS = ('CC CCL CCO CI CLC CLLC LDC LLDC LCOM5 NL NLE WMC CBO CBOI NII NOI RFC '
    'AD CD CLOC DLOC PDA PUA TCD TCLOC DIT NOA NOC NOD NOP LLOC LOC NA NG NLA NLG NLM '
    'NLPA NLPM NLS NM NOS NPA NPM NS TLLOC TLOC TNA TNG TNLA TNLG TNLM TNLPA TNLPM '
    'TNLS TNM TNOS TNPA TNPM TNS').split()


def github_release_catalog(root):
    """Dataset eligibility only: latest usable two-class release per project.

    No model scores enter release selection. Labels are inspected for benchmark
    eligibility, never supplied as target labels to selection/training/tuning.
    """
    folder = Path(root)/'additional'/'GitHubBugDataset_1.1'/'extracted'/'GitHubBugDataSet-1.1'/'database'
    if not folder.is_dir():
        raise FileNotFoundError(f'GitHub Bug Dataset 1.1 not found: {folder}')
    records = []
    for project in sorted(p for p in folder.iterdir() if p.is_dir()):
        candidates = sorted(project.glob('*/*-Class.csv'), reverse=True)
        accepted = False
        for path in candidates:
            data = load_project(path, 'GitHub15', allow_empty=True)
            classes = len(np.unique(data['y']))
            selected = not accepted and classes == 2
            accepted = accepted or selected
            records.append(dict(project=project.name, release=path.parent.name,
                path=str(path.resolve()), original_rows=data['original_rows'],
                valid_rows=len(data['y']), invalid_rows=data['invalid_rows'],
                defects=int(data['y'].sum()), nondefects=int((data['y'] == 0).sum()),
                selected=selected, reason='latest usable two-class release' if selected
                else 'empty or invalid release' if not len(data['y'])
                else 'single-class release' if classes < 2 else 'older than selected release'))
        if not accepted:
            raise ValueError(f'No two-class release for {project.name}; report this project explicitly.')
    if not records:
        raise FileNotFoundError(f'No class-level CSV files under {folder}')
    return records


def project_paths(root, family):
    root = Path(root)
    if family in FAMILIES[:5]:
        paths = sorted((root / 'ASCSA_25' / family).glob('*.csv'))
    elif family == 'PROMISE_18':
        paths = sorted((root / 'additional' / 'PROMISE_18' / 'extracted' / 'DATASET').glob('*.csv'))
    elif family == 'NASA_CSV':
        paths = sorted((root / 'additional' / 'NASA_MDP').glob('*.csv'))
    elif family == 'NASA_ARFF':
        # These three original MDP files share the 40-metric schema. The other
        # ARFFs duplicate NASA_CSV and must not be treated as new projects.
        paths = [root / 'additional' / 'NASA_MDP' / (name + '.arff')
                 for name in ('KC3', 'MW1', 'PC2')]
    elif family == 'GitHub15':
        paths = [Path(row['path']) for row in github_release_catalog(root) if row['selected']]
    elif family == 'NASA_D2':
        # KC4 in the mirror is an empty placeholder, not a usable project.
        paths = [root/'additional'/'NASA_D2'/(name+'.arff') for name in NASA_D2_PROJECTS]
    else:
        raise ValueError(f'Unknown family: {family}')
    if not paths or any(not p.is_file() for p in paths):
        raise FileNotFoundError(f'Dataset family {family} not found under {root}')
    return paths


def binary_label(series):
    series = series.map(lambda v: v.decode() if isinstance(v, bytes) else v)
    numeric = pd.to_numeric(series, errors='coerce')
    if numeric.notna().all():
        return (numeric > 0).astype(int)
    mapping = {'buggy': 1, 'clean': 0, 'true': 1, 'false': 0,
               'yes': 1, 'no': 0, 'y': 1, 'n': 0,
               'defective': 1, 'nondefective': 0, '1': 1, '0': 0}
    result = series.astype(str).str.strip().str.lower().map(mapping)
    if result.isna().any():
        raise ValueError(f'Unknown label values: {series[result.isna()].unique().tolist()}')
    return result.astype(int)


def load_project(path, family, allow_empty=False):
    path = Path(path)
    if path.suffix.lower() == '.arff':
        records, _ = arff.loadarff(path)
        frame = pd.DataFrame(records)
    else:
        frame = pd.read_csv(path)
    if family == 'NASA_CSV':
        # PC1 uses capitals, KC2 spells the combined line metric differently.
        frame.columns = [str(c).strip().lower().replace('locodeandcomment', 'loccodeandcomment')
                         for c in frame.columns]
    if family == 'NASA_D2':
        label = 'label' if 'label' in frame else 'Defective'
        features = NASA_D2_METRICS
    elif family == 'GitHub15':
        label, features = 'Number of bugs', GITHUB_METRICS
    elif family in ('PROMISE', 'PROMISE_18'):
        label, features = 'bug', OO_METRICS
    elif family == 'JIRA':
        label = 'RealBug'
        features = [c for c in frame if c not in {'File', 'HeuBug', 'HeuBugCount', 'RealBug', 'RealBugCount'}]
    elif family == 'Kamei':
        label, features = 'bug', JIT_METRICS
    else:
        label = {'ReLink': 'isDefective', 'AEEEM': 'class',
                 'NASA_CSV': ('problems' if 'problems' in frame else 'defects'),
                 'NASA_ARFF': 'Defective'}[family]
        features = [c for c in frame if c != label]
    X = frame[features].apply(pd.to_numeric, errors='coerce')
    valid = np.isfinite(X.to_numpy(dtype=float)).all(axis=1) & frame[label].notna()
    y = binary_label(frame.loc[valid, label]).to_numpy()
    X = X.loc[valid].to_numpy(dtype=float)
    if not len(X) and not allow_empty:
        raise ValueError(f'No usable rows: {path}')
    return {'name': path.parent.parent.name if family == 'GitHub15' else path.stem,
            'path': path, 'features': features, 'X': X, 'y': y,
            'row_indices': np.flatnonzero(valid),
            'original_rows': len(frame), 'invalid_rows': int((~valid).sum()),
            'duplicate_rows': int(pd.DataFrame(np.column_stack([X, y])).duplicated().sum())}


def load_family(root, family):
    projects = [load_project(p, family) for p in project_paths(root, family)]
    schema = projects[0]['features']
    for project in projects[1:]:
        if set(project['features']) != set(schema):
            raise ValueError(f'Incompatible metric schema: {family}/{project["name"]}')
        order = [project['features'].index(c) for c in schema]
        project['X'] = project['X'][:, order]
        project['features'] = list(schema)
    return projects
