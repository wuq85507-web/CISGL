import math
import statistics as st
def d(a, b):
    denom = math.sqrt(((len(a) - 1) * st.variance(a) + (len(b) - 1) * st.variance(b)) / (len(a) + len(b) - 2))
    return (st.mean(a) - st.mean(b)) / denom if denom else 0 if st.mean(a) == st.mean(b) else math.inf

def group_recursive(vectors):
    order = sorted(vectors, key=lambda n: (-st.mean(vectors[n]), n))
    means = [st.mean(vectors[n]) for n in order]

    def negligible(l, r):
        return l == r or abs(d(vectors[order[l]], vectors[order[r]])) < 0.2

    def cut(l, r):
        scores = [sum(means[l:j + 1]) ** 2 / (j - l + 1) + sum(means[j + 1:r + 1]) ** 2 / (r - j) - sum(means[l:r + 1]) ** 2 / (r - l + 1) for j in range(l, r)]
        return l + max(range(len(scores)), key=scores.__getitem__)
    groups = []

    def recurse(l, r):
        if negligible(l, r):
            groups.append(order[l:r + 1])
            return
        j = cut(l, r)
        recurse(l, j)
        recurse(j + 1, r)
    recurse(0, len(order) - 1)
    result = {name: i + 1 for i, g in enumerate(groups) for name in g}
    assigned = {}
    marks = {}
    l = 0
    r = len(order) - 1
    ng = 0
    steps = 0
    while len(assigned) < len(order):
        steps += 1
        assert steps < 1000
        if l == r:
            ng += 1
            assigned[order[l]] = ng
            if len(assigned) == len(order):
                break
            l = r + 1
            r = marks[r]
            continue
        j = cut(l, r)
        if negligible(l, r) or j == l:
            if not negligible(l, r):
                ng += 1
                assigned[order[l]] = ng
                l = j + 1
            if negligible(l, r):
                ng += 1
                for i in range(l, r + 1):
                    assigned[order[i]] = ng
                if len(assigned) == len(order):
                    break
                l = r + 1
                r = marks[r]
            while l == r:
                ng += 1
                assigned[order[r]] = ng
                if len(assigned) == len(order):
                    break
                l = r + 1
                r = marks[r]
        else:
            marks[j] = r
            r = j
    assert assigned == result, (assigned, result)
    return (order, result)
