import csv
import json
import sys
from pathlib import Path

import numpy as np
from scipy.stats import rankdata, wilcoxon

ANALYSIS_DIR = Path(__file__).resolve().parent
PACKAGE_ROOT = ANALYSIS_DIR.parent
if str(ANALYSIS_DIR) not in sys.path:
    sys.path.insert(0, str(ANALYSIS_DIR))

from sk_functions import group_recursive

METRICS = ["auc", "mcc", "average_precision", "f1"]
REFERENCE = "CISGL"


def main():
    csv_path = PACKAGE_ROOT / "results_data" / "RQ1_target_means.csv"
    lookup = {}
    keys_seen = []
    key_set = set()
    with csv_path.open("r", encoding="utf-8-sig", newline="") as f:
        for row in csv.DictReader(f):
            method = row["method"].strip()
            key = (row["dataset"].strip(), row["target"].strip())
            if key not in key_set:
                key_set.add(key)
                keys_seen.append(key)
            lookup.setdefault(method, {})[key] = {m: float(row[m]) for m in METRICS}

    comparators = sorted(m for m in lookup if m != REFERENCE)
    order = comparators + [REFERENCE]

    tests = []
    for comp in comparators:
        for m in METRICS:
            delta = np.array([lookup[REFERENCE][k][m] - lookup[comp][k][m] for k in keys_seen])
            delta[np.abs(delta) <= 1e-12] = 0.0
            nonzero = delta[delta != 0.0]
            if len(nonzero):
                ranks = rankdata(np.abs(nonzero))
                p = float(wilcoxon(delta, alternative="two-sided").pvalue)
                effect = float((ranks[nonzero > 0].sum() - ranks[nonzero < 0].sum()) / ranks.sum())
            else:
                p = 1.0
                effect = 0.0
            tests.append({
                "method": comp,
                "metric": m,
                "delta": float(delta.mean()),
                "wins": int((delta > 0).sum()),
                "ties": int((delta == 0).sum()),
                "losses": int((delta < 0).sum()),
                "p": p,
                "effect": effect,
            })

    rank_idx = sorted(range(len(tests)), key=lambda i: tests[i]["p"])
    q_val = 1.0
    for rank in range(len(rank_idx), 0, -1):
        idx = rank_idx[rank - 1]
        q_val = min(q_val, tests[idx]["p"] * len(rank_idx) / rank)
        tests[idx]["q"] = q_val

    plot_orders = {}
    groups = {}
    for m in METRICS:
        plot_orders[m], groups[m] = group_recursive(
            {method: [lookup[method][k][m] for k in keys_seen] for method in order}
        )

    out = {
        "reference": REFERENCE,
        "correction_family_size": len(tests),
        "significant_counts": {m: sum(r["q"] < 0.05 for r in tests if r["metric"] == m) for m in METRICS},
        "groups": groups,
        "plot_orders": plot_orders,
        "tests": tests,
    }
    out_path = ANALYSIS_DIR / "rq1_statistics_summary.json"
    out_path.write_text(json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps({"groups": groups, "significant_counts": out["significant_counts"]}, indent=2))


if __name__ == "__main__":
    main()
