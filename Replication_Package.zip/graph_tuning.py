"""Source-project LOPO tuning; never accepts real target features or labels."""
import numpy as np
from sklearn.metrics import roc_auc_score, matthews_corrcoef
from selection import select_all, compress, fit_lr, positive_probability
from graph_lr import target_graph, graph_quadratic, fit_graph_lr
from budget_graph_selection import METHODS as BUDGET_GRAPH_METHODS, select_budget


def tune_graph(X, y, groups, methods, *, budget, budget_fraction, low_fraction,
               regions, quantiles, candidate_multiplier, information_ridge,
               betas=(0., .03, .1, .3), neighbors=(5, 10), c_grid=(1.,), tune_all_c=False):
    candidates = [(float(beta), int(k)) for beta in dict.fromkeys(betas)
                  for k in (neighbors[:1] if beta == 0 else neighbors)]
    method_candidates = {method: [(float(c), beta, k)
        for c in dict.fromkeys(c_grid if tune_all_c or method in ('coverage_uncertainty_graph_lr', 'coverage_random_graph_lr', *BUDGET_GRAPH_METHODS) else (1.,))
        for beta, k in candidates] for method in methods}
    records = {method: [] for method in methods}
    for held_out in np.unique(groups):
        train, valid = groups != held_out, groups == held_out
        # Labels of the pseudo-target are used only below for scoring predictions.
        if np.unique(y[valid]).size < 2:
            continue
        source, labels, target = X[train], y[train], X[valid]
        K = min(len(source), budget) if budget is not None else max(2, int(len(source)*budget_fraction))
        if K < 2 or len(source) < 2:
            continue
        selections = None
        if any(method in methods for method in ('coverage_uncertainty_graph_lr', 'coverage_random_graph_lr')):
            selections = select_all(source, labels, groups[train], target, K, low_fraction,
                regions, quantiles, 0, candidate_multiplier=candidate_multiplier,
                include_gain=False, include_information=False, information_ridge=information_ridge)[0]
        raw_source, raw_target = compress(source), compress(target)
        edges = {k: target_graph(raw_source, raw_target, k) for k in neighbors}
        for method in methods:
            if method in BUDGET_GRAPH_METHODS:
                chosen = select_budget(method, source, target, K, 0)[0]
            else:
                chosen = (np.arange(len(source)) if method == 'all_source_graph_lr'
                          else selections['coverage_random' if method == 'coverage_random_graph_lr' else 'coverage_uncertainty'])
            sx, sy = raw_source[chosen], labels[chosen]
            bases = {c: fit_lr(sx, sy, 0, c=c) for c in {r[0] for r in method_candidates[method]}}
            base = next(iter(bases.values()))
            scaled_target = base.steps[0][1].transform(raw_target)
            quadratics = {k: graph_quadratic(scaled_target, edges[k]) for k in neighbors}
            for c, beta, k in method_candidates[method]:
                model, _ = fit_graph_lr(sx, sy, raw_target, edges[k], 0, beta,
                                       base_model=bases[c], quadratic=quadratics[k], c=c)
                probability = positive_probability(model, raw_target)
                records[method].append(dict(held_out_source=int(held_out), c=c, beta=beta, neighbors=k,
                    auc=float(roc_auc_score(y[valid], probability)),
                    mcc=float(matthews_corrcoef(y[valid], probability >= .5))))
    output = {}
    for method, rows in records.items():
        if not rows:
            raise ValueError('No source LOPO fold has both classes; use --graph-tuning fixed explicitly.')
        summaries = []
        for c, beta, k in method_candidates[method]:
            matches = [r for r in rows if r['c'] == c and r['beta'] == beta and r['neighbors'] == k]
            summaries.append(dict(c=c, beta=beta, neighbors=k, folds=len(matches),
                auc=float(np.mean([r['auc'] for r in matches])),
                mcc=float(np.mean([r['mcc'] for r in matches]))))
        best = max(summaries, key=lambda r: (r['auc'], r['mcc'], -r['beta'], -r['neighbors']))
        output[method] = dict(best=best, candidates=summaries, folds=rows,
            protocol='source-project LOPO; mean project AUC; MCC breaks exact ties; selection seed=0',
            real_target_used=False)
    return output
