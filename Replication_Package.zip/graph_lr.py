"""Unlabeled-target graph regularization for the existing balanced LR."""
import copy
import numpy as np
from scipy.optimize import minimize
from scipy.special import expit
from scipy.linalg import solve_triangular
from sklearn.neighbors import NearestNeighbors
from sklearn.preprocessing import StandardScaler
from selection import fit_lr

GRAPH_METHODS = ('all_source_graph_lr', 'coverage_uncertainty_graph_lr')


def target_graph(source, target, neighbors=10):
    """Common graph topology in all-source-fitted metric space, no labels."""
    z = StandardScaler().fit(source).transform(target)
    if len(z) < 2:
        return np.array([], int), np.array([], int), np.array([], float)
    k = min(neighbors, len(z)-1)
    distances, indices = NearestNeighbors(n_neighbors=k+1, n_jobs=1).fit(z).kneighbors(z)
    edges = {}
    for i in range(len(z)):
        used = 0
        for distance, j in zip(distances[i], indices[i]):
            if i == j:
                continue
            a, b = sorted((i, int(j)))
            edges[(a, b)] = float(distance)
            used += 1
            if used == k:
                break
    pairs = np.asarray(list(edges), dtype=int)
    distance = np.asarray(list(edges.values()))
    positive = distance[distance > 1e-12]
    sigma = float(np.median(positive)) if len(positive) else 1.
    weights = np.exp(-distance**2/(2*sigma**2))
    return pairs[:, 0], pairs[:, 1], weights


def graph_quadratic(target, edges):
    left, right, weights = edges
    if not len(weights) or weights.sum() == 0:
        return np.zeros((target.shape[1], target.shape[1]))
    delta = target[left] - target[right]
    # Undirected edges stored once: equivalent to sum_ij W_ij diff^2 / (2 sum_ij W_ij).
    return (delta.T * weights) @ delta / (2*weights.sum())


def objective(parameters, source, labels, weights, quadratic, beta, c=1.):
    w, intercept = parameters[:-1], parameters[-1]
    logits = source @ w + intercept
    n = len(labels)
    loss = np.dot(weights, np.logaddexp(0, logits)-labels*logits)/weights.sum()
    # Matches sklearn balanced LR: mean BCE + ||w||^2/(2*C*n).
    loss += np.dot(w, w)/(2*c*n) + beta*(w @ quadratic @ w)
    residual = weights*(expit(logits)-labels)/weights.sum()
    gradient = np.r_[source.T @ residual + w/(c*n) + 2*beta*(quadratic @ w), residual.sum()]
    return float(loss), gradient


def fit_graph_lr(source, labels, target, edges, seed, beta, base_model=None, quadratic=None, c=1.):
    if not np.isfinite(beta) or beta < 0:
        raise ValueError('Graph beta must be finite and nonnegative.')
    if not np.isfinite(c) or c <= 0:
        raise ValueError('LR C must be finite and positive.')
    model = fit_lr(source, labels, seed, c=c) if base_model is None else copy.deepcopy(base_model)
    if len(np.unique(labels)) == 2 and model.steps[-1][1].C != c:
        raise ValueError('Cached base model must use the same C.')
    if len(np.unique(labels)) < 2 or beta == 0:
        return model, dict(beta=beta, c=c, status='single-class fallback' if len(np.unique(labels)) < 2 else 'exact ordinary LR')
    scaler, classifier = model.steps[0][1], model.steps[-1][1]
    z, t = scaler.transform(source), scaler.transform(target)
    quadratic = graph_quadratic(t, edges) if quadratic is None else quadratic
    counts = np.bincount(labels.astype(int), minlength=2)
    weights = len(labels)/(2*counts[labels.astype(int)])
    initial = np.r_[classifier.coef_[0], classifier.intercept_[0]]
    result = minimize(objective, initial, args=(z, labels, weights, quadratic, beta, c),
                      jac=True, method='L-BFGS-B', options=dict(maxiter=2000, gtol=1e-7, ftol=1e-12))
    attempts = [dict(solver='L-BFGS-B', success=bool(result.success),
                     message=str(result.message), iterations=int(result.nit))]
    if not result.success:
        # Exact change of coordinates using a global Hessian upper bound.
        # Nearest-source subsets can have tiny variance where the target has a
        # large range, yielding a stiff quadratic. Whitening changes neither
        # the loss, the graph nor the selected samples.
        start = result.x if np.isfinite(result.x).all() else initial
        design = np.column_stack((z, np.ones(len(z))))
        curvature = (design.T * (weights/(4*weights.sum()))) @ design
        curvature[:-1, :-1] += np.eye(z.shape[1])/(c*len(labels)) + 2*beta*quadratic
        factor = np.linalg.cholesky((curvature+curvature.T)/2)
        transform = solve_triangular(factor.T, np.eye(len(start)), lower=False)

        def transformed(value):
            loss, gradient = objective(start+transform @ value, z, labels, weights, quadratic, beta, c)
            return loss, transform.T @ gradient

        retry = minimize(transformed, np.zeros_like(start), jac=True, method='L-BFGS-B',
                         options=dict(maxiter=10000, maxfun=100000, maxls=50,
                                      gtol=1e-9, ftol=1e-12))
        candidate = start+transform @ retry.x
        value, gradient = objective(candidate, z, labels, weights, quadratic, beta, c)
        scaled_gradient = float(np.max(np.abs(transform.T @ gradient)))
        attempts.append(dict(solver='curvature-preconditioned L-BFGS-B',
            success=bool(retry.success), message=str(retry.message),
            iterations=int(retry.nit), scaled_gradient_max=scaled_gradient))
        if (not retry.success or not np.isfinite(candidate).all()
                or not np.isfinite(value) or scaled_gradient > 1e-5):
            raise RuntimeError(f'Graph LR optimization failed after preconditioned retry: '
                               f'{retry.message}; scaled_gradient={scaled_gradient:g}')
        if value > objective(initial, z, labels, weights, quadratic, beta, c)[0] + 1e-10:
            raise RuntimeError('Graph LR retry increased the objective above initialization.')
        result.x, result.fun, result.jac = candidate, value, gradient
        result.success, result.message = True, 'Converged after curvature-preconditioned retry'
        result.nit += retry.nit
    if not result.success or not np.isfinite(result.x).all():
        raise RuntimeError(f'Graph LR optimization failed: {result.message}')
    classifier.coef_ = result.x[:-1][None, :]
    classifier.intercept_ = result.x[-1:]
    return model, dict(beta=beta, c=c, status=str(result.message), iterations=int(result.nit),
        edges=len(edges[2]), objective=float(result.fun), gradient_max=float(np.abs(result.jac).max()),
        graph_energy=float(result.x[:-1] @ quadratic @ result.x[:-1]),
        l2_coefficient=1/(2*c*len(labels)), solver_attempts=attempts)
