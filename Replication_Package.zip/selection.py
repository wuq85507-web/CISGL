"""Metric-only instance-selection controls. No target labels accepted."""
import heapq
import numpy as np
from sklearn.cluster import KMeans, MiniBatchKMeans
from sklearn.dummy import DummyClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import GroupKFold, StratifiedKFold
from sklearn.neighbors import NearestNeighbors
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import pairwise_distances


METHODS = ('all_source', 'random_budget', 'nearest_budget', 'coverage_budget',
           'coverage_random', 'coverage_low_random', 'coverage_uncertainty',
           'coverage_low_uncertainty', 'coverage_uncertainty_pool_random',
           'coverage_uncertainty_gain', 'coverage_uncertainty_information')


def greedy_information_gain(vectors, initial, target_information, count):
    """Exact greedy trace reduction; recompute every candidate after each update."""
    matrix = np.asarray(initial, dtype=float).copy()
    target = np.asarray(target_information, dtype=float)
    remaining = np.ones(len(vectors), dtype=bool)
    selected, trace = [], []
    for _ in range(count):
        inverse = np.linalg.solve(matrix, np.eye(len(matrix)))
        positions = np.flatnonzero(remaining)
        projected = vectors[positions] @ inverse
        gains = np.einsum('ij,jk,ik->i', projected, target, projected)
        gains /= 1 + np.einsum('ij,ij->i', projected, vectors[positions])
        best = int(np.argmax(gains))
        position = int(positions[best])
        before = float(np.trace(target @ inverse))
        vector = vectors[position]
        matrix += np.outer(vector, vector)
        after = float(np.trace(target @ np.linalg.solve(matrix, np.eye(len(matrix)))))
        selected.append(position)
        remaining[position] = False
        trace.append(dict(step=len(selected), candidate_position=position,
                          gain=float(gains[best]), variance_before=before, variance_after=after))
    return np.asarray(selected, dtype=int), trace


def uncertainty_information(S, T, source_probability, target_probability, y,
                            high, candidates, count, ridge):
    """Fixed-pilot, class-weighted Fisher surrogate in common source-scaled space."""
    source = np.column_stack((S, np.ones(len(S))))
    target = np.column_stack((T, np.ones(len(T))))
    counts = np.bincount(y.astype(int), minlength=2)
    weights = len(y)/(2*counts[y.astype(int)]) if (counts > 0).all() else np.ones(len(y))
    curvature = weights*source_probability*(1-source_probability)
    vectors = source*np.sqrt(np.maximum(curvature, 0))[:, None]
    # Delta-method sensitivity of probabilities, evaluated at a fixed source pilot.
    sensitivity = target*(target_probability*(1-target_probability))[:, None]
    target_information = sensitivity.T @ sensitivity / len(T)
    initial = ridge*np.eye(source.shape[1]) + vectors[high].T @ vectors[high]
    chosen, trace = greedy_information_gain(vectors[candidates], initial, target_information, count)
    for row in trace:
        row['pool_index'] = int(candidates[row['candidate_position']])
    return candidates[chosen], dict(ridge=ridge, pilot='all-source balanced LR; source labels only',
        curvature_weights='fixed all-source balanced class weights',
        surrogate='local Fisher trace; ridge also regularizes intercept',
        target_count=len(T), candidate_indices=candidates.tolist(), greedy_trace=trace)


def greedy_coverage_gain(similarity, initial, count):
    """Lazy greedy maximization of mean max-similarity coverage, conditioned on H."""
    current = np.asarray(initial, dtype=np.float64).copy()
    if not 0 <= count <= len(similarity):
        raise ValueError('Invalid coverage selection count.')
    heap = []
    for i, row in enumerate(similarity):
        gain = float(np.maximum(row-current, 0).mean())
        heap.append((-gain, i, 0))
    heapq.heapify(heap)
    selected, trace = [], []
    while len(selected) < count:
        negative_gain, i, stamp = heapq.heappop(heap)
        if stamp != len(selected):
            gain = float(np.maximum(similarity[i]-current, 0).mean())
            heapq.heappush(heap, (-gain, i, len(selected)))
            continue
        before = float(current.mean())
        current = np.maximum(current, similarity[i])
        selected.append(i)
        trace.append(dict(step=len(selected), candidate_position=i,
                          gain=float(current.mean())-before, coverage=float(current.mean())))
    return np.asarray(selected, dtype=int), trace


def uncertainty_gain(X, T, high, candidates, count, seed, max_references):
    """Locally scaled target coverage; uniform target subsample for large targets."""
    rng = np.random.default_rng(seed)
    refs = np.sort(rng.choice(len(T), min(len(T), max_references), replace=False))
    R = T[refs]
    local = NearestNeighbors(n_neighbors=min(8, len(T)), n_jobs=1).fit(T).kneighbors(R)[0][:, -1]
    positive = local[local > 1e-12]
    fallback = float(np.median(positive)) if len(positive) else 1.
    sigma = np.where(local > 1e-12, local, fallback)
    h_distance = NearestNeighbors(n_neighbors=1, n_jobs=1).fit(X[high]).kneighbors(R)[0][:, 0]
    initial = np.exp(-h_distance**2 / (2*sigma**2))
    similarities = np.empty((len(candidates), len(R)), dtype=np.float32)
    for start in range(0, len(candidates), 256):
        squared = pairwise_distances(X[candidates[start:start+256]], R, metric='sqeuclidean')
        similarities[start:start+256] = np.exp(-squared/(2*sigma**2))
    chosen, trace = greedy_coverage_gain(similarities, initial, count)
    for row in trace:
        row['pool_index'] = int(candidates[row['candidate_position']])
    return candidates[chosen], dict(reference_indices=refs.tolist(),
        reference_count=len(refs), full_target_count=len(T), exact_target_objective=len(T) <= max_references,
        sigma_min=float(sigma.min()), sigma_median=float(np.median(sigma)),
        initial_coverage=float(initial.mean()), final_coverage=trace[-1]['coverage'],
        greedy_trace=trace)


def compress(X):
    # Supports metrics with signed values; no target-fitted parameters.
    return np.sign(X) * np.log1p(np.abs(X))


def fit_lr(X, y, seed, c=1.):
    if len(np.unique(y)) < 2:
        return make_pipeline(StandardScaler(), DummyClassifier(strategy='prior')).fit(X, y)
    return make_pipeline(StandardScaler(), LogisticRegression(
        C=c, class_weight='balanced', max_iter=2000, solver='lbfgs', random_state=seed)).fit(X, y)


def positive_probability(model, X):
    p = model.predict_proba(X)
    classes = model.classes_
    return p[:, list(classes).index(1)] if 1 in classes else np.zeros(len(X))


def oof_uncertainty(X, y, groups, seed):
    """Project-held-out predictions; all preprocessing is fitted inside each fold."""
    unique = np.unique(groups)
    if len(unique) >= 2:
        folds = GroupKFold(n_splits=min(5, len(unique))).split(X, y, groups)
        protocol = 'source-project-grouped OOF'
    else:
        counts = np.bincount(y.astype(int), minlength=2)
        n = min(5, int(counts.min()))
        if n < 2:
            return np.zeros(len(y)), 'insufficient source classes: zero uncertainty'
        folds = StratifiedKFold(n_splits=n, shuffle=True, random_state=seed).split(X, y)
        protocol = 'source-only stratified OOF fallback'
    probability = np.empty(len(y))
    for train, valid in folds:
        model = fit_lr(X[train], y[train], seed)
        probability[valid] = positive_probability(model, X[valid])
    return 1 - 2 * np.abs(probability - .5), protocol


def coverage_order(X, T, regions, seed):
    """Round-robin source nearest-neighbor rankings for target regions."""
    count = min(regions, len(np.unique(T, axis=0)))
    clusterer = (MiniBatchKMeans(n_clusters=count, random_state=seed, n_init=3,
                                batch_size=1024) if len(T) > 2000 else
                 KMeans(n_clusters=count, random_state=seed, n_init=10))
    labels = clusterer.fit_predict(T)
    rankings = []
    for label in np.unique(labels):
        distance = NearestNeighbors(n_neighbors=1, n_jobs=1).fit(T[labels == label]).kneighbors(X)[0][:, 0]
        rankings.append(np.argsort(distance, kind='stable'))
    pointers = np.zeros(len(rankings), dtype=int)
    used = np.zeros(len(X), dtype=bool)
    result = []
    while len(result) < len(X):
        for j, ranking in enumerate(rankings):
            while pointers[j] < len(X) and used[ranking[pointers[j]]]:
                pointers[j] += 1
            if pointers[j] < len(X):
                index = int(ranking[pointers[j]])
                used[index] = True
                result.append(index)
    return np.asarray(result)


def select_all(X, y, groups, T, budget, low_fraction, regions, quantiles, seed,
               candidate_multiplier=3., max_references=512, include_gain=True,
               include_information=True, information_ridge=1.):
    """Fixed K for all selection arms; ALL retains the complete source pool."""
    if not 2 <= budget <= len(X):
        raise ValueError('Budget must be between 2 and the source pool size.')
    if not 0 < low_fraction < 1 or not 0 <= quantiles[0] < quantiles[1] <= 1:
        raise ValueError('Invalid low fraction or distance quantiles.')
    if not np.isfinite(candidate_multiplier) or candidate_multiplier < 1 or max_references < 1:
        raise ValueError('Candidate multiplier must be >=1; reference count must be positive.')
    if not np.isfinite(information_ridge) or information_ridge <= 0:
        raise ValueError('Information ridge must be finite and positive.')
    # Fit common distance scaling using sources only, then transform target.
    raw_source, raw_target = compress(X), compress(T)
    scaler = StandardScaler().fit(raw_source)
    S, Z = scaler.transform(raw_source), scaler.transform(raw_target)
    distance = NearestNeighbors(n_neighbors=1, n_jobs=1).fit(Z).kneighbors(S)[0][:, 0]
    uncertainty, protocol = oof_uncertainty(raw_source, y, groups, seed)
    coverage = coverage_order(S, Z, regions, seed)
    n_low = max(1, min(budget - 1, round(budget * low_fraction)))
    high = coverage[:budget - n_low]
    remaining = np.setdiff1d(np.arange(len(X)), high)
    lower, upper = np.quantile(distance, quantiles)
    low = remaining[(distance[remaining] >= lower) & (distance[remaining] <= upper)]
    # Do not silently fill from another similarity region: preserve this experiment.
    if len(low) < n_low:
        raise ValueError(f'Only {len(low)} low-similarity candidates for {n_low} slots; '
                         'reduce budget/low fraction or widen distance quantiles.')
    rng = np.random.default_rng(seed)
    uncertain = remaining[np.argsort(-uncertainty[remaining], kind='stable')[:n_low]]
    low_uncertain = low[np.argsort(-uncertainty[low], kind='stable')[:n_low]]
    combined = lambda indices: np.r_[high, indices]
    selections = dict(all_source=np.arange(len(X)),
                      random_budget=rng.choice(len(X), budget, replace=False),
                      nearest_budget=np.argsort(distance, kind='stable')[:budget],
                      coverage_budget=coverage[:budget],
                      coverage_random=combined(rng.choice(remaining, n_low, replace=False)),
                      coverage_low_random=combined(rng.choice(low, n_low, replace=False)),
                      coverage_uncertainty=combined(uncertain),
                      coverage_low_uncertainty=combined(low_uncertain))
    audit = dict(budget=budget, high_size=len(high), low_size=n_low,
                 low_candidates=len(low), distance_lower=float(lower), distance_upper=float(upper),
                 oof_protocol=protocol, target_regions=min(regions, len(np.unique(Z, axis=0))))
    if include_gain or include_information:
        candidate_count = min(len(remaining), max(n_low, int(np.ceil(candidate_multiplier*n_low))))
        candidates = remaining[np.argsort(-uncertainty[remaining], kind='stable')[:candidate_count]]
    if include_gain:
        supplement, gain_audit = uncertainty_gain(S, Z, high, candidates, n_low, seed, max_references)
        # Separate RNG so existing eight arms preserve their historical samples.
        control_rng = np.random.default_rng(seed)
        selections['coverage_uncertainty_pool_random'] = combined(control_rng.choice(candidates, n_low, replace=False))
        selections['coverage_uncertainty_gain'] = combined(supplement)
        audit['uncertainty_gain'] = dict(gain_audit, candidate_multiplier=candidate_multiplier,
                                        candidate_indices=candidates.tolist())
    if include_information:
        pilot = fit_lr(raw_source, y, seed)
        supplement, information_audit = uncertainty_information(
            S, Z, positive_probability(pilot, raw_source), positive_probability(pilot, raw_target),
            y, high, candidates, n_low, information_ridge)
        selections['coverage_uncertainty_information'] = combined(supplement)
        audit['uncertainty_information'] = information_audit
    return selections, distance, uncertainty, audit
