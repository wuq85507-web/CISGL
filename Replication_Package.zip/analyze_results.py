"""Average seeds per target before averaging targets; paired comparisons vs ALL."""
import argparse
from pathlib import Path
import numpy as np
import pandas as pd
from scipy.stats import wilcoxon
from selection import METHODS
from graph_lr import GRAPH_METHODS
from transfer_baselines import TRANSFER_METHODS

METHODS = METHODS + GRAPH_METHODS + TRANSFER_METHODS


def interaction_results(frame, metrics):
    required = ['all_source', 'coverage_uncertainty', *GRAPH_METHODS]
    rows = []
    for metric in metrics:
        pivot = frame.pivot(index=['signature', 'dataset', 'target', 'seed'], columns='method', values=metric)
        if not set(required).issubset(pivot.columns):
            continue
        pair = pivot[required].dropna()
        gain_all = pair.all_source_graph_lr-pair.all_source
        gain_selected = pair.coverage_uncertainty_graph_lr-pair.coverage_uncertainty
        data = (gain_selected-gain_all).rename('interaction').to_frame()
        data['gain_all'] = gain_all
        data['gain_selected'] = gain_selected
        data['combined_minus_all'] = pair.coverage_uncertainty_graph_lr-pair.all_source
        data = data.groupby(['signature', 'dataset', 'target']).mean().reset_index()
        data['metric'] = metric
        rows.extend(data.to_dict('records'))
    return pd.DataFrame(rows)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('input', type=Path)
    args = parser.parse_args()
    frame = pd.read_csv(args.input)
    if frame.duplicated(['signature', 'dataset', 'target', 'seed', 'method']).any():
        raise ValueError('Duplicate result identities.')
    out = args.input.parent/'statistics'
    out.mkdir(exist_ok=True)
    metrics = ['auc', 'mcc', 'f1', 'average_precision', 'precision', 'recall', 'accuracy']
    interaction = interaction_results(frame, metrics)
    if len(interaction):
        interaction.to_csv(out/'interaction_per_target.csv', index=False)
        interaction.groupby(['signature', 'metric'])[
            ['interaction', 'gain_all', 'gain_selected', 'combined_minus_all']].agg(['mean', 'std']).to_csv(out/'interaction_summary.csv')
    targets = frame.groupby(['signature', 'dataset', 'target', 'method'])[metrics].mean().reset_index()
    targets.to_csv(out/'target_means.csv', index=False)
    summary = targets.groupby(['signature', 'method'])[metrics].agg(['mean', 'std'])
    summary.to_csv(out/'summary.csv')
    targets.groupby(['signature', 'dataset', 'method'])[metrics].agg(['mean', 'std']).to_csv(out/'per_family.csv')
    frame.groupby(['signature', 'dataset', 'target', 'method'])[metrics].agg(['mean', 'std']).to_csv(out/'seed_variation.csv')
    counts = frame.groupby(['signature', 'dataset', 'target', 'seed']).method.agg(
        recorded='nunique', methods=lambda x: '|'.join(sorted(set(x))))
    counts['expected_methods'] = len(METHODS)
    counts['all_methods_recorded'] = counts.recorded == len(METHODS)
    counts.to_csv(out/'completeness.csv')
    comparisons = []
    for signature, subset in targets.groupby('signature'):
        for metric in ('auc', 'mcc', 'f1', 'average_precision'):
            pivot = subset.pivot(index=['dataset', 'target'], columns='method', values=metric)
            if 'all_source' not in pivot:
                continue
            for method in METHODS[1:]:
                if method not in pivot:
                    continue
                pair = pivot[['all_source', method]].dropna()
                delta = pair[method] - pair.all_source
                p = float(wilcoxon(delta).pvalue) if len(delta) >= 2 and (delta != 0).any() else 1.
                comparisons.append(dict(signature=signature, method=method, metric=metric,
                    targets=len(delta), delta_mean=float(delta.mean()), wins=int((delta > 1e-12).sum()),
                    ties=int((delta.abs() <= 1e-12).sum()), losses=int((delta < -1e-12).sum()), p=p))
    paired = pd.DataFrame(comparisons)
    if len(paired):
        paired['bh_q'] = np.nan
        for _, group in paired.groupby(['signature', 'metric']):
            ordered = group.p.sort_values()
            q = np.minimum.accumulate((ordered.to_numpy()*len(ordered)/np.arange(1,len(ordered)+1))[::-1])[::-1]
            paired.loc[ordered.index, 'bh_q'] = np.clip(q,0,1)
        paired.to_csv(out/'paired_vs_all.csv', index=False)
    print(summary.to_string())
    print('Seeds averaged within targets; SD across targets. Check completeness.csv for partial runs.')
    print(f'Saved {out.resolve()}')


if __name__ == '__main__':
    main()
